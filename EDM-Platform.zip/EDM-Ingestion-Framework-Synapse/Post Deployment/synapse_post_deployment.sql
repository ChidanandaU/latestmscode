DECLARE @Count INT
DECLARE @ScopedCredential NVARCHAR(50)
SELECT @ScopedCredential = 'WorkspaceIdentity'


DECLARE @ExternalFileFormat NVARCHAR(50)
SELECT @ExternalFileFormat = 'DeltaLakeFormat'

DECLARE @ExternalDataSource1 NVARCHAR(50)
SELECT @ExternalDataSource1 = 'ExternalDataSourceStandardized'

SELECT @Count = COUNT(1) FROM sys.database_scoped_credentials WHERE name = @ScopedCredential
IF @Count <> 0
BEGIN
	SELECT @Count = COUNT(1) FROM sys.external_data_sources WHERE name = @ExternalDataSource1
	IF @Count <> 0
		BEGIN
			DROP EXTERNAL DATA SOURCE ExternalDataSourceStandardized
		END
	SELECT @Count = COUNT(1) FROM sys.external_data_sources WHERE name = 'ExternalDataSourceError'
	IF @Count <> 0
	BEGIN
		IF EXISTS ( SELECT * FROM sys.external_tables WHERE object_id = OBJECT_ID('dbo.FileProcessErrorLog') )
			DROP EXTERNAL TABLE dbo.FileProcessErrorLog
		IF EXISTS ( SELECT * FROM sys.external_tables WHERE object_id = OBJECT_ID('dbo.WarnType') )
			DROP EXTERNAL TABLE dbo.WarnType
		DROP EXTERNAL DATA SOURCE ExternalDataSourceError
	END
DROP DATABASE SCOPED CREDENTIAL WorkspaceIdentity
END

--- Create MasterKey 
DECLARE @MasterKeyCount INT
SELECT @MasterKeyCount = d.is_master_key_encrypted_by_server
FROM sys.databases AS d
WHERE d.name = '{DBName}'
IF @MasterKeyCount <> 0
BEGIN
	DROP MASTER KEY
END
CREATE MASTER KEY ENCRYPTION BY PASSWORD = '{Password}'
-- Create DATABASE SCOPED Credential
CREATE DATABASE SCOPED CREDENTIAL WorkspaceIdentity WITH IDENTITY = 'MANAGED IDENTITY'


SELECT @Count = COUNT(1) FROM sys.external_file_formats WHERE name = @ExternalFileFormat
IF @Count <> 0
BEGIN
DROP EXTERNAL FILE FORMAT DeltaLakeFormat
END
CREATE EXTERNAL FILE FORMAT DeltaLakeFormat WITH (FORMAT_TYPE = DELTA)


CREATE EXTERNAL DATA SOURCE ExternalDataSourceStandardized
WITH (
LOCATION = N'abfss://standardized@{account_name}.dfs.core.windows.net/data/',
CREDENTIAL = [WorkspaceIdentity]
)


CREATE EXTERNAL DATA SOURCE ExternalDataSourceError
WITH (
LOCATION = N'abfss://error@{account_name}.dfs.core.windows.net/data/',
CREDENTIAL = [WorkspaceIdentity]
)
GO

IF EXISTS ( SELECT * FROM sys.external_tables WHERE object_id = OBJECT_ID('dbo.FileProcessErrorLog') )
    DROP EXTERNAL TABLE dbo.FileProcessErrorLog
CREATE EXTERNAL TABLE dbo.FileProcessErrorLog
(
	PipelineID INT,
	SourceObjectId INT,
	SourceFileProcessLogId INT,
	ErrorType VARCHAR(200),
	ErrorCode VARCHAR(200),
	ErrorDescription VARCHAR(MAX),
	ErrorData VARCHAR(MAX),
	RowID NVARCHAR(200),
	CreatedOn DATETIME
)
WITH (
DATA_SOURCE=[ExternalDataSourceError], LOCATION='file_process_error_log',FILE_FORMAT=[DeltaLakeFormat]
)
GO
IF EXISTS ( SELECT * FROM sys.external_tables WHERE object_id = OBJECT_ID('dbo.WarnType') )
    DROP EXTERNAL TABLE dbo.WarnType
CREATE EXTERNAL TABLE dbo.WarnType
(
	DeltaTableName VARCHAR(110),
	[File] VARCHAR(100),
	RowID VARCHAR(1000),
	ColumnName VARCHAR(100),
	DefaultValue  VARCHAR(100),
	WarnCategory VARCHAR(100),
	CreatedOn DATETIME
)
WITH (
DATA_SOURCE=[ExternalDataSourceError], LOCATION='warn_type',FILE_FORMAT=[DeltaLakeFormat]
)
GO
