CREATE TABLE [ETLlog].[StreamingEventLog](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[EventHubID] [bigint] NULL,
	[StreamingSourceID] [bigint] NOT NULL,
	[EventGuid] [nvarchar](50) NULL,
	[IsValidated] [bit] NOT NULL,
	[EnqueuedTime] [datetime] NOT NULL,
	[SequenceNumber] [int] NOT NULL,
	[ProcessingStartTime] [datetime] NOT NULL,
	[ProcessingEndTime] [datetime] NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedOn] [datetime] NULL,
	[ModifiedBy] [nvarchar](50) NULL,
	[ModifiedOn] [datetime] NULL
) ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[StreamingEventLog]  WITH CHECK ADD FOREIGN KEY([EventHubID])
REFERENCES [Metadata].[EventHubsMaster] ([ID])
GO

ALTER TABLE [ETLlog].[StreamingEventLog]  WITH CHECK ADD FOREIGN KEY([StreamingSourceID])
REFERENCES [Metadata].[StreamingSourceDetails] ([ID])
GO