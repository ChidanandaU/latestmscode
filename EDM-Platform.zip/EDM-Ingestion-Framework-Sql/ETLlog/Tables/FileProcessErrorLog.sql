CREATE TABLE [ETLlog].[FileProcessErrorLog](
	[ErrorLogId] [int] IDENTITY(1,1) NOT NULL,
	[PipeLineId] [int] NOT NULL,
	[SourceObjectId] [int] NULL,
	[SourceFileProcessLogId] [int] NULL,
	[ErrorType] [nvarchar](200) NULL,
	[ErrorCode] [nvarchar](200) NULL,
	[ErrorDescription] [nvarchar](4000) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[ErrorData] [nvarchar](max) NULL,
	[RowId] [nvarchar](200) NULL,
PRIMARY KEY CLUSTERED 
(
	[ErrorLogId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[FileProcessErrorLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[FileProcessErrorLog] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[FileProcessErrorLog] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [ETLlog].[FileProcessErrorLog] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO

ALTER TABLE [ETLlog].[FileProcessErrorLog]  WITH CHECK ADD FOREIGN KEY([SourceObjectId])
REFERENCES [Metadata].[SourceObjectDetail] ([SourceObjectID])
GO