CREATE TABLE [ETLlog].[SourceFileProcessLog](
	[SourceFileProcessLogID] [int] IDENTITY(1,1) NOT NULL,
	[PipelineLogID] [int] NOT NULL,
	[FileName] [nvarchar](200) NOT NULL,
	[SourceCount] [bigint] NULL,
	[TargetCount] [bigint] NULL,
	[ErrorCount] [bigint] NULL,
	[DuplicateCount] [int] NULL,
	[IsLandingToRawProcessed] [bit] NULL,
	[IsRawtoStandardisedProcessed] [bit] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[SourceID] [int] NULL,
	[SourceObjectID] [int] NULL,
	[FilePath] [nvarchar](max) NULL,
	[SourceFileStatus] [varchar](20) NULL,
	[IsCDCFile] [bit] NULL,
	[RawFileStatus] [nvarchar](100) NULL,
	[RawPath] [nvarchar](500) NULL
 CONSTRAINT [PK_SourceFileProcessLog] PRIMARY KEY CLUSTERED 
(
	[SourceFileProcessLogID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[SourceFileProcessLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[SourceFileProcessLog] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[SourceFileProcessLog] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [ETLlog].[SourceFileProcessLog] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO

ALTER TABLE [ETLlog].[SourceFileProcessLog]  WITH CHECK ADD FOREIGN KEY([PipelineLogID])
REFERENCES [ETLlog].[PipelineLog] ([PipelineLogID])
GO