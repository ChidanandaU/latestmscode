CREATE TABLE [ETLlog].[PipelineEtlActivityLog](
	[PipelineActivityLogID] [int] IDENTITY(1,1) NOT NULL,
	[PipelineLogID] [int] NOT NULL,
	[ActivityName] [nvarchar](200) NOT NULL,
	[ActivityType] [nvarchar](200) NOT NULL,
	[StartTime] [datetime] NOT NULL,
	[EndTime] [datetime] NULL,
	[ActivityStatus] [nvarchar](50) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[ErrorMessage] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[PipelineActivityLogID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[PipelineEtlActivityLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[PipelineEtlActivityLog] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[PipelineEtlActivityLog] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [ETLlog].[PipelineEtlActivityLog] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO

ALTER TABLE [ETLlog].[PipelineEtlActivityLog]  WITH CHECK ADD FOREIGN KEY([PipelineLogID])
REFERENCES [ETLlog].[PipelineLog] ([PipelineLogID])
GO