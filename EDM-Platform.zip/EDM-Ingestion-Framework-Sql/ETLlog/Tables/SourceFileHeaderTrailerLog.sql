CREATE TABLE [ETLlog].[SourceFileHeaderTrailerLog](
	[HeaderTrailerLogID] [int] IDENTITY(1,1) NOT NULL,
	[SourceObjectID] [int] NOT NULL,
	[Metadata] [nvarchar](max) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[ProjectCode] [nvarchar](100) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[BusinessDate] [nvarchar](200) NULL,
	[RowCount] [bigint] NULL,
PRIMARY KEY CLUSTERED 
(
	[HeaderTrailerLogID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[SourceFileHeaderTrailerLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[SourceFileHeaderTrailerLog] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[SourceFileHeaderTrailerLog] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [ETLlog].[SourceFileHeaderTrailerLog] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO