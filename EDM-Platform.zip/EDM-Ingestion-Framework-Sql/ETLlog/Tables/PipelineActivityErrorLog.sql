CREATE TABLE [ETLlog].[PipelineActivityErrorLog](
	[PipelineActivityErrorLogID] [int] IDENTITY(1,1) NOT NULL,
	[PipelineActivityLogID] [int] NOT NULL,
	[ErrorMessage] [nvarchar](max) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[PipelineActivityErrorLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[PipelineActivityErrorLog] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[PipelineActivityErrorLog] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [ETLlog].[PipelineActivityErrorLog] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO