CREATE TABLE [ETLlog].[ErrorLog](
	[ErrorLogId] [int] IDENTITY(1,1) NOT NULL,
	[PipeLineId] [int] NOT NULL,
	[SourceObjectId] [int] NULL,
	[SourceFileProcessLogId] [int] NULL,
	[ErrorType] [nvarchar](200) NULL,
	[ErrorCode] [nvarchar](200) NULL,
	[ErrorDescription] [nvarchar](4000) NULL,
	[ErrorDetails] [nvarchar](4000) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ErrorLogId] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [ETLlog].[ErrorLog] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [ETLlog].[ErrorLog] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [ETLlog].[ErrorLog] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [ETLlog].[ErrorLog] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO

ALTER TABLE [ETLlog].[ErrorLog]  WITH CHECK ADD FOREIGN KEY([SourceObjectId])
REFERENCES [Metadata].[SourceObjectDetail] ([SourceObjectID])
GO