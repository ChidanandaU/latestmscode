﻿CREATE TYPE [ETLlog].[TableType_CDCWatermark] AS TABLE(
	[SourceName] [nvarchar](200) NULL,
	[CountryCode] [nvarchar](200) NULL,
	[SourceId] [int] NULL,
	[ObjectName] [nvarchar](200) NULL,
	[EODMarker] [nvarchar](50) NULL,
	[EODMarkerStrategy] [nvarchar](50) NULL
)
GO
