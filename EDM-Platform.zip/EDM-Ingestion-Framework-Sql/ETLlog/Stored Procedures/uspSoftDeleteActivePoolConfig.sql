CREATE PROCEDURE [ETLlog].[uspSoftDeleteActivePoolConfig]
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspSoftDeleteActivePoolConfig]
		Script Date:			      2021-06-07 
		Author:					        Divye Rastogi
		Test Execute:			      This SP is used to soft delete the active job pools
		CMD:					          EXEC ETLlog.uspSoftDeleteActivePoolConfig
								
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY	
		Update  [ETLlog].[PoolConfigurationLog]
		   SET 	isactive=0,
				EndDate = GETUTCDATE(),
				ModifiedBy = SUSER_NAME(),
				ModifiedOn = GETUTCDATE()
		WHERE IsActive = 1
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END

