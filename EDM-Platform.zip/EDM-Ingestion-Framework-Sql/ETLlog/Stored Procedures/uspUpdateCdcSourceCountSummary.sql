CREATE PROCEDURE ETLLog.uspUpdateCdcSourceCountSummary
@PipelineLogID INT,
@UpdateRecords INT,
@DeleteRecords INT,
@InsertRecords INT
AS
-----------------------------------------------------------------------------------------------------------------------    
/****** StoredProcedure:	[ETLlog].[uspUpdateCdcSourceCountSummary]
  Script Date:				    2021-09-03     
  Author:					        Divye Rastogi
  Test Execute:		        This SP is used to insert CDC File Source Count Breakdown into 
							            ETLlog.CdcSourceCountSummary
  CMD:						        EXEC [ETLlog].[uspUpdateCdcSourceCountSummary]
							            @ParentPipelineLogID = '<value>'
							            ,@UpdateRecords = '<value>'
							            ,@DeleteRecords = '<value>'
							            ,@InsertRecords = '<value>'
******/    
-----------------------------------------------------------------------------------------------------------------------    

BEGIN
	BEGIN TRY
		DECLARE @SourceFileProcessLogID INT 
		SELECT @SourceFileProcessLogID = SourceFileProcessLogID FROM EtlLog.SourceFileProcessLog WHERE PipelineLogID = @PipelineLogID
		INSERT INTO ETLLog.CdcSourceCountSummary
		(
			SourceFileProcessLogID,
			UpdateRecords,
			InsertRecords,
			DeleteRecords,
			CreatedOn,
			CreatedBy
		)
		VALUES
		(
			@SourceFileProcessLogID,
			@UpdateRecords,
			@InsertRecords,
			@DeleteRecords,
			GETUTCDATE(),
			SUSER_NAME()
		)
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
			)
	END CATCH
END