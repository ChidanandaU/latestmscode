CREATE PROCEDURE [dbo].[uspRetrieveTokenizedColumns] @objectname nvarchar(1000)
AS
BEGIN
DECLARE @columnname nvarchar(max)
SELECT @columnname=Coalesce(@columnname+','+(CASE WHEN colschema.istokenizable=1 
												 AND colschema.TokenizationAlgorithm is not null 
												THEN CONCAT('ptyProtectString',
													'('
													,colschema.columnName
													,','''
													,colschema.TokenizationAlgorithm
													,''') AS '+colschema.columnName
													)	
												  ELSE colschema.columnName
												  END),
								(CASE WHEN colschema.istokenizable=1 
								 AND colschema.TokenizationAlgorithm is not null 
								THEN CONCAT('ptyProtectString',
									'('
									,colschema.columnName
									,','''
									,colschema.TokenizationAlgorithm
									,''') AS '+colschema.columnName
									)	
								  ELSE colschema.columnName
								  END))
  FROM [Metadata].[SourceObjectSchema]  AS colschema
  JOIN [Metadata].[SourceObjectdetail] AS SourceObject
    ON colschema.SourceObjectID=SourceObject.SourceObjectId
  WHERE SourceObject.OBJECTNAME=@objectname
    AND colschema.IsActive=1 
    order by ColumnOrder asc
SELECT @columnname
END
GO