CREATE PROCEDURE [ETLlog].[uspUpdateStreamingEventLog]
@EventHubID INT = NULL,
@StreamingSourceName NVARCHAR(100) = NULL,
@EventGuid NVARCHAR(50) = NULL,
@IsValidated INT = NULL,
@EnqueuedTime DATETIME = NULL,
@SequenceNumber INT = NULL,
@ProcessingStartTime DATETIME = NULL,
@ProcessingEndTime DATETIME = NULL,
@Mode NVARCHAR(20)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspUpdateStreamingEventLog]
		Script Date:			2021-06-10
		Author:					Divye Rastogi
		Test Execute:			This SP is used to insert and update Event Logs in the StreamingEventLog Table
		CMD:					EXEC [ETLlog].[uspUpdateStreamingEventLog]
								@EventHubID = '<value>', @StreamingSourceName =<value>, @EventGuid =<value>,
								@IsValidated = '<value>', @EnqueuedTime=<value>, @SequenceNumber =<value>,
								@ProcessingStartTime=<value>, @ProcessingEndTime = <value>, @Mode=<insert/update>

******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY	
		IF @Mode = 'insert'
		BEGIN
			DECLARE @StreamingSourceID INT
			SELECT @StreamingSourceID = ID FROM Metadata.StreamingSourceDetails WHERE StreamingSource = @StreamingSourceName
			INSERT INTO ETLlog.StreamingEventLog
			(
				EventHubID,
				StreamingSourceID,
				EventGuid,
				IsValidated,
				EnqueuedTime,
				SequenceNumber,
				ProcessingStartTime,
				ProcessingEndTime,
				CreatedBy,
				CreatedOn
			)
			SELECT
			@EventHubID,
			@StreamingSourceID,
			@EventGuid,
			@IsValidated,
			@EnqueuedTime,
			@SequenceNumber,
			@ProcessingStartTime,
			@ProcessingEndTime,
			SUSER_NAME(),
			GETUTCDATE()
		END

		ELSE
		BEGIN
			UPDATE ETLlog.StreamingEventLog
			SET 
			IsValidated = @IsValidated,
			ProcessingEndTime = @ProcessingEndTime,
			ModifiedBy = SUSER_NAME(),
			ModifiedOn = GETUTCDATE()
			WHERE EventGuid = @EventGuid
		END
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
			)
	END CATCH
END