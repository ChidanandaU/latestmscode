CREATE PROCEDURE [ETLlog].[uspUpdateEtlPipelineLogRealTime]
@PipeLineName NVARCHAR(2000) =NULL,
@PipelineStatus NVARCHAR(50),
@StartTime DATETIME =NULL ,
@EndTime DATETIME =NULL,
@RunID UNIQUEIDENTIFIER =NULL,
@LoadType NVARCHAR(20) =NULL,
@Mode NVARCHAR(20),
@PipelineLogID INT =NULL
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspUpdateEtlPipelineLogRealTime]
		Script Date:			2021-06-07 
		Author:					Priyanka Bariki
		Test Execute:			This SP is used to insert or update records into the PipelineLog Table.
		CMD:					EXEC ETLlog.[uspUpdateEtlPipelineLogRealTime]
								@PipeLineName = <value>, @PipelineStatus=<value>,@StartTime = <value>, @EndTime=<value>,
								@RunID = <value>,@LoadType=<value>, @Mode = <Value>,@PipelineLogID = <value>
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
    BEGIN TRY
		IF @Mode=N'insert'
		BEGIN

        INSERT INTO [EtlLog].PipelineLog
            (
            PipeLineName,
            PipelineStatus,
            StartTime,			
			RunID,
            LoadType,
			CreatedBy,
			CreatedOn
            )
        VALUES
            (
            @PipeLineName,
            @PipelineStatus,
            @StartTime,
            @RunID,
            @LoadType,
			SUSER_NAME(),
		    GETUTCDATE()
		    );


        SELECT SCOPE_IDENTITY() AS PipelineLogID;

		END
		ELSE
		BEGIN
			UPDATE ETLlog.PipelineLog
			SET 
			PipelineStatus = @PipelineStatus,
			EndTime = @EndTime,
			ModifiedBy = SUSER_NAME(),
			ModifiedOn = GETUTCDATE()
			WHERE PipelineLogID = @PipelineLogID
		END

		END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
