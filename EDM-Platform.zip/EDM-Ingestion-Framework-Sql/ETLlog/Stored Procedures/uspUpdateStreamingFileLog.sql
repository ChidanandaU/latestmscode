CREATE PROCEDURE [ETLlog].[uspUpdateStreamingFileLog]
@PipelineLogID INT = NULL,
@FileName NVARCHAR(100) = NULL,
@FilePath NVARCHAR(255) = NULL,
@FileType NVARCHAR(50) = NULL,
@StartTime DATETIME = NULL,
@EndTime DATETIME = NULL,
@IsSucessful BIT,
@Mode NVARCHAR(20),
@FileLogID BIGINT NULL
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspUpdateStreamingFileLog]
		Script Date:			2021-06-07 
		Author:					Divye Rastogi
		Test Execute:			This SP is used to insert or update records into the uspUpdateStreamingFileLog Table.
		CMD:					EXEC ETLlog.uspUpdateStreamingFileLog
								@PipelineLogID = <value>, @FileName=<value>, @FilePath = <value>, @FileType = <value>,
								@StartTime = <value>, @EndTime=<value>, @IsSuccessful = <value>, @Mode = <Value>,
								@FileLogID = <value>
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY	
		IF @Mode = 'insert'
		BEGIN
			INSERT INTO ETLlog.StreamingFileLog
			(
				PipelineLogID,
				[FileName],
				FilePath,
				FileType,
				StartTime,
				IsSuccessful,
				CreatedBy,
				CreatedOn
			)
			VALUES
			(
				@PipelineLogID,
				@FileName,
				@FilePath,
				@FileType,
				@StartTime,
				@IsSucessful,
				SUSER_NAME(),
				GETUTCDATE()
			)
			SELECT SCOPE_IDENTITY() AS StreamingFileLogID
		END

		ELSE
		BEGIN
			UPDATE ETLlog.StreamingFileLog
			SET 
			IsSuccessful = @IsSucessful,
			EndTime = @EndTime,
			ModifiedBy = SUSER_NAME(),
			ModifiedOn = GETUTCDATE()
			WHERE ID = @FileLogID
		END
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END

