﻿CREATE PROCEDURE [ETLlog].[uspGetSourceToProcessedCDC] 
@FrequencyDurationUnit nvarchar(100)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLLOG].[uspGetSourceToProcessedCDC]
		Script Date:			2021-08-17
		Author:					Ankita Kumari	
		Test Execute:			This SP is used to get the source id & source object id for EOD Marker files
		CMD:					EXEC [ETLLOG].[uspGetSourceToProcessedCDC] 
								@FilePath='<value>',
								@FileName = '<value>'
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY

	
	SELECT Distinct SM.SourceID,SOD.SourceObjectId, SPL.FileName
	  FROM Etllog.SourceFileProcessLog SPL WITH(NOLOCK) 
	  JOIN Metadata.SourceMaster SM WITH(NOLOCK)
	    ON SPL.SourceID=SM.SourceID 
	  JOIN Metadata.SourceObjectDetail SOD
		ON SPL.SourceObjectId = SOD.SourceObjectID
	  WHERE SPL.FileName LIKE 'CDC_EOD_MARKER%' OR FILEName LIKE '%RECON%'
	   AND SPL.IsLandingToRawProcessed=1 
	   AND SPL.IsRawtoStandardisedProcessed=0
	   AND SPL.RawFileStatus = 'Not Processed'
	   AND SPL.IsCDCFile = 1
	 
	  
	
	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
GO


