CREATE PROCEDURE [ETLlog].[uspUpdatePipelineEtlActivityLog]
( 
  @PipelineActivityLogID INT,
  @ActivityStatus NVARCHAR(50)
)
AS 
BEGIN
    BEGIN TRY	
	SET NOCOUNT ON;

	IF @PipelineActivityLogID IS NOT NULL

		UPDATE EtlLog.PipelineEtlActivityLog
		SET [ActivityStatus] = @ActivityStatus,
		[EndTime] = GETUTCDATE(),
		[ModifiedOn] = GETUTCDATE(),
		[ModifiedBy] = SUSER_NAME()
		WHERE PipelineActivityLogID = @PipelineActivityLogID;
	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
	
END
