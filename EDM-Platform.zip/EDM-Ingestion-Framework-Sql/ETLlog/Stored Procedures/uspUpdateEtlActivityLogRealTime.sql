CREATE PROCEDURE [ETLlog].[uspUpdateEtlActivityLogRealTime]   
@ActivityName nvarchar(2000) = NULL,
@PipelineLogID INT =NULL,
@ActivityType NVARCHAR(20) =NULL,
@StartTime datetime =NULL,
@EndTime datetime =NULL,
@ActivityStatus NVARCHAR(50),
@Mode NVARCHAR(20),
@ActivityLogID BIGINT NULL,
@ErrorMessage NVARCHAR(max) = NULL
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspUpdateEtlActivityLogRealTime]
		Script Date:			2021-06-07 
		Author:					Priyanka Bariki
		Test Execute:			This SP is used to insert or update records into the PipelineEtlActivityLog Table.
		CMD:					EXEC ETLlog.[uspUpdateEtlActivityLogRealTime]
								@ActivityName = <value>, @PipelineLogID=<value>,@ActivityType=<value>,
								@StartTime = <value>, @EndTime=<value>,@ActivityStatus = <value>,@LoadType=<value>,
								@Mode = <Value>,@ActivityLogID = <value>
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN

    

    BEGIN TRY
		IF @Mode=N'insert'
		BEGIN

        INSERT INTO [EtlLog].[PipelineEtlActivityLog]
            (
            PipelineLogID,
            ActivityName,
			ActivityType,
			ActivityStatus,
            StartTime,
			CreatedBy,
			CreatedOn
            )
        VALUES
            (
            @PipelineLogID,
            @ActivityName,
            @ActivityType,
			@ActivityStatus,
            @StartTime,
			SUSER_NAME(),
		    GETUTCDATE()
		    );


        SELECT SCOPE_IDENTITY() AS PipelineActivityLogID;

		END
		ELSE
		BEGIN
			UPDATE ETLlog.PipelineEtlActivityLog
			SET 
			ActivityStatus = @ActivityStatus,
			EndTime = @EndTime,
			ErrorMessage = @ErrorMessage,
			ModifiedBy = SUSER_NAME(),
			ModifiedOn = GETUTCDATE()
			WHERE PipelineActivityLogID = @ActivityLogID
		END

		END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
