CREATE PROCEDURE [ETLlog].[uspTurnDownSchemaEvolutionFlagForObject]
	@SourceName nvarchar(1000),   
	@CountryCode nvarchar(1000),  
	@ObjectName nvarchar(1000)  
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspTurnDownSchemaEvolutionFlagForObject]
		Script Date:			      2021-08-17
		Author:					        Saurav Misra
		Test Execute:			      This SP is used to turn down the schema evolution flag for all columns having
                            this flag turned on for an object
		CMD:					          EXEC ETLlog.uspTurnDownSchemaEvolutionFlagForObject
                            @SourceName =<value>,   
	                          @CountryCode =<value>, 
	                          @ObjectName =<value>
								
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN  
    BEGIN TRY  
  Update sob  
        SET sob.IsSchemaEvolved=0
        FROM [Metadata].[SourceObjectSchema] sob  
        JOIN [Metadata].[SourceObjectDetail] sod   
          ON sob.SourceObjectID = sod.SourceObjectID  
        JOIN [metadata].[SourceMaster] AS SM     
          ON sm.SourceID = sod.SourceID  
   WHERE 
   sob.IsSchemaEvolved=1
   and sod.objectname = @ObjectName  
   and sm.SourceName = @SourceName  
   and sm.CountryCode = @CountryCode  
 END TRY  
 BEGIN CATCH  
 DECLARE @Errmsg NVARCHAR(4000) = (  
    SELECT ERROR_MESSAGE()  
    )  
   ,@ErrorSeverity INT = ERROR_SEVERITY()  
   ,@ErrorState INT = ERROR_STATE()  
  
  RAISERROR (  
    @Errmsg  
    ,@ErrorSeverity  
    ,@ErrorState  
    )  
 END CATCH  
 END  