CREATE PROCEDURE [ETLlog].[uspInsertFileProcessErrorLog]
@FileProcessErrorLog [ETLlog].TableType_FileProcessErrorLog READONLY 
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspInsertFileProcessErrorLog]
		Script Date:			2021-05-18 
		Author:					Vikash Jangid
		Test Execute:			This SP is used to insert or update records into the FileProcessErrorLog Table.
		CMD:					EXEC [ETLlog].[uspInsertFileProcessErrorLog] 
								@FileProcessErrorLog = @TableTypeParameter
******/
----------------------------------------------------------------------------------------------------------------------- 
BEGIN
	BEGIN TRY
		 
		SET NOCOUNT ON;
		INSERT INTO  [ETLlog].[FileProcessErrorLog](
							[PipeLineId],
							[SourceObjectId] ,
							[SourceFileProcessLogId],
							[RowId],
							[ErrorCode],
							[ErrorDescription],
							[ErrorData] 
						)

		SELECT PipeLineId,
			SourceObjectId, 
			SourceFileProcessLogId,
			RowId, 
			ErrorCode, 
			ErrorDescription, 
			ErrorData
		FROM @FileProcessErrorLog
 

	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END