CREATE PROCEDURE [ETLlog].[uspInsertParamConfigErrorLog]
( 
   @SourceName NVARCHAR(200), 
   @CountryName NVARCHAR(200), 
   @FileName NVARCHAR(200),
   @PipelineLogId INT,
   @OnSchemaEvolution BIT = 0,
   @ExceptionDetails NVARCHAR(MAX)
)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[ETLlog].[uspInsertParamConfigErrorLog]
		Script Date:			2021-08-06 
		Author:					Saurav Misra
		Test Execute:			This SP will log exception details to ParamConfigErrorLog table while 
		CMD:					EXEC [ETLlog].[uspInsertParamConfigErrorLog]
								  @SourceName =<Value>, 
								  @CountryName =<Value>,
								  @FileName =<Value>,
								  @PipelineLogId =<Value>,
								  @ExceptionDetails =<Value>,
								  @OnSchemaEvolution =<Value>
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
	
	SET NOCOUNT ON;

	SELECT @sourcename=Substring(@FileName,0,CHARINDEX('_',@FileName))

	INSERT INTO [ETLlog].[ParamConfigErrorLog]
		(
			[SourceFileProcessLogId],
			[ExceptionTimestamp],
			[ExceptionDetails],
			[OnSchemaEvolution]
		)
	SELECT
		sfp.SourceFileProcessLogID,
		(switchoffset(sysdatetimeoffset(),'+05:30')) AS ExceptionTimestamp,
		@ExceptionDetails AS ExceptionDetails,
		@OnSchemaEvolution
	FROM
	Metadata.SourceMaster sm 
	JOIN ETLLog.SourceFileProcessLog sfp 
		ON sm.SourceID = sm.SourceID
	WHERE
		sm.SourceName = @SourceName
		AND sm.CountryCode = @CountryName
		AND sfp.FileName = @FileName
    AND sfp.PipelineLogID = @PipelineLogId
		

END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
