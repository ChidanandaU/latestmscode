CREATE TABLE [Recon].[EODRecon](
	[SourceReconID] [int] IDENTITY(1,1) NOT NULL,
	[SourceID] [int] NULL,
	[SourceObjectID] [int] NULL,
	[identifier] [nvarchar](500) NULL,
	[SourceQuery] [nvarchar](max) NULL,
	[SourceValue] [bigint] NULL,
	[TargetQuery] [nvarchar](max) NULL,
	[TargetValue] [bigint] NULL,
	[BusinessDate] [datetime] NULL,
	[SourceReconStatus] [nvarchar](500) NULL,
	[LastSourceReconDateTime] [datetime] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [Recon].[EODRecon] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Recon].[EODRecon] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Recon].[EODRecon] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [Recon].[EODRecon] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO