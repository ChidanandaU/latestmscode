CREATE TABLE [Recon].[SourceObjectRecon](
	[SourceObjectID] [int] NULL,
	[identifier] [int] NULL,
	[SourceQuery] [nvarchar](max) NULL,
	[SourceCount] [bigint] NULL,
	[TargetCount] [bigint] NULL,
	[BusinessDate] [datetime] NULL,
	[SourceReconStatus] [nvarchar](500) NULL,
	[LastSourceReconDateTime] [datetime] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[SourceFileProcessLogID] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [Recon].[SourceObjectRecon] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Recon].[SourceObjectRecon] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Recon].[SourceObjectRecon] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [Recon].[SourceObjectRecon] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO