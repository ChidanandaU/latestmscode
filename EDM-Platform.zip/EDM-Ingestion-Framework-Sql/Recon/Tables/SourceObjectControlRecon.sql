CREATE TABLE [Recon].[SourceObjectControlRecon](
	[SourceObjectID] [int] NULL,
	[BusinessDate] [datetime] NULL,
	[SourceCount] [bigint] NULL,
	[TargetCount] [bigint] NULL,
	[ReconStatus] [nvarchar](1000) NULL,
	[LastReconDateTime] [datetime] NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[SourceFileProcessLogID] [int] NULL
) ON [PRIMARY]
GO

ALTER TABLE [Recon].[SourceObjectControlRecon] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Recon].[SourceObjectControlRecon] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Recon].[SourceObjectControlRecon] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [Recon].[SourceObjectControlRecon] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO