CREATE PROCEDURE [Recon].[uspInsertEODRecon]
( 
	@SourceId int,
	@SourceObjectId [int] ,
	@Identifier nvarchar(500),
	@SourceQuery nvarchar(max),
	@SourceValue bigint,
	@TargetQuery nvarchar(max),
	@TargetValue bigint,
	@BusinessDate datetime,
	@SourceReconStatus nvarchar(500),
	@LastSourceReconDateTime datetime
)
AS 
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[Recon].[uspInsertEODRecon]
		Script Date:			2021-06-01
		Author:					Santhosh Boyapally	
		Test Execute:			This SP is used to insert EOD recon
		CMD:					EXEC [Recon].[uspInsertEODRecon] 
								@SourceId = <Value>,
								@SourceObjectId = <Value>,
								@Identifier = <Value>,
								@SourceQuery = <Value>,
								@SourceValue = <Value>,
								@TargetQuery = <Value>,
								@TargetValue = <Value>,
								@BusinessDate = <Value>,
								@SourceReconStatus = <Value>,
								@LastSourceReconDateTime = <Value>
******/
-----------------------------------------------------------------------------------------------------------------------

BEGIN
	
	SET NOCOUNT ON;

		INSERT INTO [Recon].[EODRecon]
           ([SourceID]
           ,[SourceObjectID]
           ,[identifier]
           ,[SourceQuery]
           ,[SourceValue]
           ,[TargetQuery]
           ,[TargetValue]
           ,[BusinessDate]
           ,[SourceReconStatus]
           ,[LastSourceReconDateTime]
           )
     VALUES
           (@SourceId
           ,@SourceObjectId
           ,@Identifier
           ,@SourceQuery
           ,@SourceValue
           ,@TargetQuery
           ,@TargetValue
           ,@BusinessDate
           ,@SourceReconStatus
           ,@LastSourceReconDateTime
			)

END