﻿:r .\PoolConfig.PostDeployment.sql
:r .\ClusterConfig.PostDeployment.sql