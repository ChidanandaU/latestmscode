﻿SET NOCOUNT ON;
SET IDENTITY_INSERT [metadata].[PoolConfig] ON;

MERGE INTO [metadata].[PoolConfig] AS [TARGET]
USING
(
	VALUES
		(1, N'GeneralPurposeDS3V2LandingtoRawPools', N'Standard_D16s_v3', N'7.3.x-scala2.12', 10, 50, 1)

) AS [Source] ([PoolConfigurationID], [PoolName], [InstanceType], [PoolDatabricksRuntimeVersion], [PoolMinIdle], [PoolMaxCapacity],[IsLandingToRaw])
ON [Target].PoolName = [Source].PoolName

WHEN MATCHED THEN UPDATE
SET
[Target].InstanceType					= [Source].InstanceType,
[Target].[PoolDatabricksRuntimeVersion] = [Source].[PoolDatabricksRuntimeVersion],
[Target].[PoolMinIdle]					= [Source].[PoolMinIdle],
[Target].[PoolMaxCapacity]				= [Source].[PoolMaxCapacity],
[Target].[IsLandingToRaw]				= [Source].[IsLandingToRaw],
[Target].ModifiedOn						= GETUTCDATE(),
[Target].ModifiedBy						= SUSER_NAME()
WHEN NOT MATCHED THEN INSERT
(
[PoolConfigurationID],
[PoolName],
[InstanceType],
[PoolDatabricksRuntimeVersion],
[PoolMinIdle],
[PoolMaxCapacity],
[IsLandingToRaw],
[CreatedBy],
[CreatedOn]
)
VALUES
(
[Source].[PoolConfigurationID],
[Source].[PoolName],
[Source].[InstanceType],
[Source].[PoolDatabricksRuntimeVersion],
[Source].[PoolMinIdle],
[Source].[PoolMaxCapacity],
[Source].[IsLandingToRaw],
SUSER_NAME(),
GETUTCDATE()
);

DECLARE @mergeError INT
 , @mergeCount INT
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF @mergeError != 0
 BEGIN
 PRINT 'ERROR OCCURRED IN MERGE FOR [metadata].[PoolConfig]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100));
 END
ELSE
 BEGIN
 PRINT '[metadata].[PoolConfig] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
 END
GO

SET IDENTITY_INSERT [metadata].[PoolConfig] OFF
SET NOCOUNT OFF
GO