﻿SET NOCOUNT ON;
SET IDENTITY_INSERT [metadata].[ClusterConfig] ON;

MERGE INTO [metadata].[ClusterConfig] AS [TARGET]
USING
(
	VALUES
		(1, 1, N'Standard_DS3_v2-ExistingInstancePool', N'ExisingInstancePool', N'Standard_D16s_v3', N'7.3.x-scala2.12', N'Standard_D16s_v3', 2, 4, 10, NULL, NULL)

) AS [Source] ([ClusterConfigurationID], [PoolConfigurationID], [ClusterConfigurationName], [ClusterType], [ClusterDriverType], [ClusterVersion], [ClusterNodeType], [ClusterMinNodes], [ClusterMaxNodes], [AutoTerminationMinutes], [SparkEnvVars], [Libraries])
ON [Target].[ClusterConfigurationName] = [Source].[ClusterConfigurationName]
AND [Target].[PoolConfigurationID] = [Source].[PoolConfigurationID]

WHEN MATCHED THEN UPDATE
SET
[Target].[ClusterType]					= [Source].[ClusterType],
[Target].[ClusterDriverType]			= [Source].[ClusterDriverType],
[Target].[ClusterVersion]				= [Source].[ClusterVersion],
[Target].[ClusterNodeType]				= [Source].[ClusterNodeType],
[Target].[ClusterMinNodes]				= [Source].[ClusterMinNodes],
[Target].[ClusterMaxNodes]				= [Source].[ClusterMaxNodes],
[Target].[AutoTerminationMinutes]		= [Source].[AutoTerminationMinutes],
[Target].[SparkEnvVars]					= [Source].[SparkEnvVars],
[Target].[Libraries]					= [Source].[Libraries],
[Target].[ModifiedOn]					= GETUTCDATE(),
[Target].[ModifiedBy]					= SUSER_NAME()
WHEN NOT MATCHED THEN INSERT
(
	[ClusterConfigurationID], 
	[PoolConfigurationID], 
	[ClusterConfigurationName], 
	[ClusterType], 
	[ClusterDriverType], 
	[ClusterVersion], 
	[ClusterNodeType], 
	[ClusterMinNodes], 
	[ClusterMaxNodes], 
	[AutoTerminationMinutes], 
	[SparkEnvVars], 
	[Libraries],
	[CreatedOn],
	[CreatedBy]
)

VALUES
(
	[Source].[ClusterConfigurationID], 
	[Source].[PoolConfigurationID], 
	[Source].[ClusterConfigurationName], 
	[Source].[ClusterType], 
	[Source].[ClusterDriverType], 
	[Source].[ClusterVersion], 
	[Source].[ClusterNodeType], 
	[Source].[ClusterMinNodes], 
	[Source].[ClusterMaxNodes], 
	[Source].[AutoTerminationMinutes], 
	[Source].[SparkEnvVars], 
	[Source].[Libraries],
	GETUTCDATE(),
	SUSER_NAME()
);

DECLARE @mergeError INT
 , @mergeCount INT
SELECT @mergeError = @@ERROR, @mergeCount = @@ROWCOUNT
IF @mergeError != 0
 BEGIN
 PRINT 'ERROR OCCURRED IN MERGE FOR [metadata].[ClusterConfig]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100));
 END
ELSE
 BEGIN
 PRINT '[metadata].[ClusterConfig] rows affected by MERGE: ' + CAST(@mergeCount AS VARCHAR(100));
 END
GO

SET IDENTITY_INSERT [metadata].[ClusterConfig] OFF
SET NOCOUNT OFF
GO