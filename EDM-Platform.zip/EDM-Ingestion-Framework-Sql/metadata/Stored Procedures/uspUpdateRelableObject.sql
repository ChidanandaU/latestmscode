CREATE PROCEDURE [Metadata].[uspUpdateRelableObject]
@SourceName Nvarchar(200),
@CountryCode Nvarchar(200),
@RenameProperties Nvarchar(max)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[Metadata].[uspUpdateRelableObject]
		Script Date:			2021-05-24 
		Author:					Vikash Jangid
		Test Execute:			This SP is used to insert or update records into the RenameObject Table.
		CMD:					EXEC [metadata].[uspInsertRenameObject] 
								@ObjectName = <value>, @RenamedBy=<value>
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN 
	BEGIN TRY
		    UPDATE [Metadata].[RelableObject] 
		    set [RenameProperties]  = REPLACE(REPLACE(@RenameProperties,'[',''),']',''), 
			    ModifiedOn=Getdate()   
			where [SourceName] = @SourceName 
			  and [CountryCode]=@CountryCode
		
		IF NOT EXISTS (SELECT TOP 1 1 FROM [Metadata].[RelableObject] WHERE [SourceName] = @SourceName and [CountryCode]=@CountryCode)
		BEGIN
			INSERT INTO [Metadata].[RelableObject]
		           (
				   [SourceName],
				   [CountryCode]
		           ,[RenameProperties]
		           )
		     VALUES
		           (
				   @SourceName
		           ,@CountryCode
				   ,@RenameProperties
		           )
		END
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
			)
	END CATCH
END