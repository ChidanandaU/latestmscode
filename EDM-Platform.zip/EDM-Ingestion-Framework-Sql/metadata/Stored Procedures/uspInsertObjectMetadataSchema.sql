CREATE PROCEDURE [Metadata].[uspInsertObjectMetadataSchema]
@SourceObjectMetadataSchema [metadata].TableType_SourceObjectMetadataSchema READONLY
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspInsertObjectMetadataSchema]
		Script Date:			2021-06-14
		Author:					Vikash Jangid
		Test Execute:			This SP is used to insert or update records into the SourceObjectMetadataSchema Table.
		CMD:					EXEC [metadata].[uspInsertObjectMetadataSchema] 
								@SourceObjectMetadataSchema = @TableTypeParameter
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
		DECLARE @Source NVARCHAR(50)
		DECLARE @Country NVARCHAR(50)
		DECLARE @ObjectName NVARCHAR(100)

		SELECT @Source = [Source] FROM @SourceObjectMetadataSchema
		SELECT @Country = Country FROM @SourceObjectMetadataSchema
		SELECT @ObjectName = ObjectName FROM @SourceObjectMetadataSchema

		DECLARE @SourceObjectID INT
		SELECT @SourceObjectID = sod.SourceObjectID 
		FROM Metadata.SourceMaster sm
		INNER JOIN Metadata.SourceObjectDetail sod ON sm.SourceID = sod.SourceID
		WHERE sm.SourceName = @Source 
		AND sm.CountryCode = @Country 
		AND sod.ObjectName = @ObjectName

		-- if column deleted from source.
		UPDATE Metadata.SourceObjectMetadataSchema
		SET
		IsActive = 0,
		ColumnOrder = -1,
		IsSchemaEvolved = 1
		WHERE SourceObjectID = @SourceObjectID
		AND ColumnName NOT IN (SELECT ColumnName FROM @SourceObjectMetadataSchema)
		AND IsActive = 1;

		MERGE INTO metadata.SourceObjectMetadataSchema As Tar
		USING
		(
			SELECT 
			ColumnName,
			ColumnOrder,
			DataType,
			IsPrimaryKey,
			Width,
			[Length],
			Rules as [Rule],
			SourceDataType,
			IsNullable,
			IsActive,
			SchemaType
			FROM @SourceObjectMetadataSchema
		)As Src
		ON Tar.SourceObjectID = @SourceObjectID
		AND Tar.ColumnName = Src.ColumnName
		AND Tar.SchemaType = Src.SchemaType

		WHEN MATCHED AND (
		Tar.ColumnOrder		!= Src.ColumnOrder OR
		Tar.DataType		!= Src.DataType OR
		Tar.IsPrimaryKey	!= Src.IsPrimaryKey OR
		Tar.IsActive		!= Src.IsActive OR
		Tar.Width			!= Src.Width OR
		Tar.[Rule]			!= Src.[Rule] OR
		Tar.SourceDataType	!= Src.SourceDataType OR
		Tar.IsNullable		!= Src.IsNullable OR
		Tar.SchemaType		!= Src.SchemaType OR
		Tar.[Length]		!= Src.[Length]
	)
		THEN UPDATE
		SET
		Tar.ColumnOrder		= Src.ColumnOrder,
		Tar.DataType		= Src.DataType,
		Tar.IsPrimaryKey	= Src.IsPrimaryKey,
		Tar.IsActive		= Src.IsActive,
		Tar.Width			= Src.Width,
		Tar.[Rule]			= Src.[Rule],
		Tar.SourceDataType	= Src.SourceDataType,
		Tar.IsNullable		= Src.IsNullable,
		Tar.IsSchemaEvolved = 1,
		Tar.ModifiedBy		= suser_name(),
		Tar.ModifiedOn		= GETUTCDATE(),
		Tar.SchemaType		= Src.SchemaType,
		Tar.[Length]		= Src.[Length]


		WHEN NOT MATCHED THEN INSERT
		(
			 [SourceObjectID]
			,[ColumnName]
			,[ColumnOrder]
			,[SourceDataType]
			,[DataType]
			,[IsPrimaryKey]
			,[ColumnFormat]
			,[IsNullable]
			,[IsActive]
			,[IsSchemaEvolved]
			,[Width]
			,[Length]
			,[Rule]
			,[CreatedBy]
			,[CreatedOn]
			,[SchemaType]
		)
		VALUES
		(
			@SourceObjectID,
			Src.ColumnName,
			Src.ColumnOrder,
			Src.SourceDataType,
			Src.DataType,
			Src.IsPrimaryKey,
			NULL,
			Src.IsNullable,
			Src.IsActive,
			0,
			Src.Width,
			Src.[Length],
			Src.[Rule],
			suser_name(),
			GETUTCDATE(),
			Src.SchemaType
		);
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
