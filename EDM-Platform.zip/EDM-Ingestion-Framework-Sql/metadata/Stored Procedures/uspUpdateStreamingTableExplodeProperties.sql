
CREATE PROCEDURE [Metadata].[uspUpdateStreamingTableExplodeProperties]
@RealTimeMetastore [Metadata].TableType_RealTimeIngestion READONLY 
AS 
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspUpdateStreamingTableExplodeProperties]
		Script Date:			2021-04-06 
		Author:					Priyanka Bariki
		Test Execute:			This SP is used to insert or update records into the [StreamingTableExplodeProperties] Table.
		CMD:					EXEC [metadata].[uspUpdateStreamingTableExplodeProperties]
								@RealTimeMetastore= '<value>'
******/
-----------------------------------------------------------------------------------------------------------------------

BEGIN 
    BEGIN TRY  
	     SELECT 
		     STD.ID AS TargetTableID,
			 RTM.ExplodeColumnSequence,
			 RTM.ExplodeColumnJsonPath,
			 RTM.NestedObjectType,
			 suser_name() AS CreatedBy,
		     GETUTCDATE() AS CreatedOn
        INTO #temp
		FROM @RealTimeMetastore  RTM
		          
				  JOIN [Metadata].[StreamingSourceDetails] SSD    ON RTM.StreamingSource = SSD.StreamingSource 				  
		          JOIN [Metadata].[StreamingEDMPTableDetails] STD ON RTM.TargetTableName= STD.TargetTableName	
				  AND STD.StreamingSourceID=SSD.ID
		DELETE FROM [Metadata].[StreamingTableExplodeProperties]
		WHERE TargetTableID IN (Select TargetTableID FROM #temp)
		
	INSERT INTO [Metadata].[StreamingTableExplodeProperties]
	( 
		TargetTableID
		,ExplodeColumnSequence
		,ExplodeColumnJsonPath
		,NestedObjectType
		,ExplodeMode
		,CreatedBy
		,CreatedOn
	)
		
	SELECT TargetTableID, ExplodeColumnSequence,ExplodeColumnJsonPath,NestedObjectType,NULL,CreatedBy,CreatedOn
	FROM #temp
    END TRY
    BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END 