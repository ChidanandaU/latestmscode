CREATE PROCEDURE [Metadata].[uspGetTableExplodeProperties]
@SourceName NVARCHAR(100),
@TargetTableName NVARCHAR(100)

AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspGetTableExplodeProperties]
		Script Date:			2021-08-06 
		Author:					Priyanka Bariki
		Test Execute:			This SP is used to GET Table explode Properties 
		CMD:					EXEC [metadata].[uspGetTableExplodeProperties]
								@SourceName= '<value>',@TargetTableName='<value>'
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN 
  BEGIN TRY
   SELECT DISTINCT 
   StreamingSource,
   STD.TargetTableName,
   SEP.ExplodeColumnSequence,
   SEP.ExplodeColumnJsonPath,
   SEP.NestedObjectType
   FROM Metadata.StreamingSourceDetails SSD
   INNER JOIN Metadata.StreamingEDMPTableDetails STD ON SSD.ID=STD.StreamingSourceID
   INNER JOIN Metadata.StreamingTableExplodeProperties SEP ON STD.ID= SEP.TargetTableID
   WHERE SSD.StreamingSource=@SourceName AND STD.TargetTableName=@TargetTableName  
 END TRY
 
 BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
					SELECT ERROR_MESSAGE()
					)
				,@ErrorSeverity INT = ERROR_SEVERITY()
				,@ErrorState INT = ERROR_STATE()

			RAISERROR (
					@Errmsg
					,@ErrorSeverity
					,@ErrorState
					)
	END CATCH
 END
