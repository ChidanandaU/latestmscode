CREATE PROCEDURE [Metadata].[uspUpdateEventHubSchemaRegistryMaster]
@SchemaName NVARCHAR(100),
@SchemaGuid NVARCHAR(50),
@AdlsFilePath NVARCHAR(255)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspUpdateEventHubSchemaRegistryMaster]
		Script Date:			2021-02-06 
		Author:					Divye Rastogi
		Test Execute:			This SP is used to insert or update records into the EventHubSchemaRegistryMaster Table.
		CMD:					EXEC [metadata].[uspUpdateEventHubSchemaRegistryMaster]
								@SchemaName = '<value>', @SchemaGuid='<value>', @AdlsFilePath='<value>'
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
		MERGE INTO [metadata].[EventHubSchemaRegistryMaster] AS Tar
		USING
		(
			SELECT 
			@SchemaName AS SchemaName,
			@SchemaGuid AS SchemaGuid,
			@AdlsFilePath AS AdlsFilePath
		) As Src
		ON 
		Tar.SchemaName = Src.SchemaName

		WHEN MATCHED THEN UPDATE
		SET
		Tar.SchemaGuid = Src.SchemaGuid,
		Tar.AdlsFilePath = Src.AdlsFilePath,
		Tar.IsActive = 1,
		Tar.ModifiedBy = suser_name(),
		Tar.ModifiedOn = GETUTCDATE()

		WHEN NOT MATCHED THEN INSERT
		(
			SchemaName,
			SchemaGuid,
			AdlsFilePath,
			IsActive,
			CreatedBy,
			CreatedOn
		)
		VALUES
		(
			Src.SchemaName,
			Src.SchemaGuid,
			Src.AdlsFilePath,
			1,
			suser_name(),
			GETUTCDATE()
		);

	UPDATE src
	SET src.SourceStreamingID = sod.ID
	FROM metadata.[EventHubSchemaRegistryMaster] src
	INNER JOIN metadata.StreamingSourceDetails sod ON src.SchemaName = sod.StreamingSource
	WHERE src.SchemaName = @SchemaName

	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END