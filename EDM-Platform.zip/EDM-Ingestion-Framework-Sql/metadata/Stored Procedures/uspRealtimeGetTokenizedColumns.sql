CREATE PROCEDURE [Metadata].[uspRealtimeGetTokenizedColumns] 
    @TargetTableName nvarchar(100), 
    @StreamingSource nvarchar(100)
AS  
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[Metadata].[uspRealtimeGetTokenizedColumns] 
		Script Date:			06/22/2021 
		Author:					Saurav Misra
		Purpose:			    This SP is used to tokenize sensitive columns from realtime ingestion tables.
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN  
DECLARE @columnname nvarchar(max)
SELECT @columnname=
	Coalesce(@columnname+','+
		(CASE WHEN targetColumn.isTokenizable=1 AND targetColumn.TokenizationAlgorithm is not null   
         THEN CONCAT('ptyProtectString',  
             '('  
             ,targetColumn.columnName  
             ,','''  
             ,targetColumn.TokenizationAlgorithm  
             ,''') AS '+targetColumn.columnName  
             )   
          ELSE targetColumn.columnName  
          END),  
        (CASE WHEN targetColumn.isTokenizable=1 AND targetColumn.TokenizationAlgorithm is not null   
        THEN CONCAT('ptyProtectString',  
         '('  
         ,targetColumn.columnName  
         ,','''  
         ,targetColumn.TokenizationAlgorithm  
         ,''') AS '+targetColumn.columnName  
         )   
         ELSE targetColumn.columnName  
         END))  
FROM 
	[Metadata].[StreamingEDMPColumnDetails] AS targetColumn  
	JOIN [Metadata].[StreamingEDMPTableDetails] AS targetTable  
		ON targetColumn.TargetTableID = targetTable.ID
	JOIN [Metadata].[StreamingSourceDetails] source
		ON source.ID = targetTable.StreamingSourceID
WHERE 
	targetTable.[TargetTableName] = @TargetTableName
	AND source.StreamingSource = @StreamingSource
	AND targetColumn.IsActive=1   
ORDER BY ColumnOrder asc;

SELECT @columnname as [TokenizedColumnList]
END  
