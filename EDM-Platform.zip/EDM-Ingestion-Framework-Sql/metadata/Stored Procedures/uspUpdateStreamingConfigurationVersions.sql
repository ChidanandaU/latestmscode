CREATE PROCEDURE [Metadata].[uspUpdateStreamingConfigurationVersions]
@ConfigurationName nvarchar(100),
@VersionNumber nvarchar(100)
AS 
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspUpdateStreamingConfigurationVersions]
		Script Date:			2021-03-06 
		Author:					Priyanka Bariki
		Test Execute:			This SP is used to insert or update records into the StreamingConfigurationVersions Table.
		CMD:					EXEC [metadata].[uspUpdateStreamingConfigurationVersions]
								@ConfigurationName = '<value>', @VersionNumber
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN 
    BEGIN TRY

    	DECLARE @ConfigurationID INT
    	SET  @ConfigurationID=(select ID from [Metadata].[StreamingConfigurations]
		  		                        WHERE Configuration=@ConfigurationName)


    	DECLARE @LatestVersion nvarchar(100)
		SET @LatestVersion = (select Version from [Metadata].StreamingConfigurationVersions
		  		                        WHERE ConfigurationID=@ConfigurationID and IsActive=1)

        IF (isnull(@LatestVersion,'') !=@VersionNumber)
		  BEGIN
            INSERT INTO [Metadata].[StreamingConfigurationVersions]
		      (  
			  
		  	    [Version],
		  		ConfigurationID,
		  		IsActive,
		  		VersionStartDate,
		  		VersionExpiryDate,
		  		CreatedBy,
		  		CreatedOn
		  	  )
		  	VALUES
		  	(
		  	    @VersionNumber,
		  		@ConfigurationID,
		  		1,
		  		CAST(GETUTCDATE() AS DATE),
		  		'9999-12-31',
		  		suser_name(),
		  		GETUTCDATE()
		  	)


		  	UPDATE [Metadata].[StreamingConfigurationVersions]

		  	SET isActive=0 
		  	   ,VersionExpiryDate=CAST(GETUTCDATE() AS DATE)

		  	Where [Version]=@LatestVersion
		END
    END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END