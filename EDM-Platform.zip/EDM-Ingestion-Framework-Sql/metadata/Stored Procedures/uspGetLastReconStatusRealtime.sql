CREATE PROCEDURE [Metadata].[uspGetLastReconStatusRealtime]  
@Input metadata.TableType_RealTimeIngestion READONLY  
AS  
-----------------------------------------------------------------------------------------------------------------------    
/****** StoredProcedure:  [recon].[uspGetLastReconStatusRealtime]  
  Script Date:   2021-07-06     
  Author:     Divye Rastogi    
  Test Execute:   This SP is used to get the last recon status for the list of tables supplied  
  CMD:     EXEC [recon].[uspGetLastReconStatusRealtime]  
        @Input= '<value>'    
******/    
-----------------------------------------------------------------------------------------------------------------------    
BEGIN   
 BEGIN TRY  
 SELECT   
 A.TargetTableName,  
 A.ReconDate AS LastReconDate,  
 A.IsReconSkipped,  
 A.IsReconSuccessful  
 FROM   
 ( SELECT   
  src.TargetTableName,  
  rec.ReconDate,  
  rec.IsReconSkipped,  
  rec.IsReconSuccessful,  
  ROW_NUMBER() OVER (PARTITION BY rec.TargetTableID ORDER BY rec.ReconDate DESC,rec.CreatedOn DESC) as rn  
  FROM @Input Src  
  INNER JOIN Metadata.StreamingEDMPTableDetails td ON src.TargetTableName = td.TargetTableName  
  INNER JOIN recon.StreamingTableReconciliation rec ON rec.TargetTableID = td.ID  
 )A WHERE rn = 1  
 END TRY  
  
 BEGIN CATCH  
   DECLARE @Errmsg NVARCHAR(4000) = (    
   SELECT ERROR_MESSAGE() )    
  ,@ErrorSeverity INT = ERROR_SEVERITY()    
  ,@ErrorState INT = ERROR_STATE()    
    
  RAISERROR (    
    @Errmsg    
    ,@ErrorSeverity    
    ,@ErrorState    
    )   
 END CATCH  
END