﻿CREATE PROCEDURE [metadata].[uspRetrieveTokenizedColumns] 
@objectname nvarchar(1000),
@source nvarchar(100),
@country nvarchar(100)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspRetrieveTokenizedColumns] 
		Script Date:			2021-05-24 
		Author:					Vikash Jangid
		Test Execute:			This SP is used to retrieve tokenized column Select string from Schema Object.
		CMD:					EXEC [metadata].[uspRetrieveTokenizedColumns] 
								@objectname = <value>, @source=<value>, @country = <value>
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
		DECLARE @columnname nvarchar(max)
		SET @columnname = ''
		SELECT @columnname=@columnname+','+(CASE WHEN colschema.istokenizable=1 
														 AND colschema.TokenizationAlgorithm is not null
														 AND colschema.TokenizationFunction is not null
														THEN CONCAT(colschema.TokenizationFunction,
															'('
															,colschema.columnName
															,','''
															,colschema.TokenizationAlgorithm
															,''') AS '+colschema.columnName
															)	
														  ELSE colschema.columnName
														  END)
		  FROM  [Metadata].[SourceObjectSchema]  AS colschema
		  JOIN [Metadata].[SourceObjectdetail] AS SourceObject
		    ON colschema.SourceObjectID=SourceObject.SourceObjectId
		  JOIN [Metadata].[SourceMaster] AS SourceMaster
			ON SourceObject.SourceID = SourceMaster.SourceId
		  WHERE SourceObject.OBJECTNAME=@objectname
			AND SourceMaster.SourceName = @Source
			AND SourceMaster.CountryCode = @country
		    AND colschema.IsActive=1 
		    order by ColumnOrder asc

		SELECT @columnname as TokenizedColumnString
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
			)
	END CATCH
END
GO


