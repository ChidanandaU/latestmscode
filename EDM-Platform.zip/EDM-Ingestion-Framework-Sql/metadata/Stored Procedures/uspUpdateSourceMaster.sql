CREATE PROCEDURE [Metadata].[uspUpdateSourceMaster]
@SourceName NVARCHAR(100),
@CountryCode NVARCHAR(100),
@Property NVARCHAR(max)
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspUpdateSourceMaster]
		Script Date:			2021-05-24 
		Author:					Divye Rastogi
		Test Execute:			This SP is used to insert or update records into the SourceMaster Table.
		CMD:					EXEC [metadata].[uspUpdateSourceMaster] 
								@SourceName = <value>, @CountryCode=<value>, @Property=<value>
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
		MERGE INTO [metadata].[SourceMaster] AS Tar
		USING
		(
			SELECT
			@SourceName AS [SourceName],
			@CountryCode AS [CountryCode],
			@Property AS [CountrySourceProperties]
		) AS Src
		ON Tar.SourceName = Src.SourceName
		AND Tar.CountryCode = Src.CountryCode

		WHEN MATCHED THEN UPDATE
		SET
		Tar.CountrySourceProperties = Src.CountrySourceProperties,
		Tar.ModifiedBy = suser_name(),
		Tar.ModifiedOn = GETUTCDATE()

		WHEN NOT MATCHED THEN INSERT
		(
			SourceName,
			CountryCode,
			SourceType,
			CountrySourceProperties,
			IsActive,
			Frequency,
			FrequencyDurationUnit,
			ProjectCode,
			CreatedBy,
			CreatedOn
		)
		VALUES
		(
			Src.SourceName,
			Src.CountryCode,
			'CDC',
			Src.CountrySourceProperties,
			1,
			1,
			'Day',
			'POCProject001',
			suser_name(),
			GETUTCDATE()
		);
	END TRY

	BEGIN CATCH
	DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
