CREATE PROCEDURE [Metadata].[uspUpdateStreamingEDMPTableDetails]
@RealTimeMetastore [Metadata].[TableType_RealTimeIngestion] READONLY 
AS 
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspUpdateStreamingEDMPTableDetails]
		Script Date:			2021-03-06 
		Author:					Priyanka Bariki
		Test Execute:			This SP is used to insert or update records into the StreamingEDMPTableDetails Table.
		CMD:					EXEC [metadata].[uspUpdateStreamingEDMPTableDetails]
								@RealTimeMetastore = '<value>',
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN 
    
    BEGIN TRY
	
		MERGE INTO [metadata].[StreamingEDMPTableDetails] AS Tar
			USING
			(
				SELECT RTM.TargetTableName AS TargetTableName,
					   SCD.ID AS StreamingSourceID,
					   RTM.HasExplode AS HasExplode
				from @RealTimeMetastore  RTM
				JOIN [Metadata].[StreamingSourceDetails] SCD ON
				RTM.StreamingSource = SCD.[StreamingSource]
			) As Src
			ON 
			Tar.StreamingSourceID = Src.StreamingSourceID AND Tar.TargetTableName=Src.TargetTableName
			WHEN MATCHED  THEN UPDATE 
			SET 
			Tar.HasExplode=Src.HasExplode,
			Tar.ModifiedBy = suser_name(),
			Tar.ModifiedOn = GETUTCDATE()

			WHEN NOT MATCHED THEN INSERT
			(
				[TargetTableName],
				[StreamingSourceID],
				[HasExplode],
				CreatedBy,
				CreatedOn
			)
			VALUES
			(
				Src.[TargetTableName],
				Src.[StreamingSourceID],
				Src.[HasExplode],
				suser_name(),
				GETUTCDATE()
			);
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH

END