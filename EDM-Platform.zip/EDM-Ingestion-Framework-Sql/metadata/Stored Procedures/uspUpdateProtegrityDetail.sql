CREATE PROCEDURE [Metadata].[uspUpdateProtegrityDetail]
@ProtegritySchema [metadata].TableType_ProtegritySchema READONLY
AS
-----------------------------------------------------------------------------------------------------------------------
/****** StoredProcedure:		[metadata].[uspUpdateProtegrityDetail]
		Script Date:			2021-07-23 
		Author:					Sonam Jain
		Test Execute:			This SP is used to update protegrity details in SourceObjectSchema
		CMD:					EXEC [metadata].[uspUpdateProtegrityDetail] 
								@ProtegritySchema = @TableTypeParameter
******/
-----------------------------------------------------------------------------------------------------------------------
BEGIN
	BEGIN TRY
		DECLARE @Source NVARCHAR(50)
		DECLARE @Country NVARCHAR(50)
		DECLARE @ObjectName NVARCHAR(100)

		SELECT @Source = [Source] FROM @ProtegritySchema
		SELECT @Country = Country FROM @ProtegritySchema
		SELECT @ObjectName = ObjectName FROM @ProtegritySchema

		DECLARE @SourceObjectID INT
		
		SELECT @SourceObjectID = sod.SourceObjectID 
		FROM Metadata.SourceMaster sm
		INNER JOIN Metadata.SourceObjectDetail sod ON sm.SourceID = sod.SourceID
		WHERE sm.SourceName = @Source 
		AND sm.CountryCode = @Country 
		AND sod.ObjectName = @ObjectName

		MERGE INTO metadata.SourceObjectSchema As Tar
		USING
		(
			SELECT 
				SourceColumnName,
				IsTokenizable,
				TokenizationAlgorithm,
				TokenizationFunction
			FROM @ProtegritySchema
		)As Src
		ON Tar.SourceObjectID = @SourceObjectID
		AND Tar.ColumnName = Src.SourceColumnName

		WHEN MATCHED 
		THEN UPDATE
		SET
		Tar.IsTokenizable				= CASE Src.IsTokenizable WHEN 'Y' THEN 1 ELSE 0 END,
		Tar.TokenizationAlgorithm		= Src.TokenizationAlgorithm,
		Tar.TokenizationFunction		= Src.TokenizationFunction,
		Tar.ModifiedBy		= suser_name(),
		Tar.ModifiedOn		= GETUTCDATE();
	END TRY

	BEGIN CATCH
		DECLARE @Errmsg NVARCHAR(4000) = (
				SELECT ERROR_MESSAGE()
				)
			,@ErrorSeverity INT = ERROR_SEVERITY()
			,@ErrorState INT = ERROR_STATE()

		RAISERROR (
				@Errmsg
				,@ErrorSeverity
				,@ErrorState
				)
	END CATCH
END
