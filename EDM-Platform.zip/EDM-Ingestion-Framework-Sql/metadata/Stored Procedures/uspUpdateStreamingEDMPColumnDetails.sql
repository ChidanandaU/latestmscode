CREATE PROCEDURE [Metadata].[uspUpdateStreamingEDMPColumnDetails]    
@RealTimeMetastore [Metadata].TableType_RealTimeIngestion READONLY     
AS     
    
-----------------------------------------------------------------------------------------------------------------------    
/****** StoredProcedure:  [metadata].[uspUpdateStreamingEDMPColumnDetails]    
  Script Date:   2021-04-06     
  Author:     Priyanka Bariki    
  Test Execute:   This SP is used to insert or update records into the [StreamingEDMPColumnDetails] Table.    
  CMD:     EXEC [metadata].[uspUpdateStreamingEDMPColumnDetails]    
        @RealTimeMetastore= '<value>',@ConfigurationName = '<value>'    
******/    
-----------------------------------------------------------------------------------------------------------------------    
BEGIN    
    
  BEGIN TRY    
  DECLARE @ConfigurationName NVARCHAR(100)    
  SELECT @ConfigurationName = ConfigurationName FROM @RealTimeMetastore    
  DECLARE @ConfigurationID BIGINT    
      SET  @ConfigurationID=(select ID from [Metadata].[StreamingConfigurations]    
                             WHERE Configuration=@ConfigurationName)    
  DECLARE @LatestVersionID BIGINT    
   SET @LatestVersionID = (select ID from [Metadata].StreamingConfigurationVersions    
                             WHERE ConfigurationID=@ConfigurationID and IsActive=1)    
  
  
DROP TABLE IF EXISTS #TempEdmpColumnDetails  
SELECT SCD.* INTO #TempEdmpColumnDetails   
FROM @RealTimeMetastore RTM  
INNER JOIN metadata.[StreamingSourceDetails] SSD on RTM.StreamingSource = SSD.StreamingSource    
INNER JOIN [Metadata].[StreamingEDMPTableDetails] STD ON RTM.TargetTableName= STD.TargetTableName    
AND SSD.ID = STD.StreamingSourceID    
INNER JOIN [metadata].[StreamingEDMPColumnDetails] SCD ON STD.ID= SCD.TargetTableID  
  
  
DROP TABLE IF EXISTS #TempDeletedColumns  
SELECT SCD.ID INTO #TempDeletedColumns  
FROM @RealTimeMetastore RTM    
INNER JOIN metadata.[StreamingSourceDetails] SSD on RTM.StreamingSource = SSD.StreamingSource    
INNER JOIN [Metadata].[StreamingEDMPTableDetails] STD ON RTM.TargetTableName= STD.TargetTableName    
AND SSD.ID = STD.StreamingSourceID    
RIGHT JOIN #TempEdmpColumnDetails  SCD ON RTM.ColumnName=SCD.ColumnName AND STD.ID= SCD.TargetTableID  
WHERE RTM.StreamingSource IS NULL   
  
 UPDATE SCD SET  
 SCD.IsActive = 0,    
 SCD.ColumnOrder =-1,    
 SCD.IsSchemaEvolved = 1 ,  
 SCD.IsSchemaEvolvedStandardized = 1  
 FROM #TempDeletedColumns src  
 INNER JOIN metadata.StreamingEDMPColumnDetails SCD on src.ID = SCD.ID  
    
    
  ----Update Scenario-------------    
MERGE INTO [metadata].[StreamingEDMPColumnDetails] AS Tar    
  USING    
  (    
   SELECT     
          STD.StreamingSourceID AS StreamingSourceID,    
          RTM.ColumnName AS ColumnName,    
          STD.ID AS TargetTableID,    
       RTM.ColumnOrder AS ColumnOrder,    
       RTM.SourceDataType AS SourceDataType,    
       RTM.DestDataType AS DestDataType,    
       RTM.IsPrimaryKey AS IsPrimaryKey,    
       RTM.PkSequenceNumber AS PkSequenceNumber,    
       RTM.[Length] AS [Length],    
       RTM.IsNullable AS IsNullable,    
       RTM.JsonTag AS JsonTag,    
       RTM.IsExploded AS IsExploded,    
       RTM.IsActive AS IsActive,    
       1 AS IsSchemaEvolved,    
       RTM.IsTokenizable AS IsTokenizable,    
       RTM.TokenizationAlgorithm AS TokenizationAlgorithm,  
    RTM.TokenizationFunction AS TokenizationFunction  
    FROM @RealTimeMetastore  RTM    
      JOIN [Metadata].[StreamingEDMPTableDetails] STD ON RTM.TargetTableName= STD.TargetTableName     
      JOIN [Metadata].[StreamingSourceDetails] SSD    ON RTM.StreamingSource = SSD.StreamingSource     
      AND STD.StreamingSourceID=SSD.ID    
    
   ) AS Src    
  ON Tar.ColumnName = Src.ColumnName and Tar.TargetTableID =Src.TargetTableID  
  
  WHEN  MATCHED AND (    
      
  Tar.ColumnOrder             !=Src.ColumnOrder       OR    
  Tar.SourceDataType       !=Src.SourceDataType  OR    
  Tar.DestDataType    !=Src.DestDataType   OR    
  Tar.IsPrimaryKey    !=Src.IsPrimaryKey   OR    
  Tar.PkSequenceNumber   !=Src.PkSequenceNumber  OR    
  Tar.[Length]     !=Src.[Length]    OR    
  Tar.IsNullable        !=Src.IsNullable   OR    
  Tar.JsonTag     !=Src.JsonTag    OR    
  Tar.IsExploded        !=Src.IsExploded   OR    
  Tar.IsActive     !=Src.IsActive    OR    
  Tar.IsSchemaEvolved   !=Src.IsSchemaEvolved  OR    
  Tar.IsTokenizable    !=Src.IsTokenizable  OR      
  Tar.TokenizationAlgorithm  !=Src.TokenizationAlgorithm OR  
  Tar.TokenizationFunction != Src.TokenizationFunction  
  )    
  THEN  UPDATE     
  SET      
   Tar.ColumnOrder            =Src.ColumnOrder              
  ,Tar.SourceDataType   =Src.SourceDataType       
  ,Tar.DestDataType    =Src.DestDataType        
  ,Tar.IsPrimaryKey    =Src.IsPrimaryKey        
  ,Tar.PkSequenceNumber   =Src.PkSequenceNumber       
  ,Tar.[Length]     =Src.[Length]         
  ,Tar.IsNullable    =Src.IsNullable        
  ,Tar.JsonTag     =Src.JsonTag         
  ,Tar.IsExploded    =Src.IsExploded        
  ,Tar.IsActive     =Src.IsActive         
  ,Tar.IsSchemaEvolved   = CASE WHEN ((Tar.ColumnOrder != Src.ColumnOrder) OR (Tar.SourceDataType != Src.SourceDataType )) THEN 1 ELSE Tar.IsSchemaEvolved END  
  ,Tar.IsSchemaEvolvedStandardized   = CASE WHEN ((Tar.ColumnOrder != Src.ColumnOrder) OR (Tar.SourceDataType != Src.SourceDataType )) THEN 1 ELSE Tar.IsSchemaEvolvedStandardized END  
  ,Tar.IsColumnUpdated = CASE WHEN Tar.[Length]     !=Src.[Length] THEN 1 ELSE Tar.IsColumnUpdated END  
  ,Tar.IsColumnUpdatedStandardized = CASE WHEN Tar.[Length]     !=Src.[Length] THEN 1 ELSE Tar.IsColumnUpdatedStandardized END  
  ,Tar.IsTokenizable    =Src.IsTokenizable        
  ,Tar.TokenizationAlgorithm  =Src.TokenizationAlgorithm    
  ,Tar.TokenizationFunction = Src.TokenizationFunction  
  ,Tar.ConfigurationVersionID =@LatestVersionID    
  ,Tar.ModifiedBy = suser_name()    
  ,Tar.ModifiedOn = GETUTCDATE()    
    
  WHEN NOT MATCHED THEN INSERT    
  (      
      ColumnName    
     ,TargetTableID    
     ,ColumnOrder              
     ,SourceDataType       
     ,DestDataType        
     ,IsPrimaryKey        
     ,PkSequenceNumber       
     ,[Length]         
     ,IsNullable        
     ,JsonTag         
     ,IsExploded        
     ,IsActive         
     ,IsSchemaEvolved  
  ,IsSchemaEvolvedStandardized  
  ,IsColumnUpdated  
  ,IsColumnUpdatedStandardized  
     ,IsTokenizable        
     ,TokenizationAlgorithm    
  ,TokenizationFunction  
     ,ConfigurationVersionID    
     ,CreatedBy    
     ,CreatedOn    
  )    
  VALUES    
  (      
      Src.ColumnName    
     ,Src.TargetTableID    
     ,Src.ColumnOrder              
     ,Src.SourceDataType       
     ,Src.DestDataType       
     ,Src.IsPrimaryKey       
     ,Src.PkSequenceNumber      
     ,Src.[Length]        
     ,Src.IsNullable        
     ,Src.JsonTag        
     ,Src.IsExploded        
     ,Src.IsActive        
     ,Src.IsSchemaEvolved  
  ,Src.IsSchemaEvolved  
  ,0  
  ,0  
     ,Src.IsTokenizable       
     ,Src.TokenizationAlgorithm    
  ,Src.TokenizationFunction  
     ,@LatestVersionID       
     ,suser_name()    
     ,GETUTCDATE()    
  );    
      
    
  --Update with StreamingEDMPColumnDetails with latest VersionId    
    
  UPDATE SCD    
  SET SCD.ConfigurationVersionID=@LatestVersionID    
  FROM @RealTimeMetastore rtm    
  INNER JOIN metadata.[StreamingSourceDetails] ssd on rtm.StreamingSource = ssd.StreamingSource    
        INNER JOIN [Metadata].[StreamingEDMPTableDetails] STD ON RTM.TargetTableName= STD.TargetTableName    
        AND ssd.ID = std.StreamingSourceID    
        INNER JOIN [metadata].[StreamingEDMPColumnDetails] SCD ON RTM.ColumnName=SCD.ColumnName AND STD.ID= SCD.TargetTableID    
  WHERE SCD.IsActive=1    
    
 END TRY    
 BEGIN CATCH    
  DECLARE @Errmsg NVARCHAR(4000) = (    
    SELECT ERROR_MESSAGE()    
    )    
   ,@ErrorSeverity INT = ERROR_SEVERITY()    
   ,@ErrorState INT = ERROR_STATE()    
    
  RAISERROR (    
    @Errmsg    
    ,@ErrorSeverity    
    ,@ErrorState    
    )    
 END CATCH    
END