CREATE TABLE [Metadata].[SourceMaster](
	[SourceID] [int] IDENTITY(1,1) NOT NULL,
	[SourceName] [nvarchar](200) NOT NULL,
	[CountryCode] [nvarchar](200) NOT NULL,
	[SourceType] [nvarchar](200) NOT NULL,
	[CountrySourceProperties] [nvarchar](max) NULL,
	[IsActive] [bit] NOT NULL,
	[Frequency] [int] NOT NULL,
	[FrequencyDurationUnit] [nvarchar](50) NOT NULL,
	[ProjectCode] [nvarchar](100) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[BatchObjectRunCount] [int] NULL,
	[ClusterConfigurationID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[SourceID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [Metadata].[SourceMaster] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[SourceMaster] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [Metadata].[SourceMaster] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [Metadata].[SourceMaster] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO