CREATE TABLE [Metadata].[SourceObjectSchema](
	[SourceObjectSchemaID] [int] IDENTITY(1,1) NOT NULL,
	[SourceObjectID] [int] NOT NULL,
	[ColumnName] [nvarchar](200) NOT NULL,
	[ColumnOrder] [int] NOT NULL,
	[DataType] [nvarchar](100) NOT NULL,
	[IsPrimaryKey] [bit] NOT NULL,
	[ColumnFormat] [nvarchar](200) NULL,
	[IsActive] [bit] NULL,
	[IsSchemaEvolved] [bit] NULL,
	[Length] [smallint] NULL,
	[Width] [smallint] NULL,
	[Rule] [nvarchar](1000) NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
	[IsTokenizable] [bit] NULL,
	[TokenizationAlgorithm] [nvarchar](1000) NULL,
	[SourceDataType] [nvarchar](100) NULL,
	[isnullable] [bit] NULL,
	[TokenizationFunction] [nvarchar](1000) NULL,
	[DefaultValue] [nvarchar](max) NULL,
 CONSTRAINT [PK_SourceObjectSchema] PRIMARY KEY CLUSTERED 
(
	[SourceObjectSchemaID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [metadata].[SourceObjectSchema] ADD  DEFAULT ((0)) FOR [IsPrimaryKey]
GO

ALTER TABLE [metadata].[SourceObjectSchema] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [metadata].[SourceObjectSchema] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO

ALTER TABLE [metadata].[SourceObjectSchema] ADD  DEFAULT (suser_name()) FOR [ModifiedBy]
GO

ALTER TABLE [metadata].[SourceObjectSchema] ADD  DEFAULT (getutcdate()) FOR [ModifiedOn]
GO

ALTER TABLE [metadata].[SourceObjectSchema]  WITH CHECK ADD  CONSTRAINT [FK_SourceObjectSchema_SourceObjectDetail] FOREIGN KEY([SourceObjectID])
REFERENCES [metadata].[SourceObjectDetail] ([SourceObjectID])
GO

ALTER TABLE [metadata].[SourceObjectSchema] CHECK CONSTRAINT [FK_SourceObjectSchema_SourceObjectDetail]
GO