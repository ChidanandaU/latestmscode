CREATE TABLE [Metadata].[StreamingConfigurations](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Configuration] [nvarchar](100) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedBy] [nvarchar](100) NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[ModifiedBy] [nvarchar](100) NULL,
	[ModifiedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [Metadata].[StreamingConfigurations] ADD  DEFAULT ((1)) FOR [IsActive]
GO

ALTER TABLE [Metadata].[StreamingConfigurations] ADD  DEFAULT (suser_name()) FOR [CreatedBy]
GO

ALTER TABLE [Metadata].[StreamingConfigurations] ADD  DEFAULT (getutcdate()) FOR [CreatedOn]
GO