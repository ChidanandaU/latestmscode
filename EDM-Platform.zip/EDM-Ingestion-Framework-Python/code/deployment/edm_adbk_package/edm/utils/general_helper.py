import re
import json

from dotted.collection import DottedList, DottedDict
import pandas as pd
import xmltodict

from edm.utils.db_utility import DBConnection
from edm.utils.keyvault_utility import KeyvaultSecretsUtility
from edm.utils.logging_utility import add_azure_handler_to_all_loggers


def generate_date_range(start_date: str, end_date: str):
    date_range = list(pd.date_range(start=start_date, end=end_date, freq='D'))
    date_range = [date.strftime('%Y-%m-%d')for date in date_range]
    return date_range


def adls_connectivity(spark, storage_account_name, access_key):
    '''
    This function is used to set up connectivity to adls
    storage account on a spark session
    '''
    spark.conf.set(
        "fs.azure.account.key.{}.dfs.core.windows.net".
        format(storage_account_name), access_key
    )
    return spark


def blob_connectivity(spark, storage_account_name, access_key):
    '''
    This function is used to setup connectivity to Blob
    Storage Account on a Spark Session
    '''
    spark.conf.set(
        "fs.azure.account.key.{}.blob.core.windows.net".
        format(storage_account_name), access_key
    )
    return spark


def read_env_config(spark, storage_account_name, config_path):
    '''
    This method is uses to read the env config file from raw zone in the
    ADLS
    '''
    base_path = f'abfss://raw@{storage_account_name}.dfs.core.windows.net/'
    adls_config_path = base_path + config_path.lstrip('/')
    config_df = spark.read.option("multiline", "true").json(adls_config_path)
    config = config_df.toPandas().to_dict('dict')
    return config


def initialise(
    spark,
    spn_credentials,
    kv_name,
    adls_account_name,
    config_path
):
    '''
    This method sets up the Blob and ADLS connectivity by setting the
    spark.conf. This also sets the DBConnection to the Operational DB,
    add azure_handler to loggers, reads the env config.
    It returns the config and DBConnection Obj.
    '''
    kv_client = KeyvaultSecretsUtility(
        spn_credentials, kv_name)
    _, adls_access_key = kv_client.get_secret('AdlsAccessKey')
    spark = adls_connectivity(spark, adls_account_name, adls_access_key)
    config = read_env_config(
        spark, adls_account_name, config_path
    )
    _, blob_access_key = kv_client.get_secret(
        config['blob_details'][0]['blob_access_secret']
    )
    spark = blob_connectivity(
        spark, config['blob_details'][0]['name'],
        blob_access_key)
    _, db_user_name = kv_client.get_secret(
        config['db_connection_details'][0]['db_user_name_secret']
    )
    _, db_pwd = kv_client.get_secret(
        config['db_connection_details'][0]['db_password_secret']
    )
    db_obj = DBConnection(
        config['db_connection_details'][0]['db_server_name'],
        config['db_connection_details'][0]['db_name'],
        db_user_name,
        db_pwd
    )
    _, instr_key = kv_client.get_secret(
        config['app_insights'][0]['instr_key_secret']
    )
    # add_azure_handler_to_all_loggers(instr_key)
    return config, db_obj


def get_filename_date_index(file_name):
    '''
    This method is used to provide the date index from the filename.
    '''
    date_regex = r"[0-9]{4}[0-9]{2}[0-9]{2}"
    regex = re.compile(date_regex)
    file_name_part_list = file_name.split("_")
    date_index = None
    date_list = [i for i, item in enumerate(file_name_part_list) if re.search(
        regex, item)]
    if date_list:
        date_index = date_list[0]
    return date_index


def is_valid(incoming_event, deserialized_event):
    if incoming_event == deserialized_event:
        return True
    else:
        return False


def sort_nested_dict(json_dict):
    return {
        key: sort_nested_dict(value) if
        isinstance(value, dict) else value
        for key, value in sorted(json_dict.items())
    }


def reformat_data(json_dict):
    sorted_json_dict = sort_nested_dict(json_dict)
    json_string = json.dumps(sorted_json_dict, separators=(',', ':'))
    return json_string


def remove_null_values_from_dict(json_dict):
    clean = dict()
    for key, value in json_dict.items():
        if isinstance(value, dict):
            nested = remove_null_values_from_dict(value)
            if len(nested.keys()) > 0:
                clean[key] = nested
        elif value is not None:
            clean[key] = value
    return clean


def indentify_event_format(event_body: str):
    '''
    This function takes the event body and identifies if an event is
    xml, json or avro
    '''
    event_format = ""
    if event_body.startswith("<"):
        event_format = 'xml'
    else:
        event_format = 'json'
    return event_format


def get_xml_event_root_key(string: str):
    '''
    This function accepts the string and retrieves the
    xml root key from the string.
    '''
    json_dict = json.loads(string)
    root_key_with_namespace = list(json_dict.keys())[0]
    root_key = root_key_with_namespace.split(":")[1]
    return root_key


def convert_xml_event_to_json(event_body):
    '''
    This function is used to convert the xml string to json string
    '''
    encoded_string = event_body.encode("UTF-8")
    json_dict = xmltodict.parse(encoded_string)
    json_string = json.dumps(json_dict)
    namespace_regex = "ns[0-9]+:"
    formatted_json_string = re.sub(namespace_regex, '', json_string)
    return formatted_json_string


def read_json_path_value(dotted_json_obj, json_path):
    json_path = json_path.replace('[', '.').replace(']', '')
    result = None
    try:
        if((len(json_path) == 0) or (json_path.isspace())):
            return None
        else:
            result = dotted_json_obj.get(json_path, None)
        return result
    except (IndexError, ValueError):
        return None


def get_primitive_type(value):
    if isinstance(value, DottedList):
        value = list(value)
        for index, item in enumerate(value):
            if (isinstance(item, DottedList) or isinstance(item, DottedDict)):
                value[index] = get_primitive_type(item)
    if isinstance(value, DottedDict):
        value = dict(value)
        for key, val in value.items():
            if (isinstance(val, DottedList) or isinstance(val, DottedDict)):
                value[key] = get_primitive_type(val)
    return value


def get_tokenized_col_str(table_prop_df, recon=False):
    if recon:
        table_prop_df = table_prop_df.loc[
            (table_prop_df['IsActive'] == 1) &
            (table_prop_df['IsPrimaryKey'] == 1), :]

    table_prop_df.sort_values(by=['ColumnOrder'], inplace=True)
    tokenized_cols = list()
    for _, row in table_prop_df.iterrows():
        if row['IsTokenizable'] == 1:
            tokenization_str = (
                f"{row['TokenizationFunction']}({row['ColumnName']}, '{row['TokenizationAlgorithm']}') AS {row['ColumnName']}"
            )
            tokenized_cols.append(tokenization_str)
        else:
            tokenized_cols.append(row['ColumnName'])
    tokenized_cols_str = (",").join(tokenized_cols).strip(",")

    tokenized_function_list = list(table_prop_df.loc[
        table_prop_df['TokenizationFunction'].notna()
    ]['TokenizationFunction'].unique())
    return tokenized_cols_str, tokenized_function_list


def merge_sql_metastore_to_adbk_metastore(
    target_schema, target_table, source_table_df, spark
):
    col_list = list(source_table_df.columns)
    col_list_df = pd.DataFrame(data=col_list, columns=['ColumnName'])
    null_cols_list = list(
        source_table_df.columns[source_table_df.isnull().all()]
    )
    for col in null_cols_list:
        source_table_df[col] = source_table_df[col].astype(str)
    spark_df = spark.createDataFrame(source_table_df)
    spark_df.createOrReplaceTempView("MetastoreSource")
    sql_statement = f"MERGE INTO {target_schema}.{target_table} AS Tar USING\
        MetastoreSource AS Src ON Tar.ID = Src.ID WHEN MATCHED THEN UPDATE SET "
    col_list_df['UpdateCols'] = (
        "Tar." + col_list_df['ColumnName'] + " = Src." + col_list_df['ColumnName'])
    update_col_str = ",".join(col_list_df['UpdateCols'].values)
    col_list_df['InsertCols'] = "Src." + col_list_df['ColumnName']
    insert_col_str = ",".join(col_list_df['InsertCols'].values)
    table_schema_str = ",".join(col_list)

    sql_statement = (
        sql_statement + f"{update_col_str} WHEN NOT MATCHED THEN INSERT\
            ({table_schema_str}) VALUES ({insert_col_str})"
    )
    return sql_statement


def connect_to_synapse(spn_creds, kv_name, config):
    '''
    This function is used to connect to azure synapse and return
    the synapse connection obj via DBUtility.
    '''
    synapse_server_name = config['synapse_details'][0]['server_name']
    synapse_db_name = config['synapse_details'][0]['db_name']
    kv_client = KeyvaultSecretsUtility(
        spn_creds, kv_name
    )
    _, synapse_user_name = kv_client.get_secret(
        config['synapse_details'][0]['synapse_user_name_secret']
    )
    _, synapse_pwd = kv_client.get_secret(
        config['synapse_details'][0]['synapse_password_secret']
    )
    synapse_obj = DBConnection(
        synapse_server_name, synapse_db_name,
        synapse_user_name, synapse_pwd
    )
    return synapse_obj


def get_polybase_refresh_statement(
    schema, table_name, streaming_source,
    table_prop_df, external_data_source, mode
):
    location = f"/{streaming_source}/{table_name}"
    sql_statement = f"CREATE EXTERNAL TABLE [{schema}].[{table_name}] ("
    table_prop_df = table_prop_df.loc[table_prop_df['IsActive'] == 1, :]
    table_prop_df.sort_values(by=['ColumnOrder'], inplace=True)
    col_schema_str = ""
    for _, row in table_prop_df.iterrows():
        if row['DestDataType'].lower() == 'varchar':
            col_schema_str += (
                f"[{row['ColumnName']}] [{row['DestDataType']}] (1000),"
            )
        elif row['DestDataType'].lower() == 'decimal':
            col_schema_str += f"[{row['ColumnName']}] [float],"
        else:
            col_schema_str += f"[{row['ColumnName']}] [{row['DestDataType']}],"
    col_schema_str = col_schema_str.strip(",")
    if mode.lower() == 'staging':
        col_schema_str += ' ,EventGuid VARCHAR(50), CreatedOn DATETIME, ModifiedOn DATETIME'
    elif mode.lower() == 'standardized':
        col_schema_str += ' ,EventGuid VARCHAR(50), StartDate DATE, EndDate DATE, IsActive INT'
    sql_statement += col_schema_str + ")"
    sql_statement += (
        f" WITH (DATA_SOURCE = [{external_data_source}], \
            LOCATION='{location}', FILE_FORMAT=[DeltaLakeFormat])"
    )
    return sql_statement


def get_polybase_refresh_statement_batch(
    schema, object_name, source, country,
    table_prop_df, external_data_source
):
    location = f"/{source}/{country}/{object_name}"
    table_name = f'{source}_{country}_{object_name}'
    sql_statement = f"CREATE EXTERNAL TABLE [{schema}].[{table_name}] ("
    table_prop_df = table_prop_df.loc[table_prop_df['IsActive'] == 1, :]
    object_type = table_prop_df['ObjectType'].values[0]
    table_prop_df.sort_values(by=['ColumnOrder'], inplace=True)
    col_schema_str = ""
    for _, row in table_prop_df.iterrows():
        if row['DataType'].lower() == 'string':

            if pd.isnull(row['Length']):
                length = 1000
            else:
                length = 1000      
            
            col_schema_str += (
                    f"[{row['ColumnName']}] VARCHAR({length}),")
        elif ('double') in row['DataType'].lower():
            col_schema_str += f"[{row['ColumnName']}] float,"
        elif row['DataType'].lower() == 'integer':
            col_schema_str += f"[{row['ColumnName']}] INT,"
        elif row['DataType'].lower() == 'timestamp':
            col_schema_str += f"[{row['ColumnName']}] DATETIME,"
        else:
            col_schema_str += f"[{row['ColumnName']}] {row['DataType']},"
    col_schema_str = col_schema_str.strip(",")
    if object_type.lower() == 'txn':
        col_schema_str = (
            '[RowID] VARCHAR(1000),' +
            col_schema_str +
            ',[date] VARCHAR(50), [file] VARCHAR(50), [isActive] VARCHAR(1)'
            )
    else:
        col_schema_str = (
            '[RowID] VARCHAR(1000),' +
            col_schema_str +
            ',[date] VARCHAR(50), [file] VARCHAR(50), [EffectiveStartDate] DATETIME,' +
            '[EffectiveEndDate] DATETIME, [isActive] VARCHAR(1)'
            )
    col_schema_list = col_schema_str.split(",")
    if len(col_schema_list) > 1024:
        return None
    sql_statement += col_schema_str + ")"
    sql_statement += (
        f" WITH (DATA_SOURCE = [{external_data_source}], \
            LOCATION='{location}', FILE_FORMAT=[DeltaLakeFormat])"
    )
    return sql_statement


def file_exists(search_path, file_name, dbutils):
    '''
    This function is used to Return True or False based on the
    existence of file in the search path.
    search_path: the path where file needs to be checked for existence
    file_name: the file which needs to be searched.
    dbutils: to acesss DBFS.
    '''
    search_path_files = dbutils.fs.ls(search_path)
    if len(search_path_files) > 0:
        file_list = [row.name for row in search_path_files]
        if file_name in file_list:
            return True
        else:
            return False
    else:
        return False


def get_file_delimiter(cs_properties, cdc_file_flag, file_name):
    '''
    This function is used to get the file delimiter based on
    the filedelimiter property if present in the country source
    properties.
    '''
    if 'filedelimiter' in cs_properties.keys():
        delimiter = cs_properties['filedelimiter']
        if delimiter == '\\u0001':
            delimiter = '\u0001'
        if '.csv' in file_name:
            delimiter = ','
    else:
        if cdc_file_flag:
            delimiter = '\u0001'
        else:
            delimiter = ','
    return delimiter


def create_trimmed_df(df, table_name):
    '''
    This function is used to create a select statement
    to retrieve columns from a Temp View/Table by trimming
    all the columns.
    '''
    col_list = df.columns
    col_str = ""
    for col in col_list:
        col = f"trim({col}) AS {col},"
        col_str += col
    col_str = col_str.rstrip(",")
    select_str = f"SELECT {col_str} FROM {table_name}"
    return select_str
