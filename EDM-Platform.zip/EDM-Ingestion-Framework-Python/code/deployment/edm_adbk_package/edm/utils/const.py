LANDING_ZONE_CONFIG_PATH = (
    'wasbs://container@account.blob.core.windows.net/config/source/country'
)
LANDING_ZONE_DATA_PATH = (
    'wasbs://container@account.blob.core.windows.net/data/source/country'
)
RAW_ZONE_DATA_PATH = (
    'abfss://raw@account.dfs.core.windows.net/data/source/country'
)
REJECT_ZONE_DATA_PATH = (
    'abfss://reject@account.dfs.core.windows.net/data/source/country'
)
RAW_ZONE_CDC_PATH = (
    'abfss://raw@account.dfs.core.windows.net/cdc/'
)
RAW_ZONE_CONFIG_PATH = (
    'abfss://raw@account.dfs.core.windows.net/config'
)
STANDARDIZE_ZONE_DATA_PATH = (
    'abfss://standardized@account.dfs.core.windows.net/data/source/country'
)
ERROR_ZONE_DATA_PATH = (
    'abfss://error@account.dfs.core.windows.net/data/'
)
TRANSFORMED_ZONE_DATA_PATH = (
    'abfss://transformed@account.dfs.core.windows.net/data/source/country'
)
SQL_ADBK_DTYPE_MAP = {
    "DECIMAL": "decimal", "VARCHAR": "string",
    "CHAR": "string", "FLOAT": "double", "DOUBLE": "double",
    "INT": "integer", "STRING": "string", "BIGINT": "string", 
    "TIMESTAMP": "TIMESTAMP"}

REALTIME_DTYPE_MAP = {
    "STRING": "VARCHAR", 'INT': 'INT', "DOUBLE": "DECIMAL", "CLOB": "VARCHAR"
}

REALTIME_LANDING_PATH = (
    'abfss://raw@account.dfs.core.windows.net/'
)
REALTIME_STAGING_DELTA_PATH = (
    'abfss://staging@account.dfs.core.windows.net/realtime/')

REALTIME_STANDARDIZED_DELTA_PATH = (
    'abfss://standardized@account.dfs.core.windows.net/realtime/')

TOKENISATION_ALGO_NUMERALS = 'TE_N_S23_L0R0_LP_AST'
TOKENISATION_ALGO_STRING = 'TE_A_N_L0R0_S23_Y_AST'
CONTROLFILE_TABLE_MAPPING_FILENAME = 'controlfiletablemapping.csv'

GET_STREAMING_SOURCE_SCHEMA_DETAILS = "SELECT SchemaName,\
SchemaGuid \
FROM Metadata.EventHubSchemaRegistryMaster \
WHERE SchemaName = '{}'"

GET_STREAMING_TABLE_COLUMN_PROP = "SELECT ssd.StreamingSource, \
ssd.ID AS StreamingSourceID, td.ID AS TargetTableID, \
td.TargetTableName,  td.HasExplode,  cd.ColumnName,  cd.ColumnOrder, \
cd.SourceDataType,cd.DestDataType,cd.IsPrimaryKey, \
cd.PkSequenceNumber,cd.Length,  cd.IsNullable, cd.JsonTag, \
cd.IsExploded, cd.IsActive,cd.IsSchemaEvolved,cd.IsSchemaEvolvedStandardized, \
cd.IsColumnUpdated,cd.IsColumnUpdatedStandardized,cd.IsTokenizable,cd.TokenizationAlgorithm, \
cd.TokenizationFunction \
FROM Metadata.StreamingSourceDetails ssd \
INNER JOIN Metadata.StreamingEDMPTableDetails td ON ssd.ID = td.StreamingSourceID \
INNER JOIN Metadata.StreamingEDMPColumnDetails cd ON td.ID = cd.TargetTableID \
WHERE ssd.StreamingSource = '{}'"

GET_STREAMING_TABLE_EXPLODE_PROP = "SELECT DISTINCT StreamingSource, \
STD.TargetTableName,SEP.ExplodeColumnSequence, \
SEP.ExplodeColumnJsonPath,SEP.NestedObjectType \
FROM Metadata.StreamingSourceDetails SSD \
INNER JOIN Metadata.StreamingEDMPTableDetails STD ON SSD.ID=STD.StreamingSourceID \
INNER JOIN Metadata.StreamingTableExplodeProperties SEP ON STD.ID= SEP.TargetTableID \
WHERE SSD.StreamingSource='{}' AND STD.TargetTableName='{}'"

SOURCE_FILE_PROCESS_QUERY = "select PipelineLogID, SourceFileProcessLogID, \
    FileName, SourceCount, RawPath, IsCDCFile \
    from ETLlog.SourceFileProcessLog \
    where IsRawtoStandardisedProcessed = 0 \
    and IsLandingToRawProcessed = 1 \
    and SourceID={} \
    and SourceObjectID={} \
    and SourceFileStatus='Completed'\
    and FileName = '{}'\
    AND RawFileStatus='In Progress'"

RTS_GET_SOURCE_COUNTRY_CODE = "select SourceName, CountryCode from [Metadata].[SourceMaster] \
    where SourceID={}"

RTS_SOURCE_OBJECT_DETAIL = "select sm.CountrySourceProperties, sm.SourceType, \
    sod.ObjectName ,sod.ObjectType ,sod.ObjectProperties \
    from Metadata.SourceMaster sm join \
    Metadata.SourceObjectDetail sod on \
    sod.SourceId=sm.SourceID where \
    SourceObjectID={}"

LTR_SOURCE_OBJECT_DETAIL = "select sm.SourceID, sm.CountrySourceProperties, \
    sm.SourceType,sod.SourceObjectID,sod.ObjectProperties \
    from Metadata.SourceMaster sm join \
    Metadata.SourceObjectDetail sod on \
    sod.SourceId=sm.SourceID where SourceName = '{}'\
    and CountryCode= '{}' and \
    ObjectName='{}'"

GET_SOURCE_OBJECT_ID = "select SourceObjectID \
    from Metadata.SourceObjectDetail sod \
    INNER JOIN Metadata.SourceMaster sm \
        ON sm.SourceID = sod.SourceID \
    where sm.SourceName = '{}' AND \
    sm.CountryCode = '{}' AND \
    sod.ObjectName = '{}'"

GET_HEADER_TARILER_ROW_COUNT = "select [RowCount] from \
    [ETLlog].[SourceFileHeaderTrailerLog] where \
    SourceObjectID = {} \
    and IsActive = 1 \
    AND BusinessDate = '{}'"

GET_IS_PRIMARY_KEY = "SELECT soc.ColumnName,soc.IsPrimaryKey \
    FROM Metadata.SourceMaster sm with(nolock) \
    JOIN Metadata.SourceObjectDetail sod with(nolock) \
    ON sm.SourceID=sod.SourceID \
    JOIN Metadata.SourceObjectSchema soc with(nolock) \
    ON sod.SourceObjectID=soc.SourceObjectID  \
    AND sm.SourceName= '{}' \
    AND sm.CountryCode='{}' \
    AND sod.ObjectName='{}' \
    AND soc.IsActive=1"

GET_CDC_WATERMARK = "SELECT PreviousEOD, CurrentEOD \
    FROM ETLlog.CDCWatermark \
    WHERE SourceName = '{}' \
    AND CountryCode = '{}' \
    AND EODMarkerStrategy = '{}' \
    AND ObjectName = '{}'"

GET_COUNTRY_SOURCE_PROPERTIES = "SELECT CountrySourceProperties, SourceID \
    FROM metadata.SourceMaster \
    WHERE SourceName= '{}' \
    AND CountryCode = '{}'"

UPDATE_CTRL_SOURCE_FILE_PROCESS_LOG = "UPDATE ETLLog.SourceFileProcessLog \
    SET IsLandingToRawProcessed = 1, \
    IsRawToStandardisedProcessed = 1, \
    SourceFileStatus = 'Completed', RawFileStatus='Completed', \
    ModifiedOn = GETUTCDATE(),  SourceID = {}, \
    IsCDCFile = 0, \
    RawPath = '{}' \
    WHERE PipelineLogID = {}"

GET_SOURCE_FILE_PROCESS_LOG_ID = "select SourceFileProcessLogID from \
    [EtlLog].[SourceFileProcessLog] \
    where PipelineLogID = {} and filename = \
    '{}'"

UPDATE_SOURCE_FILE_PROCESS_LOG_FAILURE_QUERY = "UPDATE [EtlLog].[SourceFileProcessLog] \
    SET SourceFileStatus = 'Failed', \
    ModifiedOn = GETUTCDATE(), \
    ModifiedBy = SUSER_NAME() \
    WHERE PipelineLogID = {} "

UPDTAE_PIPELINE_LOG_FAILURE_QUERY = "UPDATE [EtlLog].[PipelineLog] \
    SET   \
    [PipelineStatus] = 'Failed',  \
    [EndTime] = GETUTCDATE(),  \
    [ModifiedOn] = GETUTCDATE(), \
    [ModifiedBy] = SUSER_NAME()  \
    WHERE PipelineLogID = {};"

GET_TOKENIZATION_FUNCTION = "SELECT DISTINCT TokenizationFunction \
    FROM metadata.SourceObjectSchema os \
    INNER JOIN metadata.SourceObjectDetail sod \
        ON sod.SourceObjectId = os.SourceObjectID \
    INNER JOIN metadata.SourceMaster sm \
        ON sm.sourceId = sod.SourceId \
    WHERE  sod.ObjectName = '{}' \
        AND sm.SourceName = '{}' \
        AND sm.CountryCode = '{}' \
        AND os.IsActive = 1 \
        AND TokenizationFunction IS NOT NULL"

GET_WIDTH_RULES = "select ColumnName, DataType, \
    Width, [Rule], IsPrimaryKey, Length, \
    isnullable from {}  \
    where SourceObjectID = {} and SchemaType = '{}' \
    and IsActive = 1 order by ColumnOrder"

GET_SCHEMA_EVOLUTION_META_INFO = "select \
        sod.ObjectName, \
        sm.SourceName, \
        sm.CountryCode, \
        ColumnName, \
        ColumnOrder, \
        DataType, \
        IsPrimaryKey,  \
        sob.IsActive, \
        sob.IsSchemaEvolved, \
        sod.ObjectType, \
        sob.Length \
    FROM [Metadata].[sourceobjectschema] sob \
    JOIN [Metadata].[SourceObjectDetail] sod  \
    ON sob.SourceObjectID = sod.SourceObjectID \
    JOIN [metadata].[SourceMaster] AS SM  \
        ON sm.SourceID=sod.SourceID \
    WHERE sod.ObjectName = '{}' \
    AND SM.SourceName = '{}' \
    AND SM.CountryCode = '{}'"

GET_RENAME_PROP = "select RenameProperties from [Metadata].[RelableObject] \
    where sourceName = '{}'\
    and CountryCode = '{}'"

GET_COL_DEFAULT_VALUES = "SELECT ColumnName, DefaultValue \
    FROM metadata.SourceObjectSchema \
        WHERE  SourceObjectID = {} \
            AND DefaultValue IS NOT NULL"

CHECK_FILE_RE_RUN = "SELECT FileName \
    FROM etllog.SourceFileProcessLog \
        WHERE  FileName = '{}' \
            AND SourceFileStatus = 'Completed' AND RawFileStatus \
                NOT IN ('In Progress', 'Not Processed')"

DELTA_EXTRA_TRAIL_COLS = [
    'date string', 'file string', 'EffectiveStartDate timestamp',
    'EffectiveEndDate timestamp', 'isActive string', 'EffectiveEndDate_ timestamp']

TXN_EXTRA_TRAIL_COLS = ['date string', 'file string', 'isActive string', 'date_ string']