import json
import re
import datetime

import pyspark.sql.types as t
import pyspark.sql.functions as f

from edm.utils.const import (
    GET_SOURCE_FILE_PROCESS_LOG_ID, GET_TOKENIZATION_FUNCTION, GET_WIDTH_RULES,
    LANDING_ZONE_DATA_PATH, LTR_SOURCE_OBJECT_DETAIL, RAW_ZONE_DATA_PATH,
    RAW_ZONE_CDC_PATH, GET_COUNTRY_SOURCE_PROPERTIES,
    UPDATE_CTRL_SOURCE_FILE_PROCESS_LOG, REJECT_ZONE_DATA_PATH
)
from edm.utils.general_helper import (
    create_trimmed_df, initialise, get_filename_date_index, get_file_delimiter
)
from edm.utils.logging_utility import get_logger

LOGGER = get_logger(__name__)


class LandingToRawProcessor:
    '''
    This class is used to process the data file
    from Landing to Raw zone. Data file will get
    reject if found empty and moved to reject zone.
    '''

    def __init__(
        self, source, country, file_name, object_name, pipeline_log_id, spark, 
        sqlContext, dbutils, **kwargs
    ):
        '''
        This instantiates a landing to raw processor Object
        '''
        self.source = source
        self.country = country
        self.file_name = file_name
        self.object_name = object_name
        self.pipeline_log_id = pipeline_log_id
        self.spark = spark
        self.sqlContext = sqlContext
        self.dbutils = dbutils
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def control_file_handling(self, landing_data_path):
        source_file_path = landing_data_path+'/'+self.file_name
        query = GET_COUNTRY_SOURCE_PROPERTIES.format(self.source, self.country)

        ctrl_file_flag = None
        result_df = self.db_obj.get_df_from_query(query)
        cs_properties = result_df['CountrySourceProperties'].values[0]
        self.source_id = result_df['SourceID'].values[0]
        cs_properties = json.loads(cs_properties)
        # Defining control file identifier & Flag
        ## Check if cs_properties['control_file'] is True
        ctrl_file_identifier = '*CONTROL*'
        if 'control.file.identifier' in cs_properties.keys():
            ctrl_file_identifier = cs_properties['control.file.identifier']
        ctrl_file_flag = (
            re.search(ctrl_file_identifier.lstrip('*').rstrip('*'), self.file_name)
        )
        # Checking if file is control file
        if ctrl_file_flag:
            LOGGER.info("Moving Control File to raw Zone")
            control_dest = (
                RAW_ZONE_DATA_PATH.replace(
                    'account', self.adls_account_name
                ).replace(
                    "source",
                    self.source
                ).replace(
                    "country",
                    self.country
                ).replace(
                    "data",
                    "control"
                )
            )
            raw_path_to_update = (
                f"control/{self.source}/{self.country}/{self.file_name.rstrip('.csv').upper()}.csv"
            )
            control_dest = (
                control_dest.rstrip("/") +
                '/' + self.file_name.rstrip('.csv').upper() + '.csv')
            self.dbutils.fs.mv(source_file_path, control_dest)
            LOGGER.info("File Moved Successfully")
            update_query = UPDATE_CTRL_SOURCE_FILE_PROCESS_LOG.format(
                self.source_id, raw_path_to_update, self.pipeline_log_id)
            self.db_obj.run_sql_query(update_query)

        return ctrl_file_flag

    def landing_to_raw_processor(self):
        '''
        This method is used to process & tokenize the data file and
        move it to Raw zone if it's not empty otherwise
        moved to reject zone.
        '''
        # Defining destination and source path
        try:
            data_dest = (
                RAW_ZONE_DATA_PATH.replace(
                    'account', self.adls_account_name
                ).replace(
                    "source",
                    self.source
                ).replace(
                    "country",
                    self.country
                )
            )
            cdc_dest = (
                RAW_ZONE_CDC_PATH.replace(
                    'account', self.adls_account_name
                )
            ).rstrip('/')

            landing_data_path = (
                LANDING_ZONE_DATA_PATH.replace(
                    "container",
                    self.config['blob_details'][0]['incoming_container_name']
                    ).replace(
                        "account",
                        self.config['blob_details'][0]['name']
                    ).replace(
                        "source",
                        self.source
                    ).replace(
                        "country",
                        self.country
                    )
            )
            landing_archive_path = (
                LANDING_ZONE_DATA_PATH.replace(
                    "container",
                    'archives'
                    ).replace(
                        "account",
                        self.config['blob_details'][0]['name']
                    ).replace(
                        "source",
                        self.source
                    ).replace(
                        "country",
                        self.country
                    )
            )
            self.source_file_path = landing_data_path + '/' + self.file_name
            self.reject_zone_path = REJECT_ZONE_DATA_PATH.replace(
                        "account",
                        self.adls_account_name
                    ).replace(
                        "source",
                        self.source
                    ).replace(
                        "country",
                        self.country
                    )
            

            self.cdc_file_flag = False
            cdc_eod_marker_file_flag = False
            cdc_recon_file_flag = False
            date_index = None
            ctrl_file_flag = None

            # Control file handling
            ctrl_file_flag = self.control_file_handling(landing_data_path)
            if ctrl_file_flag:
                return True

            # Checking file type
            if ('.D' and '.T' and '.R') in self.file_name:
                self.cdc_file_flag = True
                file_name_part_list = self.file_name.split(".")
                business_date = file_name_part_list[1].strip('D')
                object_name = file_name_part_list[0].lower()
                if 'eod_marker' in self.file_name.lower():
                    cdc_eod_marker_file_flag = True
                if 'recon' in self.file_name.lower():
                    cdc_recon_file_flag = True
            else:
                date_index = get_filename_date_index(self.file_name)
                file_name_part_list = self.file_name.split("_")
                object_name = self.object_name
                business_date = file_name_part_list[date_index].split('.')[0]

            query = GET_SOURCE_FILE_PROCESS_LOG_ID.format(
                self.pipeline_log_id, self.file_name)
            source_file_details = self.db_obj.run_sql_query(query)[0][0]
            sourcefileprocesslog_id = source_file_details[0]

            output = {}
            if object_name:

                # Getting Source and Object properties from metastore
                propQuery = LTR_SOURCE_OBJECT_DETAIL.format(
                    self.source, self.country, object_name
                )
                meta_details = self.db_obj.run_sql_query(propQuery)[0][0]
                self.source_id = meta_details[0]
                cs_properties = json.loads(meta_details[1])
                source_object_id = meta_details[3]
                os_properties = json.loads(meta_details[4])

                # Extracting Source Type & control file property value
                source_type = cs_properties['sourcing.type']
                ctrl_file = cs_properties['control_file']

                # Defining year, month, date for partitioning
                d = datetime.date.today()
                year = str(d.year)
                month = str(d.strftime('%m'))
                date = str(d.strftime('%d'))

                # Getting schema info from metadata
                schema, schema_info, col_to_cast = self \
                    .object_schema_width_rules(source_object_id)

                # Renaming the file if required
                if self.cdc_file_flag:
                    if cdc_eod_marker_file_flag:
                        common_path = f'{cdc_dest}/trigger/eod_marker/{self.source}/{self.country}/{year}/{month}/{date}'
                    elif cdc_recon_file_flag:
                        common_path = f'{cdc_dest}/trigger/recon/{self.source}/{self.country}/{year}/{month}/{date}'
                    else:
                        common_path = (
                            f'{cdc_dest}/{self.source}/{self.country}/{object_name}/{year}/{month}/{date}'
                            )
                else:
                    common_path = (
                            f'{data_dest}/{object_name}/{year}/{month}/{date}'
                        )
                if (object_name not in self.file_name and object_name.upper() not in self.file_name):
                    new_file_name = (
                        f'{self.source}_{self.country}_{object_name}_{business_date}.csv'
                    )
                    destination = (
                        common_path + f'/{new_file_name}'
                    )
                else:
                    destination = (
                        common_path + f'/{self.file_name}'
                    )

                # getting delimiter info
                delimiter = get_file_delimiter(
                    cs_properties, self.cdc_file_flag, self.file_name
                )
                # Source File Path
                source_file_path = landing_data_path+'/'+self.file_name
                count = 0
                rts_flag = 0
                raw_file_status = None

                if source_type == 'BATCH_FIXEDWIDTH':
                    fw_df = self.spark.read.option("multiline", "true") \
                        .option("escape", " ") \
                        .text(landing_data_path+'/'+self.file_name)
                    if ctrl_file in ('false', 'False'):
                        fw_df, header_trailer_flag = self.extract_header_trailer(
                            fw_df, os_properties,
                            source_object_id,
                            object_name,
                            sourcefileprocesslog_id,
                            business_date,
                            source_type
                            )
                    if(header_trailer_flag is False):
                        return
                    # Verify if dataframe is empty or not
                    count = fw_df.count()
                    if count != 0:
                        width = 1
                        for items in schema_info:
                            fw_df = fw_df \
                                .withColumn(
                                    items[0],
                                    f.col('value').substr(width, items[2])
                                )
                            width += items[2]
                        cols = [i[0] for i in schema_info]
                        dl_df = fw_df.select(cols)
                        dl_df = self.get_df_with_rules(dl_df, schema_info)
                        dl_df.createOrReplaceTempView('TempTable')
                        select_string = create_trimmed_df(dl_df, 'TempTable')
                        dl_df = self.spark.sql(select_string)
                        # dl_df = self.spark.createDataFrame(dl_df.rdd, schema)
                        for key, value in col_to_cast.items():
                            dl_df = dl_df.withColumn(key, f.col(key).cast(value))
                        # Tokenization
                        dl_df = self.tokenization(dl_df, object_name)
                        dl_df.coalesce(1).write. \
                            format("csv"). \
                            mode("overwrite"). \
                            option("sep", delimiter). \
                            option("compression", "snappy"). \
                            option("header", "true"). \
                            save(destination)
                    else:
                        # Reject the file from ADF
                        output['IsArchived'] = True
                        LOGGER.info("Archiving the filename.")
                else:
                    if self.cdc_file_flag:
                        df = self.spark.read \
                        .option("multiline", "true") \
                        .option("escape", " ") \
                        .option('sep', delimiter) \
                        .csv(
                            landing_data_path+'/'+self.file_name,
                            schema=schema,
                            header=False
                        )
                    else:
                        # To check for headerindicator value
                        if ctrl_file in ('false', 'False'):
                            prop_ex = f"{self.source}_{self.country}_{object_name}"
                            if f'{prop_ex}.headerindicator' in os_properties:
                                h_val = os_properties[f'{prop_ex}.headerindicator']
                                if(h_val != ''):
                                    df = self.spark.read\
                                        .option("multiline", "true") \
                                        .option("escape", " ") \
                                        .option('sep', delimiter) \
                                        .csv(
                                            landing_data_path+'/'+self.file_name,
                                            schema=schema
                                        )
                                else:
                                    df = self.spark.read \
                                    .option("multiline", "true") \
                                    .option("escape", " ") \
                                    .option('sep', delimiter) \
                                    .csv(
                                        landing_data_path+'/'+self.file_name,
                                        schema=schema,
                                        header=True
                                    )
                            else:
                                df = self.spark.read \
                                    .option("multiline", "true") \
                                    .option("escape", " ") \
                                    .option('sep', delimiter) \
                                    .csv(
                                        landing_data_path+'/'+self.file_name,
                                        schema=schema,
                                        header=True
                                    )
                        else:
                            df = self.spark.read \
                                .option("multiline", "true") \
                                .option("escape", " ") \
                                .option('sep', delimiter) \
                                .csv(
                                    landing_data_path+'/'+self.file_name,
                                    schema=schema,
                                    header=True
                                )
                    count = df.count()
                    if count != 0:
                        for key, value in col_to_cast.items():
                            df = df.withColumn(key, f.col(key).cast(value))

                        if ctrl_file in ('false', 'False'):
                            df, header_trailer_flag = self.extract_header_trailer(
                                df, os_properties,
                                source_object_id,
                                object_name,
                                sourcefileprocesslog_id,
                                business_date=business_date
                            )
                            if header_trailer_flag is False:
                                return
                        count = df.count()
                        df = self.get_df_with_rules(df, schema_info)
                        # Tokenization
                        df = self.tokenization(df, object_name)
                        # Write dataframe to raw zone
                        df.coalesce(1).write. \
                            format("csv"). \
                            mode("overwrite"). \
                            option("sep", delimiter). \
                            option("compression", "snappy"). \
                            option("header", "true"). \
                            save(destination)
                    else:
                        # Reject the file from ADF
                        output['IsArchived'] = True
                        LOGGER.info("Archiving the filename.")

                # Archiving the data file
                if 'IsArchived' in output:
                    landing_archive_path = landing_archive_path.rstrip('/')
                    landing_archive_path = (
                        landing_archive_path + '/' + year + '/' + month + '/' + date + '/' + self.file_name
                    )
                    self.dbutils.fs.mv(source_file_path, landing_archive_path)
                    rts_flag = 1
                    raw_file_status = 'Archived'
                    LOGGER.info("File Archived Successfully.")

                # Logging in Metastore
                LOGGER.info("Logging to Source File table")
                if self.cdc_file_flag:
                    raw_path = destination.split('cdc/')[1]
                else:
                    raw_path = destination.split('data/')[1]
                param = {
                    'SourceFileProcessLogID': sourcefileprocesslog_id,
                    'SourceCount': count,
                    'SourceId': self.source_id,
                    'SourceObjectId': source_object_id,
                    'PipelineLogID': self.pipeline_log_id,
                    'SourceFileStatus': 'Completed',
                    'IsLandingToRawProcessed': 1,
                    'IsRawtoStandardisedProcessed': rts_flag,
                    'IsCDCFile': self.cdc_file_flag,
                    'PipelineStatus': 'Succeeded',
                    'TargetCount': None,
                    'ErrorCount': None,
                    'DuplicateCount': None,
                    'RawPath': raw_path,
                    'RawFileStatus': raw_file_status
                    }
                self.db_obj.run_stored_proc(
                    'ETLlog', 'uspUpdatePipelineLog', params=param
                )

            else:
                LOGGER.info("Date is not available in filename.")
        except Exception as err:
            LOGGER.exception("Exception: " + str(err))
            param = {
                    'SourceFileProcessLogID': sourcefileprocesslog_id,
                    'SourceCount': None,
                    'SourceId': self.source_id,
                    'SourceObjectId': source_object_id,
                    'PipelineLogID': self.pipeline_log_id,
                    'SourceFileStatus': 'Failed',
                    'IsLandingToRawProcessed': 0,
                    'IsRawtoStandardisedProcessed': 0,
                    'IsCDCFile': self.cdc_file_flag,
                    'PipelineStatus': 'Failed',
                    'TargetCount': None,
                    'ErrorCount': None,
                    'DuplicateCount': None,
                    'RawPath': None
                    }
            self.db_obj.run_stored_proc(
                    'ETLlog', 'uspUpdatePipelineLog', params=param
                )

   
    def tokenization(self, df, object_name):
        # Creating temp view for tokenization
        filename = self.file_name.split('.')[0].replace('$', '')
        df.createOrReplaceTempView(filename)
        param = {'objectname': object_name, 
                 'Source'    : self.source,
                 'Country'   : self.country}
        token_cols_df = self.db_obj.get_df_from_stored_proc(
            'metadata', 'uspRetrieveTokenizedColumns', params=param
        )
        meta_info_sql = GET_TOKENIZATION_FUNCTION.format(object_name, self.source, self.country)
        tokenization_func_list = (
            self.db_obj.get_df_from_query(meta_info_sql)
            ['TokenizationFunction'].values
        )
        tokenization_func_base = (
            "create or replace temporary function {} as 'com.protegrity.hive.udf.{}'"
        )
        if len(tokenization_func_list) > 0:
            # register the functions
            for func in tokenization_func_list:
                tokenization_reg_str = tokenization_func_base.format(
                    func, func
                )
                self.spark.sql(tokenization_reg_str)

            token_col_str = (
                token_cols_df['TokenizedColumnString'].values[0].rstrip(',').lstrip(',')
            )
            query = "select "+token_col_str+" from "+filename
            df = self.spark.sql(query)
        return df

    def object_schema_width_rules(self, source_object_id, stype=None):
        '''
        This method is used to extract schema,
        width and rules information from metastore and
        create a structtype schema for spark.
        '''
        if stype:
            table_name = '[Metadata].[SourceObjectMetadataSchema]'
            query = GET_WIDTH_RULES.format(table_name, source_object_id, stype)
        else:
            table_name = '[Metadata].[SourceObjectSchema]'
            query = GET_WIDTH_RULES.replace("and SchemaType = '{}'", "")
            query = query.format(table_name, source_object_id)

        schema_info = self.db_obj.run_sql_query(query)[0]
        schema = t.StructType()
        col_to_cast = {}
        for items in schema_info:
            col = items[0]
            if (items[1] == 'integer') or (items[1] == 'int') or ('decimal' in items[1].lower()):
                schema.add(col, 'string', True)
                col_to_cast[col] = items[1]
            else:
                schema.add(col, items[1].lower(), True)
        return schema, schema_info, col_to_cast

    def get_df_with_rules(self, df, schema_info):
        '''
        This method is used to apply the rules
        on Columns.
        '''
        for item in schema_info:
            rule_info = item[3]
            column = item[0]
            if rule_info:
                if rule_info.startswith("Trim"):
                    replace_to = rule_info.rstrip(',').lstrip('(').split(')')[0] \
                        .split(',')[0].strip("'")
                    replace_by = rule_info.rstrip(',').lstrip('(').split(')')[0] \
                        .split(',')[1].strip("'")
                    df = df.withColumn(
                        column, f.regexp_replace(
                            column, replace_to, replace_by
                        )
                    )
                elif rule_info == "ReplaceWhiteSpaces('0')":
                    replace_to = ' '
                    replace_by = rule_info \
                        .strip('ReplaceWhiteSpaces') \
                        .strip("('") \
                        .strip("')")
                    df = df.withColumn(
                        column, f.regexp_replace(
                            column, replace_to, replace_by
                        )
                    )
                elif rule_info.startswith("DIVIDE"):
                    N = int(
                        rule_info.split(',')[0].strip('DIVIDE').strip("(").strip(")")
                    )
                    replace_to = ' '
                    replace_by = rule_info.split(',')[1]. \
                        strip('ReplaceWhiteSpaces'). \
                        strip("('") \
                        .strip("')")
                    df = df.withColumn(
                        column,
                        f.col(column).cast(t.DoubleType())
                        ) \
                        .withColumn(column, f.col(column)/N) \
                        .withColumn(column, f.regexp_replace(
                            column, replace_to, replace_by)
                        )
                    if 'DECIMAL' in item[1]:
                        df = df.withColumn(
                            column, f.col(column).cast(t.DecimalType())
                        )

        return df

    # Verify with header and trailer schema after extracting header & trailer records 
    def extract_header_trailer(
        self,
        df,
        os_properties,
        source_object_id,
        object_name,
        sourcefileprocesslog_id,
        business_date,
        stype=None
    ):
        '''
        This method is used to extract header & trailer data
        from dataframe and store it in metastore.
        '''
        header = self.spark.createDataFrame(data=[], schema=t.StructType([]))
        trailer = self.spark.createDataFrame(data=[], schema=t.StructType([]))
        header_trailer_flag = True
        header_metadata_value = None
        trailer_metadata_value = None
        icol = df.columns[0]
        prop_ex = f'{self.source}_{self.country}_{object_name}'

        h_ind = os_properties.get(f'{prop_ex}.headerindicator', None)
        tr_ind = os_properties.get(f'{prop_ex}.trailerindicator', None)
        
        if h_ind == '':
            h_ind = None
        if tr_ind == '':
            tr_ind = None

        if h_ind or tr_ind:
            if (h_ind is None) and (tr_ind is None):
                # In this case we can consider header or trailer info not present
                return df, header_trailer_flag
            first_rec = df.first()
            last_rec = df.tail(1)

            if stype == 'BATCH_FIXEDWIDTH':
                first_row_value = str(first_rec[icol][0])
                last_row_value = str(last_rec[0][icol][0])
            else:
                first_row_value = str(first_rec[icol])
                last_row_value = str(last_rec[0][icol])

            if(
                (h_ind == first_row_value and tr_ind == last_row_value) or 
                (h_ind == first_row_value and tr_ind is None) or 
                (h_ind is None and tr_ind == last_row_value)
            ):
                # Getting Schema for header & trailer
                if(h_ind == first_row_value):
                    header = df.filter(f.col(icol).startswith(h_ind))
                    if(header.count() > 0):
                        df = df.filter(~f.col(icol).startswith(h_ind))
                        hschema, hschema_info, hcol_to_cast = (
                            self.object_schema_width_rules(
                                source_object_id, 'headercolschema'
                            )
                        )

                if(tr_ind == last_row_value):
                    trailer = df.filter(f.col(icol).startswith(tr_ind))
                    if(trailer.count() > 0):
                        df = df.filter(~f.col(icol).startswith(tr_ind))
                        tschema, tschema_info, tcol_to_cast = (
                            self.object_schema_width_rules(
                                source_object_id, 'trailercolschema'
                            )
                        )

                if stype == 'BATCH_FIXEDWIDTH':
                    if(header.count() > 0):
                        hwidth = 1
                        for items in hschema_info:
                            header = header \
                                .withColumn(
                                    items[0], f.col(icol).substr(hwidth, items[2])
                                )
                            hwidth += items[2]
                        header_metadata_value = header.collect()[0].asDict()
                    if(trailer.count() > 0):
                        twidth = 1
                        for items in tschema_info:
                            if items[2]:
                                awidth = items[2]
                            else:
                                awidth = 8
                            trailer = trailer \
                                .withColumn(
                                    items[0], f.col(icol).substr(twidth, awidth)
                                )
                            twidth += awidth
                        trailer_metadata_value = trailer.collect()[0].asDict()
                else:
                    if(header.count() > 0):
                        header = header.select(header.columns[:len(hschema_info)])
                        header = self.spark.createDataFrame(header.rdd, hschema)
                        for key, value in hcol_to_cast.items():
                            if 'decimal' in value.lower():
                                value = 'double'
                            header = header.withColumn(key, f.col(key).cast(value))
                        header_metadata_value = header.collect()[0].asDict()
                    if(trailer.count() > 0):
                        trailer = trailer.select(trailer.columns[:len(tschema_info)])                  
                        trailer = self.spark.createDataFrame(trailer.rdd, tschema)
                        for key, value in tcol_to_cast.items():
                            if 'decimal' in value.lower():
                                value = 'double'
                            trailer = trailer.withColumn(key, f.col(key).cast(value))
                        trailer_metadata_value = trailer.collect()[0].asDict()
                    
                Metadata = {'header': header_metadata_value,
                            'trailer': trailer_metadata_value}

                if(trailer.count() > 0):                        
                    row_count = Metadata['trailer']['ROWCOUNT']
                else:
                    row_count = 0

                param = {
                    'SourceObjectID': source_object_id,
                    'Metadata': json.dumps(Metadata),
                    'RowCount': row_count,
                    'BusinessDate': business_date
                    }
                self.db_obj.run_stored_proc(
                    'ETLlog', 'SourceFileHeaderTrailerLogProc', params=param
                )
            elif '.D' in self.file_name:
                file_name_part_list = self.file_name.split(".")
                business_date = file_name_part_list[1].strip('D')
                row_count = file_name_part_list[3].strip('R')
                param = {
                    'SourceObjectID': source_object_id,
                    'Metadata': '{}',
                    'RowCount': int(row_count),
                    'BusinessDate': business_date
                    }
                self.db_obj.run_stored_proc(
                    'ETLlog', 'SourceFileHeaderTrailerLogProc', params=param
                )
            else:
                source_count = df.count()
                self.dbutils.fs.mv(
                    self.source_file_path, self.reject_zone_path)
                header_trailer_flag = False
                rts_flag = 1
                raw_file_status = (
                    'Rejected- Header Trailer Validation Failed')
                param = {
                    'SourceFileProcessLogID': sourcefileprocesslog_id,
                    'SourceCount': source_count,
                    'SourceId': self.source_id,
                    'SourceObjectId': source_object_id,
                    'PipelineLogID': self.pipeline_log_id,
                    'SourceFileStatus': 'Completed',
                    'IsLandingToRawProcessed': 1,
                    'IsRawtoStandardisedProcessed': rts_flag,
                    'IsCDCFile': self.cdc_file_flag,
                    'PipelineStatus': 'Succeeded',
                    'TargetCount': None,
                    'ErrorCount': None,
                    'RawPath': None,
                    'DuplicateCount': None,
                    'RawFileStatus': raw_file_status
                }
                self.db_obj.run_stored_proc(
                    'ETLlog', 'uspUpdatePipelineLog', params=param
                )
        return df, header_trailer_flag

    def run(self):
        '''
        This method is used to run the Landing to raw pipeline
        end-to-end.
        '''
        LOGGER.info("Starting Landing to Raw pipeline")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        LOGGER.info("Ended Initialisation")
        LOGGER.info("Starting Processing Data Files")
        self.landing_to_raw_processor()