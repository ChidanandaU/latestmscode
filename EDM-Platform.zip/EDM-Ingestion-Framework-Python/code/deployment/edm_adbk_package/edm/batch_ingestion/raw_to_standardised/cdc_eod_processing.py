import pyspark.sql.functions as f
from pyspark.sql import types as t
from edm.batch_ingestion.landing_to_raw.landing_to_raw_processor import (
    LandingToRawProcessor
)

from edm.utils.const import (
    RAW_ZONE_CDC_PATH,
    SOURCE_FILE_PROCESS_QUERY,
    RTS_GET_SOURCE_COUNTRY_CODE
    )

from edm.utils.logging_utility import get_logger

from edm.utils.general_helper import (
    initialise
)

LOGGER = get_logger(__name__)


class CDCEODProcessor:
    '''
    This class is used to process the EOD Marker
    or recon files for processing CDC data
    '''
    def __init__(
        self, source_id, source_object_id, file_name,
        spark, dbutils, sc, **kwargs
    ):
        '''
        This instantiates a CDC EOD Processor object
        '''
        self.source_id = source_id
        self.source_object_id = source_object_id
        self.file_name = file_name
        self.spark = spark
        self.dbutils = dbutils
        self.sc = sc
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def cdc_eod_processor(self):
        '''
        This method is used to process the EOD or recon
        files for CDC data
        '''
        try:
            # Extracting EOD Marker Strategy from the file name
            if self.file_name.upper().find('CDC_EOD_MARKER') != -1:
                eod_marker_strategy = 'global_eod'
            elif self.file_name.upper().find('RECON') != -1:
                eod_marker_strategy = 'table_level_eod'

            # Getting file info from technical metastore.
            query = SOURCE_FILE_PROCESS_QUERY.format(
                self.source_id, self.source_object_id, self.file_name)
            results = self.db_obj.get_df_from_query(query)

            # Processing all the required files
            for _, file_info in results.iterrows():
                pipeline_log_id = file_info['PipelineLogID']
                source_file_process_log_id = file_info[
                    'SourceFileProcessLogID']
                source_count = file_info['SourceCount']
                source_path = file_info['RawPath']
                # Getting Source name & country code using source id
                query = RTS_GET_SOURCE_COUNTRY_CODE.format(self.source_id)
                results = self.db_obj.get_df_from_query(query)
                source_name = results['SourceName'].values[0]
                country_name = results['CountryCode'].values[0]

                # Defining source path
                cdc_common_path = (
                    RAW_ZONE_CDC_PATH.replace(
                        'account', self.adls_account_name
                    )
                )

                cdc_path = (
                    f'{cdc_common_path}/{source_path}')
                # Reading data
                schema, schema_info, col_to_cast = LandingToRawProcessor \
                    .object_schema_width_rules(self, self.source_object_id)

                LOGGER.info("Reading data from EOD Marked/recon File")

                data = self.spark.read \
                    .option("multiline", "true") \
                    .option("parserLib", "univocity") \
                    .option('delimiter', '\u0001') \
                    .option("ignoreTrailingWhiteSpace", "true") \
                    .csv(cdc_path + '/*.snappy', schema=schema, header=True)

                LOGGER.info("Finished Reading data from EOD Marked/recon File")

                # Defining columns for Table level EOD
                if eod_marker_strategy == 'table_level_eod':
                    df = data.select(
                        'SRC_STM', 'SRC_CTRY', 'TBL_NAME','JOURNALDATE')
                    df = df.withColumnRenamed('SRC_STM', 'SourceName')
                    df = df.withColumnRenamed('SRC_CTRY', 'CountryCode')
                    df = df.withColumnRenamed('TBL_NAME', 'ObjectName')
                    df = df.withColumnRenamed('JOURNALDATE', 'EODMarker')
                    df = df.withColumn('EODMarkerStrategy', f.lit(
                        eod_marker_strategy))

                # Defining columns for Global EOD
                if eod_marker_strategy == 'global_eod':
                    eod_marker_time = (
                        data.agg({"MARKER_TIME": "max"}).collect()[0][0]
                    )
                    data = [
                        source_name, country_name, 'all',
                        eod_marker_time, eod_marker_strategy]
                    rdd = self.sc.parallelize([data])
                    columns = t.StructType().add(
                        'SourceName', t.StringType(), True) \
                        .add('CountryCode', t.StringType(), True) \
                        .add('ObjectName', t.StringType(), True) \
                        .add('EODMarker', t.StringType(), True) \
                        .add('EODMarkerStrategy', t.StringType(), True)

                    df = self.spark.createDataFrame(rdd, columns)
                # Update EOD Marker time in CDC Watermark table
                LOGGER.info("Updating CDC Watermark Table")
                schema = 'ETLlog'
                cdc_sp = 'uspUpsertCDCWatermark'
                table_type = 'TableType_CDCWatermark'
                final_df = df.select("*").toPandas()
                if not final_df.empty:
                    self.db_obj.insert_data_from_df(
                        schema,
                        cdc_sp,
                        final_df,
                        table_type
                    )
                LOGGER.info("Finished Updating CDC Watermark Table")
                # Update the status in SourceFileProcessLog
                target_count = df.count()
                error_count = source_count - target_count
                params = {
                    'PipelineLogID': pipeline_log_id,
                    'SourceFileProcessLogID': source_file_process_log_id,
                    'SourceCount': source_count,
                    'TargetCount': target_count,
                    'ErrorCount': error_count,
                    'IsLandingToRawProcessed': 1,
                    'IsRawtoStandardisedProcessed': 1,
                    'sourceObjectID': self.source_object_id,
                    'sourceID': self.source_id,
                    'PipelineStatus': 'Succeeded',
                    'RawFileStatus': 'Completed'
                    }
                schema = 'ETLlog'
                stored_proc = 'uspUpdatePipelineLog'
                self.db_obj.run_stored_proc(schema, stored_proc, params)

        except Exception as err:
            LOGGER.exception("Exception: " + str(err))
            param = {
                'SourceFileProcessLogID': source_file_process_log_id,
                'SourceId': self.source_id,
                'SourceCount': source_count,
                'TargetCount': None,
                'ErrorCount':None,
                'SourceObjectId': self.source_object_id,
                'PipelineLogID': pipeline_log_id,
                'RawFileStatus': 'Failed',
                'IsLandingToRawProcessed': 1,
                'IsRawtoStandardisedProcessed': 0,
                'PipelineStatus': 'Failed'
                }
            self.db_obj.run_stored_proc(
                'ETLlog', 'uspUpdatePipelineLog', params=param
            )

    def run(self):
        '''
        This method is used to run the EOD/recon file processsing
        '''
        LOGGER.info("Starting EOD File Processing")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        LOGGER.info("Ended Initialisation")
        self.cdc_eod_processor()
        LOGGER.info("Finished EOD File Procesing")