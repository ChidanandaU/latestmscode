import json
import datetime
import uuid

import pandas as pd

from edm.batch_ingestion.landing_to_raw.landing_to_raw_processor import (
    LandingToRawProcessor
)
from edm.utils.const import (
    CHECK_FILE_RE_RUN,
    ERROR_ZONE_DATA_PATH,
    GET_COL_DEFAULT_VALUES,
    RAW_ZONE_DATA_PATH,
    RAW_ZONE_CDC_PATH,
    REJECT_ZONE_DATA_PATH,
    STANDARDIZE_ZONE_DATA_PATH,
    SOURCE_FILE_PROCESS_QUERY,
    RTS_GET_SOURCE_COUNTRY_CODE,
    RTS_SOURCE_OBJECT_DETAIL,
    GET_SOURCE_OBJECT_ID,
    GET_HEADER_TARILER_ROW_COUNT,
    DELTA_EXTRA_TRAIL_COLS,
    TXN_EXTRA_TRAIL_COLS,
    GET_IS_PRIMARY_KEY,
    GET_CDC_WATERMARK
)

from edm.utils.general_helper import (
    get_file_delimiter, initialise, get_filename_date_index
)
from edm.utils.logging_utility import get_logger
from pyspark.sql import types as t
from pyspark.sql import functions as f
from pyspark.sql import DataFrame

LOGGER = get_logger(__name__)


class RawToStandardizeProcessor:
    '''
    This class is used to process the data file
    from Raw to Standardize zone after applying
    all the necessary validations.
    '''

    def __init__(
        self, source_id, source_object_id,
        file_name, spark, dbutils, **kwargs
    ):
        '''
        This instantiates a Raw To Standardized Object
        '''
        self.source_id = source_id
        self.source_object_id = source_object_id
        self.file_name = file_name
        self.spark = spark
        self.dbutils = dbutils
        self.spn_credentials = kwargs.get("spn_credentials", None)
        self.kv_name = kwargs.get("kv_name", None)
        self.adls_account_name = kwargs.get("adls_account_name", None)
        self.config_path = kwargs.get("config_path", None)

    def control_file_processing(
        self, cs_properties, source_name,
        country_name, object_name, business_date
    ):
        LOGGER.info("Control file processing started.")
        ctrl_file = cs_properties['control_file']
        if ctrl_file in ('true', 'True'):
            # Defining control file path
            control_file_path = (
                RAW_ZONE_DATA_PATH.replace(
                    'account', self.adls_account_name
                ).replace(
                    "data", "control"
                ).replace(
                    "source", source_name
                ).replace(
                    "country", country_name
                )
            )
            hschema, _, hcol_to_cast = LandingToRawProcessor \
                .object_schema_width_rules(
                    self,
                    self.source_object_id,
                    'headercolschema'
                )
            hschema = hschema.add('ID', t.IntegerType(), True)
            tschema, _, tcol_to_cast = LandingToRawProcessor \
                .object_schema_width_rules(
                    self,
                    self.source_object_id,
                    'trailercolschema'
                    )
            tschema = tschema.add('ID', t.IntegerType(), True)
            # ctrl_file_identifier
            if 'control.file.identifier' in cs_properties.keys():
                ctrl_file_identifier = cs_properties['control.file.identifier']
                ctrl_file_identifier = (
                    ctrl_file_identifier.replace("*", '').upper()
                )
            else:
                ctrl_file_identifier = 'CONTROL'
            control_data = self.spark.read \
                .option("parserLib", "univocity") \
                .option("ignoreTrailingWhiteSpace", "true") \
                .csv(
                    f'{control_file_path}/{source_name.upper()}_{country_name.upper()}_{ctrl_file_identifier}_{business_date}*')
            control_data_pd_df = control_data.toPandas()
            control_data_pd_df['ID'] = control_data_pd_df.index+1
            control_data = self.spark.createDataFrame(control_data_pd_df)
            h_data = self.spark \
                .createDataFrame(
                    control_data.where(
                        (f.col('_c0') == 'H') & (f.lower(f.col('_c3')) == object_name.lower())
                    ).rdd, schema=hschema)
            row_id = h_data.select('ID').collect()[0][0]
            for key, value in hcol_to_cast.items():
                if 'DECIMAL' or 'decimal' in value:
                    continue
                else:
                    h_data = h_data.withColumn(key, f.col(key).cast(value))
            trailer = control_data.where(
                (f.col('_c0') == 'T') & (f.col('ID') == (row_id + 1))
            )
            countNullValues = trailer \
                .select(
                    [f.count(f.when(f.col(a).isNull(), a)).alias(a) for a in trailer.columns]
                    ).collect()[0].asDict()
            columnDrop = [d for d, n in countNullValues.items() if n > 0]
            trailer = trailer.drop(*columnDrop)
            t_data = self.spark.createDataFrame(
                trailer.rdd,
                schema=tschema
            )
            for key, value in tcol_to_cast.items():
                if 'DECIMAL' or 'decimal' in value:
                    continue
                else:
                    t_data = t_data.withColumn(key, f.col(key).cast(value))
            hdata_dict = h_data.collect()[0]
            tdata_dict = t_data.collect()[0]  # list of rows
            metadata = {
                'header': hdata_dict.asDict(),
                'trailer': tdata_dict.asDict()
            }
            table_name = metadata['header']['table'].lower()
            rowcount = metadata['trailer']['ROWCOUNT']
            businessdate = metadata['header']['hDate']
            query = GET_SOURCE_OBJECT_ID.format(
                source_name, country_name, table_name
            )
            results = self.db_obj.get_df_from_query(query)
            if len(results) > 0:
                object_id = results['SourceObjectID'].values[0]
                param = {
                    'SourceObjectID': object_id,
                    'Metadata': json.dumps(metadata),
                    'RowCount': rowcount,
                    'BusinessDate': businessdate}

                self.db_obj.run_stored_proc(
                    'ETLlog',
                    'SourceFileHeaderTrailerLogProc',
                    params=param
                )

    def data_row_count_check(
        self, data, cs_properties, raw_path, source_count,
        pipeline_log_id, source_file_process_log_id, business_date
    ):
        '''
        This method is used to validate the source data row count
        with header trailer row count and move the file to reject zone,
        if the row count validation fails.
        '''
        LOGGER.info("Row count validation started.")
        row_count_check = True
        query = GET_HEADER_TARILER_ROW_COUNT.format(
            self.source_object_id, business_date
        )
        results = self.db_obj.get_df_from_query(query)
        df_count = data.count()
        skip_row_flag = True
        if len(results) > 0:
            received_row_count = results['RowCount'].values[0]
        if 'skip.row.count' in cs_properties:
            if cs_properties['skip.row.count'].lower() == 'false':
                skip_row_flag = False
            else:
                LOGGER.info("Skip Row count is True.")
        else:
            if len(results) > 0:
                skip_row_flag = False

        if not skip_row_flag:
            if len(results) > 0:
                if df_count != received_row_count:
                    LOGGER.info(
                        '''
                        Rejecting the file due to row count
                        mismatch.
                        '''
                    )
                    # Reject the file
                    row_count_check = False
                    self.dbutils.fs.mv(raw_path, self.reject_path, recurse = True)
                    self.update_source_db(
                        0, source_count, 0, pipeline_log_id,
                        source_file_process_log_id, 1, 0,
                        'Succeeded', 'Rejected - Row Count Validation Failed'
                    )
                else:
                    LOGGER.info("Row count validation successful !!.")
            else:
                LOGGER.info(
                    '''
                    Rejecting the file as skip row count is false
                    and metadata info is not available.
                    '''
                )
                # Reject the file
                row_count_check = False
                self.dbutils.fs.mv(raw_path, self.reject_path, recurse = True)
                self.update_source_db(
                    0, source_count, 0, pipeline_log_id,
                    source_file_process_log_id, 1, 0,
                    'Succeeded',
                    'Rejected - Row Count Not available in Trailer'
                )
        return row_count_check

    def data_column_count_check(
        self, data, schema_info, raw_path, source_count,
        pipeline_log_id, source_file_process_log_id
    ):
        '''
        This method is used to validate if the received data file has
        the same number of columns as present in the SQL Metastore. If not,
        the data file is rejected and moved to the reject zone.
        '''
        LOGGER.info("Column count validation started.")
        column_count_check = True
        col_count_from_properties = len(schema_info)
        if col_count_from_properties == len(data.columns):
            LOGGER.info("Column count validation successful.")
        else:
            LOGGER.info(
                "Rejecting the file due to column length mismatch."
            )
            # Move to reject directory
            column_count_check = False
            self.dbutils.fs.mv(raw_path, self.reject_path, recurse = True)
            self.update_source_db(
                0, source_count, 0, pipeline_log_id,
                source_file_process_log_id, 1, 0, 'Succeeded',
                'Rejected - Column Count Validation Failed'
            )
        return column_count_check

    def add_audit_columns(self, data, file_name, business_date):
        '''
        This method is used to add the audit columns to the Dataframe
        holding the data.
        '''
        LOGGER.info("Adding audit columns to data.")
        uuidUdf = f.udf(lambda: str(uuid.uuid4()), t.StringType())

        # If file is a CDC file, use business date as date
        file_name = file_name.replace('$', '')
        df_added_columns = data.withColumn(
            "date", f.lit(business_date)
            ) \
            .withColumn(
                'time', f.expr(
                    "reflect('java.time.LocalDateTime', 'now')"
                ).cast("string")
            ) \
            .withColumn('RowID',  uuidUdf()) \
            .withColumn('file', f.lit(file_name))

        df_added_columns = df_added_columns\
            .withColumn('time', f.translate(f.col("time"), "-:.", ""))
        df_added_columns = df_added_columns\
            .withColumn('time', f.trim(f.col('time')))
        df_added_columns = df_added_columns\
            .withColumn(
                'RowID', f.concat(
                    f.col('time'), f.lit('_'), f.col('RowID')
                )
            )
        df_added_columns = df_added_columns\
            .select(data.columns+['date', 'RowID', 'file'])
        LOGGER.info("Audit columns added successfully")
        df_added_columns.persist()
        return df_added_columns

    def data_date_col_transformations(self, df_added_columns):
        '''
        This method is used to perorm transformations on date columns
        to bring them to a common Date Format.
        '''
        LOGGER.info("Date columns transformation started.")
        # TODO: Integrate ColumnTransformationRules.xml
        func = f.udf(
            lambda x: datetime.datetime.strptime(x, '%Y%m%d'), t.DateType()
        )
        df_added_columns = df_added_columns \
            .withColumn(
                'date', f.date_format(func(f.col('date')), 'MM-dd-yyy') # 09-08-2021
            )
        LOGGER.info("Date columns transformation completed.")
        return df_added_columns

    def data_key_col_check(
        self, df_added_columns, pk_stmt,
        pipeline_log_id, source_file_process_log_id
    ):
        '''
        This method is used to validate if any Pk cols are null or not.
        if any of the rows PK values are null, those values are moved to the reject zone.
        '''
        # Key Columns Check
        LOGGER.info("Key columns check started.")
        df_invalid_col = None
        if pk_stmt != ' is NULL) ':
            df_key_col_check = df_added_columns \
                .filter(pk_stmt)
            if df_key_col_check.count() > 0:
                col_list = list(df_key_col_check.columns)
                df_invalid_col = df_key_col_check\
                    .select('RowID',
                            f.to_json(
                                f.struct(col_list)
                            ).alias("ErrorData")
                            )
                df_invalid_col = df_invalid_col \
                    .withColumn(
                        'PipelineID',
                        f.lit(pipeline_log_id)) \
                    .withColumn(
                        'SourceObjectId',
                        f.lit(self.source_object_id)) \
                    .withColumn(
                        'SourceFileProcessLogId',
                        f.lit(source_file_process_log_id)) \
                    .withColumn(
                        'ErrorCode',
                        f.lit('PK Null Check')) \
                    .withColumn(
                        'ErrorDescription',
                        f.lit('Primary Key column are Null')
                        )\
                    .withColumn(
                        'ErrorType',
                        f.lit('Validation Error')
                    )
                df_invalid_col_distinct = df_invalid_col.select('RowID').distinct()
                df_invalid_col_distinct.createOrReplaceTempView("RejectedRowID")
                df_added_columns.createOrReplaceTempView("FinalData")
                df_added_columns = self.spark.sql('SELECT fd.*  \
                                    FROM FinalData fd \
                                    LEFT JOIN RejectedRowId rr \
                                    ON fd.RowId = rr.RowId \
                                    WHERE rr.RowId IS NULL')
                # df_invalid_col = df_invalid_col.toPandas()
                # Error Logging
                if df_invalid_col.count() > 0:
                    df_invalid_col = (
                        df_invalid_col.withColumn(
                            'CreatedOn', f.lit(datetime.datetime.now()))
                    )
                    df_invalid_col = (
                        df_invalid_col.withColumn(
                            'CreatedOn_', f.lit(datetime.datetime.now()))
                    )
                    df_invalid_col.coalesce(1).write.format('delta').\
                        mode('append').\
                        partitionBy('CreatedOn_').\
                        option('mergeSchema', 'true').\
                        save(self.file_process_error_path)
                    #     schema = 'ETLlog'
                    #     stored_proc = 'uspInsertFileProcessErrorLog'
                    #     table_type = 'TableType_FileProcessErrorLog'
                    #     self.db_obj.insert_data_from_df(
                    #                         schema,
                    #                         stored_proc,
                    #                         df_invalid_col,
                    #                         table_type)
        else:
            LOGGER.info("No PK cols are null")
        return df_added_columns

    def data_type_check(
        self, df_added_columns,
        pipeline_log_id, source_file_process_log_id,
        source_count, source_path, dtype_list
    ):
        '''
        This method is used to check if the Data has the same data types as recorded from the config file.
        if not, the file is moved to reject zone and the Process Stops.
        '''
        # Data Type Validation
        LOGGER.info("Data Type Validation started.")
        data_type_check_flag = True
        df_dtype_val = df_added_columns.dtypes
        dtype_validation = set(df_dtype_val).difference(set(dtype_list))
        if dtype_validation == {('date', 'string'), ('RowID', 'string'), ('file', 'string')}:
            LOGGER.info('Data Type Validation successful')
        else:
            data_type_check_flag = False
            mismtached_cols_dtype = dtype_validation - {('date', 'string'), ('RowID', 'string'), ('file', 'string')}
            mismtached_cols_dtype = {cols[0]:cols[1] for cols in mismtached_cols_dtype}
            mismtached_cols_str = json.dumps(mismtached_cols_dtype)
            table_type_dict = {
                'PipelineID': pipeline_log_id,
                'SourceObjectId': self.source_object_id,
                'SourceFileProcessLogId': source_file_process_log_id,
                'ErrorType': 'Validation Error',
                'ErrorCode': 'Data Type Check',
                'ErrorDescription': 'Data Type Check Failed',
                'ErrorData': mismtached_cols_str,
                'RowID': None
            }
            df_error_log_schema = t.StructType([
                t.StructField('PipelineID', t.IntegerType(), True),
                t.StructField('SourceObjectId', t.IntegerType(), True),
                t.StructField('SourceFileProcessLogId', t.IntegerType(), True),
                t.StructField('ErrorType', t.StringType(), True),
                t.StructField('ErrorCode', t.StringType(), True),
                t.StructField('ErrorDescription', t.StringType(), True),
                t.StructField('ErrorData', t.StringType(), True),
                t.StructField('RowID', t.StringType(), True)
            ])
            df_error_log = pd.DataFrame(data=[table_type_dict])
            df_error_log_spark = self.spark.createDataFrame(
                df_error_log, schema=df_error_log_schema
            )

            if df_error_log_spark.count() > 0:
                df_error_log_spark = (
                    df_error_log_spark.withColumn(
                        'CreatedOn', f.lit(datetime.datetime.now()))
                )
                df_error_log_spark = (
                    df_error_log_spark.withColumn(
                        'CreatedOn_', f.lit(datetime.datetime.now()))
                )
                df_error_log_spark.coalesce(1).write.format('delta').\
                    mode('append').partitionBy('CreatedOn_').\
                    option('mergeSchema', 'true').\
                    save(self.file_process_error_path)
            #   schema = 'ETLlog'
            #   stored_proc = 'uspInsertFileProcessErrorLog'
            #   table_type = 'TableType_FileProcessErrorLog'
            #   self.db_obj.insert_data_from_df(
            #                       schema,
            #                       stored_proc,
            #                       df_error_log,
            #                       table_type)
            self.update_source_db(
                0, source_count, 0, pipeline_log_id,
                source_file_process_log_id, 1, 0,
                'Succeeded', 'Rejected - Data Type Validation Failed')
            self.dbutils.fs.mv(source_path, self.reject_path, recurse = True)
            LOGGER.info('Data Type Validation falied')
        return data_type_check_flag

    def max_length_check(
        self, df_added_columns, schema_info, pk_col_list, pipeline_log_id,
        source_file_process_log_id
    ):
        LOGGER.info('Max Length check started')
        col_list = df_added_columns.columns
        if len(pk_col_list) > 0:
            error_col_list = pk_col_list
        else:
            error_col_list = col_list
        df_length = df_added_columns

        schema_info_dict = {item[0]: item[5] for item in schema_info if item[5] is not None and item[5] !=0 and item[1] == 'string'}

        df_length = df_length.withColumn(
            'ErrorData', f.to_json(f.struct(error_col_list)))
        df_length = df_length.withColumn(
                'PipelineID', f.lit(pipeline_log_id))
        df_length = df_length.withColumn(
            'SourceObjectId', f.lit(self.source_object_id)
        )
        df_length = df_length.withColumn(
            'SourceFileProcessLogId', f.lit(
                source_file_process_log_id)
        )
        df_length = df_length.withColumn(
            'ErrorCode', f.lit('Max Length Check Failed')
        )
        df_length = df_length.withColumn(
            'ErrorDescription', f.lit('Max Length Check Failed'))
        df_length = df_length.withColumn(
            'ErrorType', f.lit('Validation Error')
        )
        df_length.createOrReplaceTempView('MaxLengthCheckView')
        max_length_where_clause = self.create_max_length_where_clause(
            schema_info_dict)
        max_length_query = f'\
        SELECT RowID, ErrorData, PipelineID, SourceObjectId, \
            SourceFileProcessLogId, ErrorCode, ErrorDescription, \
                ErrorType FROM MaxLengthCheckView \
                    WHERE {max_length_where_clause}'

        final_invalid_records = self.spark.sql(max_length_query)
        invalid_record_count = final_invalid_records.count()
        if invalid_record_count > 0:
            final_invalid_records_distinct = final_invalid_records.select('RowID').distinct()
            final_invalid_records_distinct.createOrReplaceTempView("RejectedRowId")            
            df_added_columns.createOrReplaceTempView("FinalData")
            df_added_columns = self.spark.sql('SELECT fd.*  \
                                    FROM FinalData fd \
                                    LEFT JOIN RejectedRowId rr \
                                    ON fd.RowId = rr.RowId \
                                    WHERE rr.RowId IS NULL')
            final_invalid_records = (
                final_invalid_records.withColumn(
                    'CreatedOn', f.lit(datetime.datetime.now()))
            )
            final_invalid_records = (
                final_invalid_records.withColumn(
                    'CreatedOn_', f.lit(datetime.datetime.now()))
            )
            final_invalid_records.coalesce(1).write.format('delta').\
                mode('append').\
                partitionBy('CreatedOn_').\
                option('mergeSchema', 'true').\
                save(self.file_process_error_path)

            # final_invalid_records = final_invalid_records.toPandas()
            # schema = 'ETLlog'
            # stored_proc = 'uspInsertFileProcessErrorLog'
            # table_type = 'TableType_FileProcessErrorLog'
            # self.db_obj.insert_data_from_df(
            #     schema,
            #     stored_proc,
            #     final_invalid_records,
            #     table_type)

        return df_added_columns

    def create_max_length_where_clause(self, schema_info_dict):
        logical_cond_list = list()
        for col in schema_info_dict.keys():
            logical_cond_str = (
                "NVL(LENGTH(" + col + "),0) >" + str(schema_info_dict[col])
            )
            logical_cond_list.append(logical_cond_str)
        where_clause_str = " OR ".join(logical_cond_list)
        return where_clause_str

    def perform_re_run_process(
        self, source, country,
        object_name, business_date
    ):
        object_name = object_name.replace('$', '')
        delta_table_name = f'{source}_{country}_{object_name}_delta'
        business_date = (
            datetime.datetime.
            strptime(business_date, '%Y%m%d').
            strftime('%m-%d-%Y')
        )
        file_name = self.file_name.replace('$', '')
        # check if delta table exists
        table_exists = self.spark.sql(f"SHOW TABLES '{delta_table_name}'")
        if table_exists.count() > 0:
            sql_query = CHECK_FILE_RE_RUN.format(self.file_name)
            result = self.db_obj.get_df_from_query(sql_query)
            if len(result) > 0:
                delete_existing_part_rows = (f"DELETE FROM \
                    {delta_table_name} WHERE file = '{file_name}' \
                        AND date = '{business_date}'")
                self.spark.sql(delete_existing_part_rows)

    def raw_to_standardize_processor(self):
        '''
        This method is used to process the data files
        present in raw zone and move it to standardized
        layer.
        '''
        try:
            # Getting info of file to be processed.
            query = SOURCE_FILE_PROCESS_QUERY.format(
                self.source_id, self.source_object_id, self.file_name)
            results = self.db_obj.get_df_from_query(query)

            eod_marker_strategy = None

            # Processing all the required files
            for _, file_info in results.iterrows():
                pipeline_log_id = file_info['PipelineLogID']
                source_file_process_log_id = file_info['SourceFileProcessLogID']
                file_name = file_info['FileName']
                source_count = file_info['SourceCount']
                source_path = file_info['RawPath']
                cdc_file_flag = file_info['IsCDCFile']

                # Getting Source name & country code using source id
                query = RTS_GET_SOURCE_COUNTRY_CODE.format(self.source_id)
                results = self.db_obj.get_df_from_query(query)
                source_name = results['SourceName'].values[0]
                country_name = results['CountryCode'].values[0]

                # Reading data from source master and source object tables
                query = RTS_SOURCE_OBJECT_DETAIL.format(self.source_object_id)
                results = self.db_obj.run_sql_query(query)
                cs_properties = json.loads(results[0][0][0])
                object_name = results[0][0][2]
                object_type = results[0][0][3]

                # Defining destination path
                standardized_path = (
                    STANDARDIZE_ZONE_DATA_PATH.replace(
                        'account', self.adls_account_name
                    ).replace(
                        "source",
                        source_name
                    ).replace(
                        "country",
                        country_name
                    ))
                self.file_process_error_path = (
                    ERROR_ZONE_DATA_PATH.replace(
                        'account', self.adls_account_name
                    ))
                self.file_process_error_path += 'file_process_error_log'
                # Get date index
                if cdc_file_flag:
                    file_name_part_list = file_name.split(".")
                    business_date = file_name_part_list[1].strip('D')
                    business_date= datetime.datetime.strptime(business_date, '%Y%j').date()
                    business_date = business_date.strftime('%Y%m%d')
                    business_time = file_name_part_list[1].strip('T')
                    eod_marker_strategy = cs_properties['eod.marker.strategy']
                else:
                    date_index = get_filename_date_index(file_name)
                    file_content = file_name.split('_')
                    business_date = file_content[date_index].strip('.csv').strip('.dat')
                # Check for re-run logic for txn files
                if object_type.lower() == 'txn':
                    self.perform_re_run_process(
                        source_name, country_name, object_name, business_date
                    )
                self.reject_path = (REJECT_ZONE_DATA_PATH.replace(
                            'account', self.adls_account_name
                        ).replace(
                            "source",
                            source_name
                        ).replace(
                            "country",
                            country_name
                        )
                )
                # Defining source path
                if cdc_file_flag:
                    data_source = (
                        RAW_ZONE_CDC_PATH.replace(
                            'account', self.adls_account_name)
                    )
                    raw_path = (
                        f'{data_source}{source_path}')
                    self.reject_path = (
                        f"{self.reject_path}/{source_path.split(country_name+'/')[1]}"
                    )
                else:
                    data_source = (
                        RAW_ZONE_DATA_PATH.replace(
                            'account', self.adls_account_name
                        ).replace(
                            "source",
                            source_name
                        ).replace(
                            "country",
                            country_name
                        )
                    )
                    source_path = source_path.split(country_name+'/')[1]
                    raw_path = f'{data_source}/{source_path}'
                    self.reject_path = (
                        f"{self.reject_path}/{source_path}"
                    )

                # Reading data
                schema, schema_info, col_to_cast = LandingToRawProcessor \
                    .object_schema_width_rules(self, self.source_object_id)
                # get select col list
                select_col_list = [f"{item[0]} {item[1]}" for item in schema_info]
                if object_type.lower() == 'delta':
                    select_col_list = (
                        ['RowID string'] + select_col_list +
                        DELTA_EXTRA_TRAIL_COLS
                    )
                else:
                    select_col_list = (
                        ['RowID string'] + select_col_list +
                        TXN_EXTRA_TRAIL_COLS
                    )
                self.col_dtype_str = ",".join(select_col_list)
                # get file delimiter
                delimiter = get_file_delimiter(
                    cs_properties, cdc_file_flag, self.file_name)
                if cdc_file_flag:
                    data = self.spark.read \
                        .option("multiline", "true") \
                        .option("parserLib", "univocity") \
                        .option('delimiter', delimiter) \
                        .option("ignoreTrailingWhiteSpace", "true") \
                        .csv(
                            raw_path + '/*.snappy', inferSchema=True,
                            header=True)
                    # Column count validation
                    column_count_check = self.data_column_count_check(
                        data, schema_info, raw_path, source_count,
                        pipeline_log_id, source_file_process_log_id)
                    if column_count_check is not True:
                        break
                    data = self.spark.read \
                        .option("multiline", "true") \
                        .option("parserLib", "univocity") \
                        .option('delimiter', delimiter) \
                        .option("ignoreTrailingWhiteSpace", "true") \
                        .csv(
                            raw_path + '/*.snappy', schema=schema,
                            header=True)
                else:
                    data = self.spark.read \
                        .option("parserLib", "univocity") \
                        .option("ignoreTrailingWhiteSpace", "true") \
                        .option('delimiter', delimiter)\
                        .csv(
                            raw_path + '/*.snappy', inferSchema=True,
                            header=True)
                    # Column count validation
                    column_count_check = self.data_column_count_check(
                        data, schema_info, raw_path, source_count,
                        pipeline_log_id, source_file_process_log_id)
                    if column_count_check is not True:
                        break

                    data = self.spark.read \
                        .option("parserLib", "univocity") \
                        .option("ignoreTrailingWhiteSpace", "true")\
                        .option('delimiter', delimiter)\
                        .csv(
                            raw_path + '/*.snappy', schema=schema,
                            header=True)

                for key, value in col_to_cast.items():
                    data = data.withColumn(key, f.col(key).cast(value))

                # Control File Processing
                self.control_file_processing(
                    cs_properties, source_name,
                    country_name, object_name, business_date
                )

                # Row Count Validation
                row_count_check = self.data_row_count_check(
                    data, cs_properties, raw_path, source_count,
                    pipeline_log_id, source_file_process_log_id,
                    business_date
                )
                if row_count_check is not True:
                    break

                # Adding columns to data
                df_added_columns = self.add_audit_columns(
                    data, file_name, business_date)
                # Replace Nullable Columns with Default Value
                df_added_columns, rows_with_null_values = (
                    self.replace_null_values_with_default(
                        df_added_columns, source_name,
                        country_name, object_name)
                )
                # Date Columns Transformation
                df_added_columns = self.data_date_col_transformations(
                    df_added_columns)
                # TODO : Default capturing, replacement & logging.

                LOGGER.info("Generating necessary info for validations.")
                pk_stmt = ' is NULL) '
                dtype_list = []
                pk_col_list = []
                for items in schema_info:
                    col_name = items[0]
                    col_type = items[1]
                    # Generating pk statement
                    if items[4]:
                        pk_col_list.append(col_name)
                        if pk_stmt == ' is NULL) ':
                            pk_stmt = '(' + col_name + pk_stmt # (x is NULL)
                        else:
                            pk_stmt += f'or ({col_name} is NULL) ' # (x is NULL) or (Y is NULL)
                    # Generating datatype validation tuple
                    dtype_list.append((col_name, col_type.lower())) # [(x, string), (y, Date)]

                # Key Columns Check
                df_added_columns = self.data_key_col_check(
                    df_added_columns, pk_stmt, pipeline_log_id,
                    source_file_process_log_id
                )

                data_type_check_flag = self.data_type_check(
                    df_added_columns, pipeline_log_id,
                    source_file_process_log_id, source_count, raw_path,
                    dtype_list
                )
                if data_type_check_flag is not True:
                    break

                # Max Length Check
                df_added_columns = self.max_length_check(
                    df_added_columns, schema_info, pk_col_list,
                    pipeline_log_id, source_file_process_log_id
                )
                # Not Null check
                # Source Reconciliation
                LOGGER.info('Source Reconciliation started')
                if ('recon' or 'RECON') in file_name:
                    self.recon(df_added_columns)
                LOGGER.info('Source Reconciliation completed')

                # CDC File processing
                if cdc_file_flag:
                    LOGGER.info('Starting CDC File Processing')
                    final_df = self.process_cdc_data(
                            df_added_columns,
                            source_name,
                            country_name,
                            object_name,
                            source_count,
                            eod_marker_strategy,
                            data_source,
                            pipeline_log_id,
                            source_file_process_log_id
                            )
                    if final_df == 'data saved':
                        # self.update_source_db(final_df, source_count, pipeline_log_id, source_file_process_log_id)
                        LOGGER.info('CDC File processed successfully')
                        continue

                # Flat File processing
                part_col = None
                if object_type == 'delta':
                    if df_added_columns.count() > 0:
                        LOGGER.info('Starting Master Data Processing')
                        final_df = self.master_data_load(
                            df_added_columns,
                            source_name,
                            country_name,
                            object_name,
                            source_count,
                            pipeline_log_id,
                            source_file_process_log_id
                            )
                        if final_df == 'data saved':
                            LOGGER.info('Master Data processed successfully')
                            if rows_with_null_values.count() > 0:
                                self.log_default_value_null_records(
                                    rows_with_null_values
                                )
                            continue
                        else:
                            part_col = 'EffectiveEndDate_'
                    else:
                        final_df = df_added_columns
                else:
                    df_added_columns = df_added_columns.withColumn('isActive', f.lit('1'))
                    df_added_columns = df_added_columns.withColumn(
                        'date_', f.col('date')
                    )
                    final_df = df_added_columns
                    part_col = 'date_'
                destination_standardized = f'{standardized_path}/{object_name}/'
                # getting log counts
                final_df_distinct = final_df.distinct()
                distinct_count = final_df_distinct.count()
                target_count = final_df.count()
                duplicate_count = target_count - distinct_count

                # Saving data in delta format
                if target_count > 0:
                    LOGGER.info('Saving Data in Delta Format')
                    final_df.coalesce(1).write \
                        .format("delta") \
                        .mode("append") \
                        .option("mergeSchema", "true") \
                        .partitionBy(part_col) \
                        .save(destination_standardized)
                    LOGGER.info('Data Saved Successfully')
                    # creating delta tables
                    delta_table = source_name + '_' + country_name + '_' + object_name + '_delta'
                    delta_table = delta_table.replace('$', '')
                    delta_table_exists = self.spark.sql(
                        f"SHOW TABLES '{delta_table}'"
                    )
                    if delta_table_exists.count() == 0:
                        LOGGER.info("Creating Databricks Delta Table")
                        self.spark.sql(f"CREATE TABLE {delta_table} USING DELTA OPTIONS(path '{destination_standardized}/')")
                    else:
                        LOGGER.info("Delta Table Exists. Reordering Columns if needed.")
                        replace_query = f"ALTER TABLE {delta_table} REPLACE COLUMNS ({self.col_dtype_str})"
                        self.spark.sql(replace_query)
                    LOGGER.info('Flat file processing successful')
                    # updating source file process log table
                if rows_with_null_values.count() > 0:
                    self.log_default_value_null_records(rows_with_null_values)
                self.update_source_db(
                    target_count, source_count,
                    duplicate_count, pipeline_log_id,
                    source_file_process_log_id, 1, 1,
                    'Succeeded', 'Completed'
                )
        except Exception as err:
            LOGGER.exception("Exception: " + str(err))
            param = {
                'SourceFileProcessLogID': source_file_process_log_id,
                'SourceId': self.source_id,
                'SourceCount': source_count,
                'TargetCount': None,
                'ErrorCount':None,
                'DuplicateCount': None,
                'SourceObjectId': self.source_object_id,
                'PipelineLogID': pipeline_log_id,
                'RawFileStatus': 'Failed',
                'IsLandingToRawProcessed': 1,
                'IsRawtoStandardisedProcessed': 0,
                'PipelineStatus': 'Failed'
                }
            self.db_obj.run_stored_proc(
                'ETLlog', 'uspUpdatePipelineLog', params=param
            )

    def log_default_value_null_records(self, rows_with_null_values):
        file_process_error_path = self.file_process_error_path.replace(
            'file_process_error_log', 'warn_type'
        )
        (
            rows_with_null_values.write.format('delta')
            .mode('append').partitionBy('CreatedOn_')
            .save(file_process_error_path)
        )

    def replace_null_values_with_default(
        self, df_added_columns, source_name,
        country_name, object_name
    ):
        '''
        This method is used to replace the not null values with default
        values from the table config file if present.
        '''

        sql_query = GET_COL_DEFAULT_VALUES.format(self.source_object_id)
        result_df = self.db_obj.get_df_from_query(sql_query)
        default_col_val_dict = dict()
        rows_with_null_values = self.spark.createDataFrame(
            data=[], schema=t.StructType([])
        )
        if len(result_df) > 0:
            object_name = object_name.replace('$', '')
            delta_table_name = f'{source_name}_{country_name}_{object_name}_delta'
            df_added_columns.createOrReplaceTempView('NullValueValidation')
            query_null_col_rows = ""
            for _, row in result_df.iterrows():
                default_col_val_dict[row['ColumnName']] = row['DefaultValue']
                per_col_query = f"SELECT '{delta_table_name}' AS DeltaTableName, \
                    file AS File, RowID, '{row['ColumnName']}' AS ColumnName, \
                    '{row['DefaultValue']}' AS DefaultValue, \
                    'Default Value Applied' AS WarnCategory, \
                    current_timestamp() as CreatedOn, current_timestamp() \
                    AS CreatedOn_ FROM NullValueValidation \
                    WHERE {row['ColumnName']} IS NULL UNION ALL "
                query_null_col_rows = query_null_col_rows + per_col_query

            query_null_col_rows = (
                query_null_col_rows.strip().rstrip('ALL').strip()
            )
            query_null_col_rows = (
                query_null_col_rows.rstrip('UNION').strip()
            )
            rows_with_null_values = self.spark.sql(query_null_col_rows)
            df_added_columns = df_added_columns.na.fill(default_col_val_dict)

        return df_added_columns, rows_with_null_values

    def recon(self, df_added_columns):
        # func =  f.udf (lambda x: datetime.datetime.strptime(x, '%m-%d-%Y'), t.DateType())
        # df_recon = df_added_columns.withColumn('date', f.date_format(func(f.col('date')), 'yyyMMdd'))
        for row in map(lambda row: row.asDict(), df_added_columns.collect()):
            recon_status = 'Failed'
            target_cnt = 0
            source_name = row['src_stm']
            country_name = row['src_ctry']
            table_name = row['tbl_name'].lower()
            row_count = row['row_cnt']
            date_fld = row['eod_date']
            date_fld = (
                datetime.datetime.strptime(date_fld, '%Y%m%d').
                strftime('%m-%d-%Y')
            )
            delta_table = (
                source_name + '_' + country_name + '_' + table_name + '_delta'
            )
            check_table_query = f"SHOW TABLES '{delta_table}'"
            table_exists = self.spark.sql(check_table_query)
            if table_exists.count() > 0:
                df = self.spark.sql('select count(*) AS Count from {} where date="{}" AND isActive=1'.format(delta_table, date_fld))
                if df.first()['Count'] == row_count:
                    recon_status = 'Success'
                target_cnt = df.first()['Count']
            # source_query = f"select row_cnt from {source_name}_{country_name}_{table_name} \
            #    where ods='{date_fld}' and TBL_NAME='{delta_table}'"
            source_query = ""
            target_query = f"select count(*) AS Count from {delta_table} \
                where date=''{date_fld}'' AND isActive=1"
            business_date = date_fld
            identifier = f'{source_name}_{country_name}_{table_name}_rowcount'
            params = {
                'SourceID': self.source_id,
                'SourceObjectID': self.source_object_id,
                'identifier': identifier,
                'SourceQuery': source_query,
                'SourceValue': row_count,
                'TargetQuery': target_query,
                'TargetValue': target_cnt,
                'BusinessDate': business_date,
                'SourceReconStatus': recon_status,
                'LastSourceReconDateTime': None
            }
            schema = 'Recon'
            stored_proc = 'uspInsertEODRecon'
            self.db_obj.run_stored_proc(schema, stored_proc, params)

    def update_source_db(
        self,
        target_count,
        source_count,
        duplicate_count,
        pipeline_log_id,
        source_file_process_log_id,
        is_ltr_processed,
        is_rts_processed,
        pipeline_status,
        raw_file_status
    ):
        LOGGER.info("Updating Source File Process Log Table")
        error_count = source_count - (target_count + duplicate_count)
        params = {
            'PipelineLogID':pipeline_log_id,
            'SourceFileProcessLogID': source_file_process_log_id,
            'SourceCount': source_count,
            'TargetCount': target_count,
            'ErrorCount': error_count,
            'DuplicateCount': duplicate_count,
            'IsLandingToRawProcessed': is_ltr_processed,
            'IsRawtoStandardisedProcessed': is_rts_processed,
            'sourceObjectID': self.source_object_id,
            'sourceID': self.source_id,
            'PipelineStatus': pipeline_status,
            'RawFileStatus': raw_file_status
            }
        schema = 'ETLlog'
        stored_proc = 'uspUpdatePipelineLog'
        self.db_obj.run_stored_proc(schema, stored_proc, params)

    def master_data_load(
        self,
        df,
        source_name,
        country_name,
        object_name,
        source_count,
        pipeline_log_id,
        source_file_process_log_id
        ):
        '''
        This function is used to perform SCD type 2
        on master data.
        '''
        standardized_path = (
                    STANDARDIZE_ZONE_DATA_PATH.replace(
                        'account', self.adls_account_name
                    ).replace(
                        "source",
                        source_name
                    ).replace(
                        "country",
                        country_name
                    )
                ) 
                
        destination_standardized = f'{standardized_path}/{object_name}/'

        # Defining table name
        table_name = source_name + '_' + country_name + '_' + object_name

        # Adding StartDate, EndDate, isActive columns to master data
        df=df \
            .withColumn('EffectiveStartDate', f.current_timestamp()) \
            .withColumn('EffectiveEndDate', f.lit('9999_12_31 11_31_08')) \
            .withColumn('isActive', f.lit('1'))    
        df = df \
            .withColumn('EffectiveStartDate', f.to_timestamp("EffectiveStartDate", "yyyy_MM_dd HH_mm_ss")) \
            .withColumn('EffectiveEndDate', f.to_timestamp("EffectiveEndDate", "yyyy_MM_dd HH_mm_ss"))

        # Query to fetch all the columns for particular source, country and object 
        get_columns = GET_IS_PRIMARY_KEY.format(
            source_name, country_name, object_name)
        object_cols = self.db_obj.get_df_from_query(get_columns)
        object_cols_sdf = self.spark.createDataFrame(object_cols)

        column_list = (
            ','.join(object_cols["ColumnName"])+',EffectiveStartDate,EffectiveEndDate,isActive, file, RowID, date'
            )
        src_column_list = (
            'src.'+',src.'.join(object_cols["ColumnName"])+',current_timestamp(),src.EffectiveEndDate,src.isActive, src.file, src.RowID, src.date'
        )
        src_column_select_list = (
            'src.' + ',src.'.join(object_cols["ColumnName"]) + ',current_timestamp() as EffectiveStartDate,src.EffectiveEndDate,src.isActive, src.file, src.RowID, src.date'
        )
        key_columns = object_cols_sdf \
            .filter("IsPrimaryKey==1") \
            .withColumn(
                'KeyColumnCondition',f.concat(f.lit('tar.'),f.col("ColumnName"),f.lit('=src.'),f.col("ColumnName"))
            ) \
            .select("ColumnName",'KeyColumnCondition').toPandas()
        Key_column_condition_string=' and '.join(key_columns["KeyColumnCondition"])
        non_key_columns=object_cols_sdf \
            .filter("IsPrimaryKey==0") \
            .withColumn(
                'KeyColumnCondition', f.concat(f.lit('tar.'),f.col("ColumnName"),f.lit('=src.'),f.col("ColumnName"))
            ) \
            .select('ColumnName','KeyColumnCondition').toPandas()
        non_key_columns_rowhash_list_srcstring=',"|",'.join("NVL(src."+non_key_columns["ColumnName"] + ",'')")
        non_key_columns_rowhash_list_string=',"|",'.join("NVL(tar."+non_key_columns["ColumnName"] + ",'')")

        table_name=table_name.replace('$','')
        delta_table_name = table_name+'master'
        df = df.withColumn("SerialNumber", f.monotonically_increasing_id())
        df.createOrReplaceTempView(delta_table_name)

        pk_columns = object_cols_sdf \
            .filter("IsPrimaryKey==1")\
            .select("ColumnName").toPandas()
        partition_string = ' , \n'.join(key_columns["ColumnName"])   
        df_distinct_data=self.spark.sql(f"""SELECT {column_list} FROM
                            (
                                select ROW_NUMBER() over (partition by {partition_string} ORDER BY SerialNumber DESC) AS ROWNUMBER, {column_list}
                                from {delta_table_name}
                            )
                            WHERE ROWNUMBER = 1""")
        df_distinct_data.createOrReplaceTempView(delta_table_name)
        # getting log counts for master load
        target_count = df_distinct_data.count()
        duplicate_count = source_count - target_count

        check_if_table_exists = self.spark.sql("show tables '"+table_name+"_delta'") 
        if (check_if_table_exists.count()==0):
            df=df_distinct_data.withColumn("EffectiveEndDate_", df_distinct_data["EffectiveEndDate"])
            return df
        else:
            df_overwrite_schema=df_distinct_data.filter("1=2")
            df_overwrite_schema=df_overwrite_schema.withColumn(
                "EffectiveEndDate_", df_distinct_data["EffectiveEndDate"]
            )
            df_overwrite_schema.write \
            .format("delta") \
            .mode("append") \
            .option("mergeSchema", "true") \
            .partitionBy('EffectiveEndDate_') \
            .save(
                destination_standardized
            )
            
            column_list = column_list + ', EffectiveEndDate_'
            src_column_list = src_column_list + ', src.EffectiveEndDate'

            merge_statement = f'''
            Merge INTO {table_name}_delta as tar using {delta_table_name} as src 
            on {Key_column_condition_string} WHEN Matched and 
            sha2(concat_ws({non_key_columns_rowhash_list_srcstring}),256) 
            != sha2(concat_ws({non_key_columns_rowhash_list_string}),256) 
            and tar.isActive=1 then update SET EffectiveEndDate=current_timestamp(),isActive=0,
            EffectiveEndDate_=current_timestamp()
            When Not Matched THEN INSERT ({column_list}) values ({src_column_list})'''
            self.spark.sql(merge_statement)
            
            select_statement = f'''
            Select {src_column_select_list} FROM {delta_table_name}
            as src LEFT JOIN {table_name}_delta as tar ON 
            {Key_column_condition_string} AND tar.isActive=1  
            Where tar.isActive is null
            '''
            df_append = self.spark.sql(select_statement)
            df_append=df_append.withColumn("EffectiveEndDate_", df_append["EffectiveEndDate"])
            df_append.write \
            .format('delta') \
            .mode("append") \
            .partitionBy('EffectiveEndDate_') \
            .save(
                destination_standardized
            )
            replace_query = f"ALTER TABLE {table_name}_delta REPLACE COLUMNS ({self.col_dtype_str})"
            self.spark.sql(replace_query)

            self.update_source_db(
                target_count, source_count, 
                duplicate_count ,pipeline_log_id, 
                source_file_process_log_id,1, 1, 'Succeeded', 'Completed'
            )
            return('data saved')

    def process_cdc_data(self,
            df,
            source_name,
            country_name,
            object_name,
            source_count,
            eod_marker_strategy,
            data_source,
            pipeline_log_id,
            source_file_process_log_id
    ):   
        # Fetch EOD Marker Time from watermark table
        if eod_marker_strategy == 'global_eod':  
            object_name = 'all'       
        query = GET_CDC_WATERMARK.format(
            source_name, country_name, eod_marker_strategy, object_name)
        results = self.db_obj.run_sql_query(query)

        previous_eod_timestamp = results [0][0][0]
        current_eod_timestamp = results [0][0][1]

        # Put default date if previous EOD marker time is not available
        if previous_eod_timestamp is None:
            previous_eod_timestamp = '1900-01-01 00:00:00.000000'      

        # Create temporary view from dataframe
        df.createOrReplaceTempView("tbl_temp_source")
        # Getting log counts for DB Logging
        target_count = df.count()
        updated_records_count = self.spark.sql(
            "SELECT * FROM tbl_temp_source WHERE OPERATIONTYPE = 'A' OR \
                OPERATIONTYPE = 'B'"
        ).count()
        deleted_records_count = self.spark.sql(
            "SELECT * FROM tbl_temp_source WHERE OPERATIONTYPE = 'D'").count()
        inserted_records_count = self.spark.sql(
            "SELECT * FROM tbl_temp_source WHERE OPERATIONTYPE = 'I'").count()
        # Defining target delta table name
        target_delta_table = source_name + '_' + country_name + '_' + object_name + '_delta'
        
        #Check if target tables exists
        table_exists = self.spark.catalog._jcatalog.tableExists(f"{target_delta_table}")
        
        # Create target table if it does not exists
        # Select schema from temporary view, add columns for CDC to create target delta table
        if not table_exists:
          LOGGER.info('Creating Delta table as it does not exists')
          source_table_df = self.spark.sql(f"""select * from tbl_temp_source where 1=2""")
          source_table_df = source_table_df.withColumn("EffectiveStartDate",
                                f.lit(None).cast(t.TimestampType()))
          source_table_df = source_table_df.withColumn("EffectiveEndDate",
                                f.lit(None).cast(t.TimestampType()))
          source_table_df = source_table_df.withColumn("isActive", 
                                f.lit(None).cast(t.StringType()))
          source_table_df.createOrReplaceTempView(f"tmp_{target_delta_table}")
          
          standardized_path = (
                    STANDARDIZE_ZONE_DATA_PATH.replace(
                        'account', self.adls_account_name
                    ).replace(
                        "source",
                        source_name
                    ).replace(
                        "country",
                        country_name
                    )
                ) 
                
          destination_standardized = f'{standardized_path}/{object_name}/'
          
          self.spark.sql(f"""
                  CREATE TABLE IF NOT EXISTS {target_delta_table}
                  USING delta 
                  PARTITIONED BY (EffectiveEndDate) 
                  LOCATION '{destination_standardized}' AS 
                  SELECT * FROM tmp_{target_delta_table} where 1=2
                  """)
        
        # Fetch all the columns from SQL metastore
        get_columns = GET_IS_PRIMARY_KEY.format(source_name, country_name, object_name)
        object_cols = self.db_obj.get_df_from_query(get_columns)
        object_cols_df = self.spark.createDataFrame(object_cols)  

        # Filter the df to get primary key columns
        key_columns = object_cols_df \
            .filter("IsPrimaryKey==1")\
            .select("ColumnName").toPandas()
        pk_columns = ' , \n'.join(key_columns["ColumnName"]) 
        
        # Preparing join statement based on primary keys
        merged_keys = []
        pk_keys = pk_columns.split(",")
        for keys in pk_keys:
            merged_keys.append(keys.strip())
        pk_cols_join_cond = ' and '.join(map(lambda x: f"next.{x} = base.{x}", merged_keys))

        # Preparing where condition to filter records based on EOD Marker time
        where_condition = f"where (journaldate > \
                                (cast('{previous_eod_timestamp}' as timestamp))\
                            and journaldate <= \
                                (cast('{current_eod_timestamp}' as timestamp)))"

        # Define operation sequence for CDC operations
        pushdown_query = f"""SELECT *,
        CASE 
            WHEN OPERATIONTYPE = 'I' 
                THEN 1
            WHEN OPERATIONTYPE = 'B'
                THEN 2
            WHEN OPERATIONTYPE = 'A'
                THEN 3
            WHEN OPERATIONTYPE = 'D'
                THEN 4
        END AS operation_seq
        FROM tbl_temp_source"""
        updated_data = self.spark.sql(pushdown_query)
        updated_data.createOrReplaceTempView("""tbl_updated_source""")

        # Prepare query to mark active Flag
        pushdown_query = f"""SELECT * FROM
        (
        SELECT 
        base.*,
        CASE 
            WHEN base.rnum=1 and base.operationtype <> 'D'  
                THEN '1'
            ELSE '0' 
        END as isActive,
        base.JOURNALDATE AS EffectiveStartDate,
        to_timestamp(nvl((next.next_journal_date-(interval 1 second)),
            from_unixtime(unix_timestamp("9999-12-31 23:59:59", "yyyy-MM-dd HH:mm:ss"),"yyyy-MM-dd HH:mm:ss"))) AS EffectiveEndDate
        FROM
        (
        SELECT  * ,
            row_number() over (partition by {pk_columns} 
                order by journaldate desc, operation_seq desc) AS rnum
        FROM tbl_updated_source
        {where_condition}
        ) base
        LEFT OUTER JOIN 
        (
        SELECT 
            {pk_columns},
            journaldate as next_journal_date,
            row_number() over (partition by {pk_columns} 
                order by journaldate desc,operation_seq desc ) AS rnum
        FROM tbl_updated_source    
        {where_condition}
        ) next
        ON (next.rnum = base.rnum - 1 and {pk_cols_join_cond})
        ORDER BY rnum desc) source
        """
        change_data = self.spark.sql(pushdown_query)
        
        # Check if there are any new rows to be added or updated
        if bool(change_data.head(1)):
            change_data = change_data.drop("rnum")
            change_data = change_data.drop("operation_seq")
            
            colums_select_stmt = change_data.columns
            
            # Preparing string for insert
            target_tab_col_str = ','.join(colums_select_stmt)
            target_tab_insert_val = ','.join(list(map(lambda x: f"{x}", colums_select_stmt)))
            
            # Preparing data for merge
            obsolete_df = change_data.filter(f.col("isActive") == '0')
            if bool(obsolete_df.head(1)):
                # Mark obsolete records
                obsolete_df.createOrReplaceTempView(f"temp_{target_delta_table}")
                to_be_deleted_df = obsolete_df.filter(f.col("OPERATIONTYPE") == "D")
                if bool(to_be_deleted_df.head(1)):
                    print("No of rows to be deleted(update with 'isActive = 0') : ", to_be_deleted_df.count())
                    execute_stmt = self.execute_cdc(target_delta_table, True, True,
                                                    source=to_be_deleted_df,
                                                    merge_keys=merged_keys)
                    self.spark.sql(execute_stmt)
                else:
                    self.spark.sql(f"""MERGE INTO  {target_delta_table} USING temp_{target_delta_table}
                                        ON 1=2 
                                        WHEN NOT MATCHED 
                                        THEN INSERT ({target_tab_col_str}) 
                                        VALUES ({target_tab_insert_val})""")
                
            merged_keys.append('isActive')
            to_be_updated_df = change_data.filter(f.col("isActive") == '1')
            if bool(to_be_updated_df.head(1)):
                # Insert active records
                print("No of rows to be updated : ", to_be_updated_df.count())
                execute_stmt = self.execute_cdc(target_delta_table, True, False,
                                                                source=to_be_updated_df,
                                                                merge_keys=merged_keys)
                self.spark.sql(execute_stmt)
        
        self.update_source_db(
            target_count, source_count, 0, 
            pipeline_log_id, source_file_process_log_id, 1, 1, 'Succeeded', 'Completed')
        self.update_cdc_source_count_summary(
            pipeline_log_id, updated_records_count, 
            deleted_records_count, inserted_records_count
        )
        return('data saved')
    
    def update_cdc_source_count_summary(
        self, pipeline_log_id, update_count, 
        delete_count, insert_count
    ):
        '''
        This function is used to insert the source count summary for CDC Files into
        ETLlog.CdcSourceCountSummary Table.
        '''
        params = {
            'PipelineLogID': pipeline_log_id,
            'UpdateRecords': update_count,
            'DeleteRecords': delete_count,
            'InsertRecords': insert_count
        }
        self.db_obj.run_stored_proc(
            'ETLLog','uspUpdateCdcSourceCountSummary', params=params
        )
        
    def execute_cdc(self, parameter_table_name, supply_obsolete_val, to_be_deleted,
                                  source: DataFrame, merge_keys: list) -> str:
        
        
        source.createOrReplaceTempView(f"tmp_source_{parameter_table_name}")
        cols = source.columns
        scd_type2_cols = set(cols) - {'EffectiveStartDate', 'EffectiveEndDate'}
  
       # Preparing Select statement dynamically for merge query
        select_stmnt_list = list(
            map(lambda x: "src.{}".format(x + " AS " + x + "_Key, src." + x if x in merge_keys else x), scd_type2_cols))
        select_stmnt_str = ', \n'.join(
            select_stmnt_list) + ', from_unixtime(unix_timestamp("1900-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss"))' \
                                 ' as EffectiveStartDate, src.EffectiveEndDate'
        
        # Preparing Union statement dynamically for merge query
        union_all_stmnt_list = list(
            map(lambda x: "{}".format("NULL AS " + x + "_Key, src." + x if x in merge_keys else "src." + x),
                scd_type2_cols))        
        union_all_stmnt_str = ', \n'.join(union_all_stmnt_list) + ', src.EffectiveStartDate, \
        from_unixtime(unix_timestamp("9999-12-31 23:59:59", "yyyy-MM-dd HH:mm:ss")) as EffectiveEndDate'

        
        # Preparing join condition dynamically
        joining_str_inner = ' AND '.join(list(map(lambda x: "src.{} = trg.{}".format(x, x), merge_keys)))


        joining_str_outer = ' AND '.join(list(map(lambda x: "target.{} = source.{}".format(x, x + "_Key"), merge_keys)))

        
        cols_without_ts = set(cols) - {'RowID','file','date'}

        # Preparing insert statement for merge query                                               
        insert_col_str = ' , \n'.join(cols_without_ts)
        insert_val_str = ' , \n'.join(
            list(map(lambda x: "{}".format("\'1\'" if 'isActive' in x else "source." + x), cols_without_ts)))
        
                                                       
        if supply_obsolete_val:                                           
            insert_col_str = ' , \n'.join(cols)
            insert_val_str = ' , \n'.join(
                list(map(lambda x: "{}".format("source." + x), cols))) 
            select_stmnt_str = ', \n'.join(
                select_stmnt_list) + ', src.EffectiveStartDate, src.EffectiveEndDate'
            union_all_stmnt_str = ', \n'.join(union_all_stmnt_list) + ', src.EffectiveStartDate, \
          src.EffectiveEndDate'
            
        if to_be_deleted:
            insert_col_str = ' , \n'.join(cols)
            insert_val_str = ' , \n'.join(
                list(map(lambda x: "{}".format("\'0\'" if 'isActive' in x else "source." + x), cols)))
            
        match_cols = set(filter(lambda x: 'record_' not in x, set(cols_without_ts) - set(merge_keys))) - {
            'EffectiveStartDate', 'EffectiveEndDate'}
        match_src_str = "||'-'||".join(list(map(lambda x: f"nvl(cast(src.{x} as string),'')", match_cols)))
        match_trg_str = "||'-'||".join(list(map(lambda x: f"nvl(cast(trg.{x} as string),'')", match_cols)))
        match_str_inner = f"md5({match_src_str}) <> md5({match_trg_str})"

        match_src_str = "||'-'||".join(list(map(lambda x: f"nvl(cast(source.{x} as string),'')", match_cols)))
        match_trg_str = "||'-'||".join(list(map(lambda x: f"nvl(cast(target.{x} as string),'')", match_cols)))
        match_str_outer = f"md5({match_src_str}) <> md5({match_trg_str})"

        merge_statement = f"""MERGE INTO {parameter_table_name} target USING 
            ( SELECT {select_stmnt_str} 
            FROM tmp_source_{parameter_table_name} as src
            UNION ALL 
            SELECT {union_all_stmnt_str} FROM tmp_source_{parameter_table_name} as src 
            JOIN {parameter_table_name} as trg ON {joining_str_inner} 
            WHERE trg.isActive = \'1\' 
            AND {match_str_inner} ) source ON {joining_str_outer} 
            WHEN MATCHED AND {match_str_outer} THEN 
            UPDATE
            SET target.isActive = \'0\', 
            target.EffectiveEndDate = source.EffectiveStartDate - interval 1 second
            WHEN NOT MATCHED THEN INSERT ({insert_col_str}) VALUES ({insert_val_str})
            """

        
        return merge_statement
        

    def run(self):
        '''
        This method is used to run the raw to standardize pipeline
        end-to-end.
        '''
        LOGGER.info("Starting Raw to Standardized pipeline")
        LOGGER.info("Started Initialisation")
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        LOGGER.info("Ended Initialisation")
        LOGGER.info("Starting Processing Data Files")
        self.raw_to_standardize_processor()