from edm.utils.const import TRANSFORMED_ZONE_DATA_PATH
from edm.utils.db_utility import DBConnection
from edm.utils.general_helper import (
    initialise, get_polybase_refresh_statement_batch)
from edm.utils.keyvault_utility import KeyvaultSecretsUtility
from edm.utils.logging_utility import get_logger


EXTERNAL_DATA_SOURCE = 'ExtenalDataSourceTransformed'
LOGGER = get_logger(__name__)


class SyncPolybaseDeltaTables:
    def __init__(
        self, ingestion_type, adls_account_name, spn_credentials,
        config_path, kv_name, spark, synapse_server, synapse_db
    ):
        self.ingestion_type = ingestion_type
        self.adls_account_name = adls_account_name
        self.spn_credentials = spn_credentials
        self.config_path = config_path
        self.kv_name = kv_name
        self.spark = spark
        self.synapse_server_name = synapse_server
        self.synapse_db = synapse_db

    def sync_batch_synapse_delta_tables(self):
        LOGGER.info("Starting Ingestion for Batch Framework Tables")
        # 1. To get the list of Active sources, Tables and Columns
        sql_query = "SELECT sm.SourceID, sm.SourceName, sm.CountryCode, \
        sod.SourceObjectID, sod.ObjectName, sos.ColumnName, \
        sos.ColumnOrder, sos.DataType, sod.ObjectType, \
        sos.IsActive, sos.[Length] \
        FROM metadata.SourceMaster sm \
        INNER JOIN metadata.SourceObjectDetail sod \
            ON sod.SourceID = sm.SourceID \
        INNER JOIN metadata.SourceObjectSchema sos \
            ON sos.SourceObjectID = sod.SourceObjectID \
        WHERE sm.IsActive = 1 AND sod.IsActive = 1 AND sos.IsActive = 1"

        LOGGER.info("Getting List of all objects for All Batch Sources")
        meta_info_df = self.db_obj.get_df_from_query(sql_query)
        object_master_list = (
            meta_info_df['SourceObjectID'].drop_duplicates().values
        )
        for object_id in object_master_list:
            table_prop_df = meta_info_df.loc[
                meta_info_df['SourceObjectID'] == object_id, :]
            source = table_prop_df['SourceName'].values[0]
            country = table_prop_df['CountryCode'].values[0]
            object_name = table_prop_df['ObjectName'].values[0]
            LOGGER.info(f"Syncing Tables for Object: {object_name}")

            delta_table_location = (
                TRANSFORMED_ZONE_DATA_PATH.replace(
                    'account', self.adls_account_name).replace(
                        'source', source).replace('country', country)
            )
            delta_table_location = (
                delta_table_location.rstrip('/') + '/' + object_name
            )

            # delta table creation
            delta_table_name = f'{source}_{country}_{object_name}_delta'
            LOGGER.info(f"Refreshing Delta table: {delta_table_name}")
            delta_table_exist_query = f"SHOW TABLES '{delta_table_name}'"
            delta_table_exist = self.spark.sql(delta_table_exist_query)
            if delta_table_exist.count() > 0:
                drop_delta_table_query = f'DROP TABLE {delta_table_name}'
                self.spark.sql(drop_delta_table_query)
            
            delta_table_creation_query = (
                f"CREATE TABLE {delta_table_name} USING DELTA LOCATION \
                    '{delta_table_location}'"
            )
            self.spark.sql(delta_table_creation_query)

            # Polybase Table Creation
            table_name = f'{source}_{country}_{object_name}'
            LOGGER.info(f"Refreshing Polybase table: {table_name}")
            schema = 'dbo'
            sql_query = (
                f"SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE \
                    TABLE_SCHEMA = '{schema}' AND TABLE_NAME = '{table_name}'"
            )
            results, _ = self.synapse_obj.run_sql_query(
                sql_query
            )
            if len(results) != 0:
                self.synapse_obj.run_sql_query(
                    f"DROP EXTERNAL TABLE {schema}.{table_name}"
                )
            polybase_sql_query = get_polybase_refresh_statement_batch(
                    'dbo', object_name, source, country,
                    table_prop_df, EXTERNAL_DATA_SOURCE)
            self.synapse_obj.run_sql_query(polybase_sql_query)

    def run(self):
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials,
            self.kv_name, self.adls_account_name, self.config_path
        )
        self.kv_client = KeyvaultSecretsUtility(
            self.spn_credentials, self.kv_name
        )
        _, synapse_username = self.kv_client.get_secret(
            self.config['synapse_details'][0]['synapse_user_name_secret']
        )
        _, synapse_pwd = self.kv_client.get_secret(
            self.config['synapse_details'][0]['synapse_password_secret']
        )
        self.synapse_obj = DBConnection(
            self.synapse_server_name, self.synapse_db, synapse_username,
            synapse_pwd)
        if self.ingestion_type.lower() == 'batch':
            LOGGER.info(
                f"Starting tables sync for Ingestion Type: {self.ingestion_type}")
            self.sync_batch_synapse_delta_tables()
        if self.ingestion_type.lower() == 'realtime':
            pass
        if self.ingestion_type.lower() == 'all':
            pass
