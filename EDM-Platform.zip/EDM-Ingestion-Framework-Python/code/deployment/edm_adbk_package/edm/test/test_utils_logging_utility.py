import logging
from unittest import TestCase
from unittest.mock import patch

from edm.utils.logging_utility import (
    get_logger, add_azure_handler_to_all_loggers)


class TestGetLogger(TestCase):
    def test_get_logger(self):
        logger = get_logger("my_test_logger")
        self.assertIsInstance(
            logger,
            logging.Logger)
        # logging.DEBUG corresponds to effective level =10
        self.assertEqual(logger.getEffectiveLevel(), 10)
        self.assertEqual(logger.name, 'edm.my_test_logger')
        self.assertEqual(len(logger.handlers), 1)
        self.assertIsInstance(logger.handlers[0], logging.StreamHandler)


class TestAddAzureHandlerToAllLoggers(TestCase):
    @patch('edm.utils.logging_utility.AzureLogHandler')
    def test_add_azure_handler_to_all_loggers(self, mock_azure_log_handler):
        # get_logger tested above
        logger_1 = get_logger("module1")
        logger_2 = get_logger("module2")

        instr_key = 'test_key'
        add_azure_handler_to_all_loggers(instr_key)

        self.assertEqual(len(logger_1.handlers), 2)
        self.assertEqual(len(logger_2.handlers), 2)
        mock_azure_log_handler.assert_called_once_with(
            connection_string='InstrumentationKey=test_key'
        )
