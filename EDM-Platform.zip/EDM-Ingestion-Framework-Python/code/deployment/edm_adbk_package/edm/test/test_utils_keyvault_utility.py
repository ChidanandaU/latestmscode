from unittest import TestCase
from unittest.mock import MagicMock, patch, Mock

from azure.core.exceptions import ResourceNotFoundError

from edm.utils.keyvault_utility import KeyvaultSecretsUtility

test_module_name = 'edm.utils.keyvault_utility'


class MockSecrets:
    def __init__(self):
        self.name = None
        self.value = None


def mock_keyvault(secret_name):
    secrets = {
        'Secret1': 'password1',
        'Secret2': 'password2',
    }
    secret_value = secrets.get(secret_name, None)
    print(secret_value)
    secrets_return = MockSecrets()
    if secret_value is not None:
        secrets_return.name = secret_name
        secrets_return.value = secret_value
        return secrets_return
    else:
        raise ResourceNotFoundError()


class TestKeyvaultUtility(TestCase):

    def setUp(self):
        self.spn_credentials = {
            'spn_id': 'SPIDI',
            'spn_password': 'SPTNIK',
            'tenant_id': 'TNT',
        }

    @patch(f'{test_module_name}.ClientSecretCredential')
    @patch(f'{test_module_name}.SecretClient')
    def test_init(self, mock_csc, mock_sc):
        spn_credentials = {
            'spn_id': 'SPIDI',
            'spn_password': 'SPTNIK',
            'tenant_id': 'TNT',
        }
        kv = KeyvaultSecretsUtility(spn_credentials, 'KV')
        mock_sc.assert_called_once()
        mock_csc.assert_called_once()

        assert kv.url == 'https://KV.vault.azure.net/'

    @patch(f'{test_module_name}.ClientSecretCredential')
    @patch(f'{test_module_name}.SecretClient')
    def test_get_secret(self, mock_csc, mock_sc):
        mock_client = Mock()
        mock_sc.return_value = mock_client
        mock_client.get_secret = MagicMock()
        mock_client.get_secret.side_effect = mock_keyvault

        kv_obj = KeyvaultSecretsUtility(self.spn_credentials, 'KV')
        kv_obj.client = mock_client

        secret_name, secret_value = kv_obj.get_secret('Secret1')
        self.assertEqual(secret_value, 'password1')
        self.assertEqual(secret_name, 'Secret1')

        secret_name, secret_value = kv_obj.get_secret('Secret2')
        self.assertEqual(secret_value, 'password2')
        self.assertEqual(secret_name, 'Secret2')

        with self.assertRaises(ResourceNotFoundError):
            kv_obj.get_secret('Secret3')
