from datetime import datetime
import re

import pandas as pd
from pyspark.sql.functions import (
    col, lower)

from edm.utils.const import (
    REALTIME_LANDING_PATH, CONTROLFILE_TABLE_MAPPING_FILENAME
)
from edm.utils.general_helper import (
    generate_date_range,
    initialise,
    get_tokenized_col_str
)
from edm.utils.logging_utility import get_logger

LOGGER = get_logger(__name__)
METADATASCHEMA = 'Metadata'
RECONSCHEMA = 'Recon'
RECON_COMPARISON_QUERY = (
                "SELECT {}\
                FROM \
                {} ctrl LEFT JOIN \
                {} \
                stg ON {} \
                WHERE stg.EventGuid IS NULL"
            )


class RealtimeDataReconcilication:
    '''
    This class is used to read a recon file,
    identify the list of tables for the recon,
    perform reconciliation for each table
    and write the failed records to the failed file
    '''
    def __init__(
            self, recon_file_name, recon_file_path, spark, dbutils, **kwargs):
        '''
        This constructor takes the necessary params required to create
        the object of RealtimeDataReconcilication class
        and the run the different function in this class.
        '''
        self.spark = spark
        self.dbutils = dbutils
        self.recon_file_name = recon_file_name
        self.recon_file_path = recon_file_path
        self.kv_name = kwargs.get('kv_name', None)
        self.spn_credentials = kwargs.get('spn_credentials', None)
        self.adls_account_name = kwargs.get('adls_account_name', None)
        self.config_path = kwargs.get('config_path', None)

    def get_control_file_details(self):
        res = re.sub(
            r'[0-9]{2}_[0-9]{2}_[0-9]{4}', 'DD_MM_YYYY', self.recon_file_name)
        recon_file_name_parts = res.split('_')
        recon_file_name_parts[1] = 'XX'
        control_file_name = '_'.join(recon_file_name_parts)
        recon_folder_index = self.recon_file_path.index('recon')
        recon_relative_path = (
            self.recon_file_path[recon_folder_index:].rstrip('/')
        )
        relative_file_path = (
            recon_relative_path + '/' + self.recon_file_name
        )
        recon_relative_path = relative_file_path.split('/')
        source_system = recon_relative_path[2]
        country = recon_relative_path[3]
        recon_date = (
            recon_relative_path[4] + '-' +
            recon_relative_path[5] + '-' +
            recon_relative_path[6]
        )
        recon_date = datetime.strptime(recon_date, '%Y-%m-%d')
        recon_date = recon_date.strftime('%Y-%m-%d')
        return control_file_name, source_system, recon_date, country

    def get_failed_file_name(self):
        date_part_index = re.search(
            r'[0-9]{2}_[0-9]{2}_[0-9]{4}', self.recon_file_name)
        self.failed_file_name = (
            self.recon_file_name[:date_part_index.start()] +
            'FAIL_'+self.recon_file_name[date_part_index.start():])
        recon_date_parts = self.recon_date.split('-')
        base_path = REALTIME_LANDING_PATH.replace(
            'account', self.adls_account_name
        )
        self.failed_file_path = (
            base_path.rstrip('/') + '/recon/failed/' +
            f'{self.source_system.lower()}/' +
            f'{recon_date_parts[0]}/' +
            f'{recon_date_parts[1]}/' +
            f'{recon_date_parts[2]}/' +
            self.failed_file_name.lstrip('/')
        )

    def get_tables_to_reconcile(self):
        '''
        This method is used to get the list of tables to be reconciled by
        using the control file name from ADLS
        '''
        base_path = REALTIME_LANDING_PATH.replace(
            'account', self.adls_account_name
        )
        adls_config_path = (
            base_path.rstrip('/') + '/recon/mapping/' +
            f'{self.source_system.lower()}/' +
            CONTROLFILE_TABLE_MAPPING_FILENAME.lstrip('/')
        )
        mapping_df = self.spark.read.options(
            delimiter=',', multiline=True).csv(adls_config_path, header=True)
        tables_to_be_reconciled = (
            mapping_df.filter(
                lower(col("CONTROL_FILE_NAME")) == (
                    self.control_file_name.lower())
                ).select(
                    col("Target_Table_Name").alias("table_name"),
                    col("Primary_Key").alias("pkcol_list")).collect()
        )
        recon_pk_list = tables_to_be_reconciled[0].pkcol_list.split('|')
        recon_table_list = [row.table_name for row in tables_to_be_reconciled]
        return recon_table_list, recon_pk_list

    def get_recon_rows_from_control_file(self):
        '''
        This function is used to read the Control file as Spark
        Dataframe from ADLS , read the nubmer of rows to be reconciled
        and then return the a pandas dataframe with the rows
        '''
        recon_folder_index = self.recon_file_path.index('recon')
        relative_file_path = (
            self.recon_file_path[recon_folder_index:].rstrip('/') +
            '/' + self.recon_file_name
        )
        control_file_path = REALTIME_LANDING_PATH.replace(
            'account', self.adls_account_name
        )
        control_file_path = (
            control_file_path.rstrip('/') + '/' + relative_file_path)
        LOGGER.info(f'Reading Control File: {control_file_path}')
        control_file_spark_df = (
            self.spark.read.format('csv').
            options(
                header=True,
                delimiter='\u0001',
                multiline=True, quote="\""
            ).load(control_file_path)
        )

        control_file_df = control_file_spark_df.toPandas()
        control_file_df = control_file_df.loc[
            control_file_df['H'] == 'D', self.recon_pk_list]
        return control_file_df

    def get_min_recon_pk_list(self, source_system_name):
        '''
        This method is used to get the list with minimum number of PK columns
        from mapping file in ADLS for a specific source system
        '''
        base_path = REALTIME_LANDING_PATH.replace(
            'account', self.adls_account_name
        )
        adls_config_path = (
            base_path.rstrip('/') + '/recon/mapping/' +
            f'{source_system_name.lower()}/' +
            CONTROLFILE_TABLE_MAPPING_FILENAME.lstrip('/')
        )
        # delimiter '|' to be added to kwargs or const
        mapping_df = (
            self.spark.read.options(delimiter=',').csv(
                adls_config_path, header=True))
        tables_to_be_reconciled = (
            mapping_df.select(
                col("Primary_Key").alias("pkcol_list")).collect())
        pk_col_list = [row.pkcol_list for row in tables_to_be_reconciled]
        pk_col_list.sort(key=len)
        return pk_col_list[0].split('|')

    def get_table_metadata_for_recon_tables(self):
        '''
        This method returns a dataframe having metadata
        for the list of recon tables
        '''
        self.tables_df = pd.DataFrame(
            data=self.recon_table_list, columns=['TargetTableName'])
        result_df = self.db_obj.get_result_df_from_input_df(
            schema=METADATASCHEMA,
            sp_name='uspGetStreamingTableMetadataUsingTableList',
            input_df=self.tables_df,
            table_type_name='TableType_RealTimeIngestion'
            )
        return result_df

    def tokenize_columns(self, data, table_name, table_prop_df):
        tokneization_func_base = "create or replace temporary function {} as'com.protegrity.hive.udf.{}'"
        spark_data = self.spark.createDataFrame(data)
        spark_data.createOrReplaceTempView(f'{table_name}Temp')
        tokenized_col_str, tokenization_func = get_tokenized_col_str(
            table_prop_df, recon=True
        )
        # TODO: register the functions dynamically
        for func in tokenization_func:
            sql_statement = tokneization_func_base.format(func, func)
            self.spark.sql(sql_statement)
        spark_sql_query = f"SELECT {tokenized_col_str} FROM {table_name}Temp"
        tokenized_col_df = self.spark.sql(spark_sql_query)
        return tokenized_col_df

    def get_last_recon_successful_tables(self):
        '''
        This method returns a dataframe having last recon status for tables
        '''
        result_df = self.db_obj.get_result_df_from_input_df(
            schema=METADATASCHEMA,
            sp_name='uspGetLastReconStatusRealtime',
            input_df=self.tables_df,
            table_type_name='TableType_RealTimeIngestion'
            )
        if(len(result_df) != 0):
            result_df_pd = result_df.loc[
                ((result_df['IsReconSuccessful'] == 0) |
                    (result_df['IsReconSkipped'] == 1)), :]
            invalid_recon_table_list = list(
                result_df_pd['TargetTableName'].values
            )
            return (
                    list(
                        set(self.recon_table_list) - set(
                            invalid_recon_table_list)),
                    invalid_recon_table_list, result_df)
        else:
            # for the first time when recon runs
            return self.recon_table_list, None, None

    def perform_data_recon_for_controlfile(self):
        '''
        This method performs data reconciliation
        by iterating through the list of tables.
        Inputs - self.recon_table_list,
        self.recon_dataframe,
        self.recon_pk_list,
        self.recon_tables_metadata
        '''
        pk_col_string = ','.join(self.recon_pk_list)
        stg_delta_table_view = 'StgDeltaTableSource'
        recon_data_view = 'ReconTableSource'
        untokenized_control_file_rows_df = self.recon_dataframe
        recon_table_list, invalid_recon_table_list, result_df = (
            self.get_last_recon_successful_tables())

        if(
            (invalid_recon_table_list is not None) and
                (len(invalid_recon_table_list) != 0)):
            self.reconcile_failed_tables(
                invalid_recon_table_list, result_df, pk_col_string)
        # reconciling for valid tables
        for recon_table in recon_table_list:
            try:
                # raise ValueError("Exception Test")
                stg_delta_table_name = f"{recon_table}_delta"
                std_delta_table_name = f"{recon_table}"
                delta_table_rows_query = (
                    f"SELECT {pk_col_string},EventGuid \
                            from {stg_delta_table_name} \
                                where cast(ModifiedOn as DATE) = \
                                '{self.recon_date}' \
                                    OR cast(CreatedOn as DATE)='{self.recon_date}'")

                stg_delta_table_rows = self.spark.sql(delta_table_rows_query)
                stg_delta_table_rows.createOrReplaceTempView(
                    stg_delta_table_view)
                table_prop_df = self.recon_tables_metadata.loc[
                    (
                        self.recon_tables_metadata['TargetTableName'] == (
                            recon_table)
                        ), :]
                tokenized_control_file_rows = self.tokenize_columns(
                    untokenized_control_file_rows_df,
                    recon_table, table_prop_df
                    )
                tokenized_control_file_rows.createOrReplaceTempView(
                    recon_data_view)
                ##TODO: Remove this line
                #untokenized_control_file_rows_df = self.spark.createDataFrame(
                #    untokenized_control_file_rows_df)
                ##TODO: Remove this line
                #untokenized_control_file_rows_df.createOrReplaceTempView(
                #    recon_data_view)           
                pk_col_df = pd.DataFrame(
                    self.recon_pk_list, columns=['ColumnName'])
                pk_col_df['pk_join_string'] = (
                    "ctrl." + pk_col_df['ColumnName'] +
                    "=stg." + pk_col_df['ColumnName'])
                pk_col_df['pk_select_string'] = (
                    "ctrl." + pk_col_df['ColumnName'])
                pk_join_string = (
                    ' AND '.join(pk_col_df['pk_join_string'].values))
                pk_select_string = (
                    ','.join(pk_col_df['pk_select_string'].values))
                compare_query = RECON_COMPARISON_QUERY.format(
                    pk_select_string, recon_data_view,
                    stg_delta_table_view, pk_join_string)
                failure_rows = self.spark.sql(compare_query)
                if(failure_rows.count() != 0):
                    self.process_failed_rows(failure_rows)
                    self.record_table_recon_results(
                        recon_table, failure_rows.count(), 0, 0,
                        len(self.recon_dataframe), None)
                else:
                    self.process_successful_rows(recon_table)
                    self.record_table_recon_results(
                        recon_table, 0, 0, 1, len(self.recon_dataframe), None)
            except Exception as err:
                self.record_table_recon_results(
                        recon_table, 0, 1, 0, len(self.recon_dataframe),
                        str(err)
                    )
                raise Exception

    def process_failed_rows(self, failure_rows):
        formatted_failure_rows = failure_rows.select(self.minimal_pk_col_list)
        formatted_failure_rows.write.format("csv").mode(
            "append").options(
                header=True,
                delimiter='\u0001'
                ).save(self.failed_file_path)
        # read all failed rows from failed file path
        all_failure_rows = (
            self.spark.read.format('csv').
            options(
                header=True,
                delimiter='\u0001',
                multiline=True, quote="\""
            ).load(self.failed_file_path)
        )
        all_failure_rows = all_failure_rows.distinct()
        all_failure_rows.write.format("csv").mode(
            "overwrite").options(
                header=True,
                delimiter='\u0001'
                ).save(self.failed_file_path)

    def process_successful_rows(
            self, table_name, retry_mode=False, last_recon_date=None):
        stg_delta_table_name = f"{table_name}_delta"
        if(retry_mode is False):
            successful_recon_rows_query = (
                f"SELECT * \
                        from {stg_delta_table_name} \
                            where cast(ModifiedOn as DATE) = \
                            '{self.recon_date}' \
                                OR cast(CreatedOn as DATE)='{self.recon_date}'")
        else:
            successful_recon_rows_query = (
                f"SELECT * \
                        from {stg_delta_table_name} \
                            where ( \
                                    (cast(ModifiedOn as DATE) >= '{last_recon_date}' AND \
                                    cast(ModifiedOn as DATE) <= '{self.recon_date}') \
                                    OR (cast(CreatedOn as DATE) >= '{last_recon_date}' \
                                    AND cast(CreatedOn as DATE) <= '{self.recon_date}')\
                                    )")

        successful_recon_rows = self.spark.sql(successful_recon_rows_query)
        recon_date_parts = self.recon_date.split('-')
        base_path = REALTIME_LANDING_PATH.replace(
            'account', self.adls_account_name
        )
        recon_success_file_path = (
            base_path.rstrip('/') + '/recon/success/' +
            f'{self.source_system.lower()}/' +
            f'{table_name}/' +
            f'{recon_date_parts[0]}/' +
            f'{recon_date_parts[1]}/' +
            f'{recon_date_parts[2]}/' +
            f'{table_name}.csv'.lstrip('/')
        )
        successful_recon_rows.write.format("csv").mode(
            "overwrite").options(
                header=True,
                delimiter='|'
                ).save(recon_success_file_path)

    def record_table_recon_results(
            self, table_name, failed_rows_count, is_recon_skipped,
            is_recon_successful, control_file_rows_count, exception_details):
        params = {
            'ControlFileName': self.recon_file_name,
            'TargetTableName': table_name,
            'ReconDate': self.recon_date,
            'ControlFileRecordCount': control_file_rows_count,
            'FailedEDMPTableRowCount': failed_rows_count,
            'IsReconSkipped': is_recon_skipped,
            'IsReconSuccessful': is_recon_successful,
            'ExceptionDetails': exception_details
        }

        LOGGER.info(
            f'Logging recon information for control file: \
                {self.control_file_name} and table:{table_name}'
            )
        self.db_obj.run_stored_proc(
            schema=RECONSCHEMA,
            stored_proc='uspInsertReconDetailsForStreamingTables',
            params=params
        )

    def reconcile_failed_tables(
        self, invalid_recon_table_list, result_df, pk_col_string
    ):
        stg_delta_table_view = 'StgDeltaTableSource'
        recon_data_view = 'ReconTableSource'
        for table in invalid_recon_table_list:
            try:
                stg_delta_table_name = f"{table}_delta"
                last_recon_date = (
                    result_df.loc[result_df["TargetTableName"] == (
                        table), :]['LastReconDate'].values[0])
                last_recon_date = str(last_recon_date).split("T")[0]
                current_recon_date = self.recon_date
                recon_date_range = (
                    generate_date_range(last_recon_date, current_recon_date))
                delta_table_rows_query = (
                        f"SELECT {pk_col_string},EventGuid \
                                from {stg_delta_table_name} \
                                    where ( \
                                            (cast(ModifiedOn as DATE) >= '{last_recon_date}' AND \
                                            cast(ModifiedOn as DATE) <= '{current_recon_date}') \
                                            OR (cast(CreatedOn as DATE) >= '{last_recon_date}' \
                                            AND cast(CreatedOn as DATE) <= '{current_recon_date}')\
                                            )"
                )

                delta_table_rows = self.spark.sql(delta_table_rows_query)
                delta_table_rows.createOrReplaceTempView(stg_delta_table_view)
                final_recon_df = pd.DataFrame()
                # date, source_system, control file name , path
                for recon_date in recon_date_range:
                    date_parts = recon_date.split('-')
                    year = date_parts[0]
                    month = date_parts[1]
                    date = date_parts[2]
                    recon_file_name = re.sub(
                        r'[0-9]{2}_[0-9]{2}_[0-9]{4}', f'{date}_{month}_{year}', 
                        self.recon_file_name)
                    recon_file_path = re.sub(
                        r'[0-9]{4}/[0-9]{2}/[0-9]{2}', f'{year}/{month}/{date}',
                        self.recon_file_path
                    )
                    # raw/recon
                    recon_folder_index = recon_file_path.index('recon')
                    relative_file_path = recon_file_path[recon_folder_index:]
                    base_path = REALTIME_LANDING_PATH.replace(
                        'account', self.adls_account_name
                    )
                    adls_config_path = (
                        base_path.rstrip('/') + '/' + relative_file_path + '/' +
                        recon_file_name.lstrip('/')
                    )
                    # delimiter '|' to be added to kwargs or const
                    control_file_spark_df = (
                        self.spark.read.format('csv').
                        options(
                            header=True,
                            delimiter='\u0001',
                            multiline=True, quote="\""
                        ).load(adls_config_path)
                    )
                    control_file_rows_pd_df = control_file_spark_df.toPandas()
                    control_file_rows_pd_df = control_file_rows_pd_df.loc[
                        control_file_rows_pd_df['H'] == 'D',
                        self.recon_pk_list
                    ]
                    final_recon_df = final_recon_df.append(
                        control_file_rows_pd_df
                    )
                final_recon_df = final_recon_df.drop_duplicates()
                table_prop_df = self.recon_tables_metadata.loc[
                    (self.recon_tables_metadata['TargetTableName'] == (
                        table)), :]
                final_recon_spark_df = self.tokenize_columns(
                    final_recon_df, table, table_prop_df)
                final_recon_spark_df.createOrReplaceTempView(recon_data_view)

                ##TODO: remove the line
                #final_recon_spark_df = self.spark.createDataFrame(
                #    final_recon_df)
                ##TODO: remove the line
                #final_recon_spark_df.createOrReplaceTempView(recon_data_view)
                pk_col_df = pd.DataFrame(
                        self.recon_pk_list, columns=['ColumnName'])
                pk_col_df['pk_join_string'] = (
                    "ctrl." + pk_col_df['ColumnName'] +
                    "=stg." + pk_col_df['ColumnName'])
                pk_col_df['pk_select_string'] = (
                    "ctrl." + pk_col_df['ColumnName'])
                pk_join_string = (
                    ' AND '.join(pk_col_df['pk_join_string'].values))
                pk_select_string = (
                    ','.join(pk_col_df['pk_select_string'].values))

                compare_query = RECON_COMPARISON_QUERY.format(
                    pk_select_string, recon_data_view,
                    stg_delta_table_view, pk_join_string)

                failure_rows = self.spark.sql(compare_query)
                if(failure_rows.count() == 0):
                    self.process_successful_rows(
                        table, True, last_recon_date)
                    self.record_table_recon_results(
                        table, 0, 0, 1, final_recon_spark_df.count(), None)
            except Exception:
                LOGGER.exception(
                    "Exception occured while processing control file \
                        {self.control_file_name} for table {table}"
                    )
                raise Exception

    def run(self):
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        # Getting the control file name and source system
        # by reading the control file name and path
        self.control_file_name, self.source_system, self.recon_date, \
            self.country = (
                self.get_control_file_details())
        # Composing the failed file name from the control file
        self.get_failed_file_name()
        # Getting the list of tables to be reconciled and
        # primary columns list specific to the control file
        # and the group of tables
        self.recon_table_list, self.recon_pk_list = (
            self.get_tables_to_reconcile())
        # Getting the metadata for the list of tables to be reconciled.
        self.recon_tables_metadata = self.get_table_metadata_for_recon_tables()
        # Getting the rows from the control file
        # that will be used for reconciliation
        self.recon_dataframe = self.get_recon_rows_from_control_file()
        # Getting the minimal list of primary key columns
        # for filling in the failed file
        self.minimal_pk_col_list = self.get_min_recon_pk_list(
            self.source_system)
        self.perform_data_recon_for_controlfile()
        LOGGER.info('Control file processing Completed')