import json

from avro import schema

from edm.utils.adls_utility import ADLSInterface
from edm.utils.event_hub_utility import EventHubConnection
from edm.utils.general_helper import (
    initialise, merge_sql_metastore_to_adbk_metastore)
from edm.utils.logging_utility import get_logger

LOGGER = get_logger(__name__)

TARGET_SCHEMA = 'metadata'


class ParseRegisterSchema:
    '''
    This class is used to Read and Parse the Schema Files dropped
    into ADLS schema folder in the raw zone. Register the schema into
    the Azure Hub Schema Registry and then update the same in the
    metastore.
    '''
    def __init__(self, file_name, file_path, spark, dbutils, **kwargs):
        self.spark = spark
        self.dbutils = dbutils
        self.file_name = file_name
        self.file_path = file_path
        self.kv_name = kwargs.get('kv_name', None)
        self.spn_credentials = kwargs.get('spn_credentials', None)
        self.adls_account_name = kwargs.get('adls_account_name', None)
        self.config_path = kwargs.get('config_path', None)
        self.source_name = self.file_path.split('/')[2]
        self.adls_client = ADLSInterface(
            self.adls_account_name, self.spn_credentials
        )

    def read_schema_from_adls(self, extension):
        '''
        This function is used to read the .avsc file from the
        ADLS using ADLS Utility and get the content in the form of Bytes
        Array.
        '''
        LOGGER.info(f'Reading {self.file_path}/{self.file_name}')
        schema_str_index = self.file_path.index('schema')
        file_path_wo_filename = self.file_path[schema_str_index:]
        relative_path = (
            file_path_wo_filename.rstrip('/') + '/' + self.file_name
        )
        file_system = self.file_path.split('/')[0]
        read_data = self.adls_client.get_file(
            remotepath=relative_path,
            file_system=file_system
        )
        if extension == 'avsc':
            schema_content = schema.parse(read_data.getvalue())
        #  other if blocks for other formats of schema in future.
        if extension == 'json':
            schema_str_data = read_data.getvalue().decode('UTF-8')
            json_dict = json.loads(schema_str_data)
            schema_content = json.dumps(json_dict)

        return schema_content

    def update_schema_registry_metastore(self, schema_id):
        '''
        This function is used to update the schema Guid in the
        Schema Registry table in the Metastore DB.
        '''
        LOGGER.info('Updating the Registry Table in the Metastore')
        adls_file_path = (
            self.file_path.rstrip('/') + '/' + self.file_name.lstrip('/')
        )
        params = {
            "SchemaName": self.source_name,
            "SchemaGuid": schema_id,
            "AdlsFilePath": adls_file_path

        }
        db_schema_name = 'metadata'
        sp_name = 'uspUpdateEventHubSchemaRegistryMaster'
        self.db_obj.run_stored_proc(
            db_schema_name, sp_name, params
        )
        source_df = self.db_obj.get_df_from_query(
            "SELECT * FROM metadata.EventHubSchemaRegistryMaster"
        )
        sql_statement = merge_sql_metastore_to_adbk_metastore(
            TARGET_SCHEMA, 'EventHubSchemaRegistryMaster', source_df,
            self.spark
        )
        self.spark.sql(sql_statement)

    def run(self):
        '''
        This function starts the Parser.
        It first initialised the required Clients, reads the .avsc
        file from the ADLS, Registers the schema content on the
        Azure Even Hub Registry and then updates the DB metastore.
        '''
        self.config, self.db_obj = initialise(
            self.spark, self.spn_credentials, self.kv_name,
            self.adls_account_name, self.config_path
        )
        extension_index = self.file_name.rindex(".")
        extension = self.file_name[extension_index+1:]
        schema_content = self.read_schema_from_adls(extension)
        LOGGER.info('Creating Event Hub Registry Connection')
        event_hub_obj = EventHubConnection(
            self.spn_credentials, self.config, self.spark
        )
        schema_id = event_hub_obj.register_schema_to_registry(
            self.source_name, schema_content,
            self.config['event_hub'][0]['schema_group_name']
        )
        self.update_schema_registry_metastore(schema_id)
