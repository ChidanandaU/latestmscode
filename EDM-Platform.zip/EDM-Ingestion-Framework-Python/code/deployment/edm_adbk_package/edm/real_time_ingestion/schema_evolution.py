from datetime import datetime

import pandas as pd
from pyspark.sql.functions import (col, lit)

STG_COLS_INGORED = ['EventGuid', 'CreatedOn', 'ModifiedOn']
STD_COLS_INGORED = ['EventGuid', 'StartDate', 'EndDate', 'IsActive']


class SchemaEvolution:
    def __init__(
        self, table_name,
        streaming_source, mode,
        delta_table_path, spark, dbutils
    ):
        self.table_name = table_name
        self.streaming_source = streaming_source
        self.mode = mode
        self.source_location = delta_table_path
        self.spark = spark
        self.dbutils = dbutils
        if mode.lower() == 'staging':
            self.delta_table_name = f"{self.table_name}_delta"
        else:
            self.delta_table_name = self.table_name

    def _get_delta_table_backup_name_loc(self):
        today = datetime.utcnow()
        backup_delta_location = (
            f"{self.source_location}_{today.year}_{today.month}_{today.day}")
        backup_delta_table_name = (
            f"{self.delta_table_name}_{today.year}_{today.month}_{today.day}")
        return backup_delta_location, backup_delta_table_name

    def run_delete_columns(self, table_prop_df):
        if self.mode.lower() == 'staging':
            delete_cols_df = table_prop_df.loc[
                (table_prop_df['IsSchemaEvolved'] == 1) &
                (table_prop_df['IsActive'] == 0), :
            ]
        else:
            delete_cols_df = table_prop_df.loc[
                (table_prop_df['IsSchemaEvolvedStandardized'] == 1) &
                (table_prop_df['IsActive'] == 0), :
            ]
        if len(delete_cols_df) > 0:
            # backup_location, backup_table_name = (
            #     self._get_delta_table_backup_name_loc()
            # )
            # self.dbutils.fs.cp(self.source_location, backup_location)
            # delta_backup_table_sql = (
            #     f"CREATE TABLE {backup_table_name} USING DELTA LOCATION \
            #         '{backup_location}'"
            #     )
            # self.spark.sql(delta_backup_table_sql)

            undeleted_columns = table_prop_df.loc[
                table_prop_df['IsActive'] == 1, :
            ]

            delta_table_cols = (
                    self.spark.sql(f"DESCRIBE TABLE {self.delta_table_name}")
                    )
            delta_table_cols = (
                delta_table_cols.filter(
                    col(
                        'data_type').isNotNull())
                )
            delta_table_cols_df_pd = delta_table_cols.toPandas()
            undeleted_columns = pd.merge(
                delta_table_cols_df_pd, undeleted_columns,
                left_on=['col_name'], right_on=['ColumnName'],
                how='inner'
            )
            undeleted_columns.sort_values(by=['ColumnOrder'], inplace=True)
            undeleted_cols_str = ",".join(
                undeleted_columns['ColumnName'].values
            )
            if self.mode.lower() == 'staging':
                undeleted_cols_str += ',EventGuid, CreatedOn, ModifiedOn'
            elif self.mode.lower() == 'standardized':
                undeleted_cols_str += ',EventGuid, StartDate, EndDate, IsActive'

            select_string = (
                f"SELECT {undeleted_cols_str} from {self.delta_table_name}")
            delta_table_data = self.spark.sql(select_string)
            (
                delta_table_data.write.format('delta')
                .mode('overwrite').
                option('overwriteschema', 'true').
                save(self.source_location)
            )

    def run_update_data_type_col_order(self, table_prop_df):
        if self.mode.lower() == 'staging':
            updated_columns = table_prop_df.loc[
                ((table_prop_df['IsSchemaEvolved'] == 1) &
                    (table_prop_df['IsActive'] == 1)), :]
            cols_to_ignore = STG_COLS_INGORED
        else:
            updated_columns = table_prop_df.loc[
                ((table_prop_df['IsSchemaEvolvedStandardized'] == 1) &
                    (table_prop_df['IsActive'] == 1)), :]
            cols_to_ignore = STD_COLS_INGORED
        if len(updated_columns) != 0:
            # First check for data type change
            table_prop_df = table_prop_df.loc[
                table_prop_df['IsActive'] == 1, :
            ]
            table_prop_df.sort_values(
                by=['ColumnOrder'], inplace=True
            )
            schema_evolution_src = 'SchemaEvolutionSource'
            current_table_schema = 'SchemaEvolutionCurrent'
            col_desc_sql = f"DESCRIBE TABLE {self.delta_table_name}"
            col_desc_df = self.spark.sql(col_desc_sql)
            col_desc_df.createOrReplaceTempView(schema_evolution_src)
            table_prop_spark_df = self.spark.createDataFrame(table_prop_df)
            table_prop_spark_df.createOrReplaceTempView(current_table_schema)

            col_desc_df_pd = col_desc_df.toPandas()
            col_desc_list = list(
                col_desc_df_pd.loc[
                    ((
                        col_desc_df_pd['data_type'].notnull()) & ~(
                            col_desc_df_pd['col_name'].isin(cols_to_ignore)
                            )), :]['col_name'].values)
            current_col_list = list(table_prop_df['ColumnName'].values)  # get column order sorted column list from metastore

            col_data_type_mismatch_sql = (
                f"SELECT src.col_name AS ColumnName, \
                src.data_type AS SrcDataType, \
                tar.SourceDataType AS CurrentDataType FROM \
                {schema_evolution_src} src INNER JOIN \
                {current_table_schema} \
                tar ON src.col_name = tar.ColumnName \
                AND lower(src.data_type) != lower(tar.SourceDataType)"
            )
            datatype_mismatched_cols = self.spark.sql(
                col_data_type_mismatch_sql
            )
            if datatype_mismatched_cols.count() != 0:   #datatype change
                # backup_location, backup_table_name = (
                #     self._get_delta_table_backup_name_loc()
                # )
                #   self.dbutils.fs.cp(self.source_location, backup_location, True)
                #   delta_backup_table_sql = (
                #       f"CREATE OR REPLACE TABLE {backup_table_name} USING DELTA LOCATION \
                #           '{backup_location}'"
                #   )
                #   self.spark.sql(delta_backup_table_sql)
                src_data = self.spark.sql(
                    f"SELECT * FROM {self.delta_table_name}"
                )
                datatype_mismatched_cols = datatype_mismatched_cols.toPandas()
                for _, row in datatype_mismatched_cols.iterrows():
                    column_name = row['ColumnName']
                    src_data_type = row['CurrentDataType']
                    src_data = src_data.withColumn(
                        column_name, col(column_name).cast(src_data_type)
                    )
                src_data.write.format('delta').mode('overwrite').\
                    option('overwriteschema', 'true').\
                    save(self.source_location)

            if col_desc_list != current_col_list:   # Column Order Change
                table_prop_df = pd.merge(
                    col_desc_df_pd, table_prop_df,
                    left_on=['col_name'], right_on=['ColumnName'],
                    how='inner')
                table_prop_df.sort_values(by=['ColumnOrder'], inplace=True)
                table_prop_df['ColumnWithDataType'] = (
                    table_prop_df['ColumnName'] + " " + table_prop_df['SourceDataType'])
                col_data_type_str = ",".join(
                    table_prop_df['ColumnWithDataType'].values
                )
                if self.mode.lower() == 'staging':
                    col_data_type_str += (
                        ",EventGuid string, CreatedOn timestamp, ModifiedOn timestamp")
                elif self.mode.lower() == 'standardized':
                    col_data_type_str += (
                        ",EventGuid string, StartDate DATE, EndDate DATE, IsActive INT")
                alter_sql = (
                    f"ALTER TABLE {self.delta_table_name} REPLACE COLUMNS \
                        ({col_data_type_str})"
                )
                self.spark.sql(alter_sql)

    def run_add_new_col(self, table_prop_df):
        is_active_columns = sorted(table_prop_df.loc[
                    table_prop_df['IsActive'] == 1, ['ColumnName']
                    ]['ColumnName'].values)
        delta_table_cols = (
                    self.spark.sql(f"DESCRIBE TABLE {self.delta_table_name}")
                    )
        delta_table_cols = (
                    delta_table_cols.filter(
                        col(
                            'data_type').isNotNull()).select('col_name').collect())
        if self.mode.lower() == 'staging':
            cols_to_ignore = STG_COLS_INGORED
        elif self.mode.lower() == 'standardized':
            cols_to_ignore = STD_COLS_INGORED
        delta_table_cols = sorted([
                    row.col_name for row in delta_table_cols if row.col_name not in cols_to_ignore
                    ])

        if is_active_columns != delta_table_cols:
            delta_table_data = self.spark.sql(
                f"SELECT * FROM {self.delta_table_name} LIMIT 1"
            )
            new_cols = list(set(is_active_columns) - set(delta_table_cols))
            new_cols_df = table_prop_df.loc[
                table_prop_df['ColumnName'].isin(new_cols), :
            ]
            for _, row in new_cols_df.iterrows():
                delta_table_data = delta_table_data.withColumn(
                    row['ColumnName'], lit(None)
                )
                delta_table_data = delta_table_data.withColumn(
                    row['ColumnName'], col(row['ColumnName']).cast(
                        row['SourceDataType'])
                )
            current_table = delta_table_data
            (
                current_table.filter('1=2').
                write.format('delta').mode('append').
                option('mergeSchema', 'true').save(self.source_location)
            )
            # Reorder Columns
            ordered_cols = table_prop_df.loc[table_prop_df['IsActive'] == 1, :]
            ordered_cols.sort_values(by=['ColumnOrder'], inplace=True)
            ordered_cols['ColumnWithDataType'] = (
                        ordered_cols['ColumnName'] + " " + ordered_cols['SourceDataType'])
            ordered_cols_str = ",".join(
                ordered_cols['ColumnWithDataType'].values
            )
            if self.mode.lower() == 'staging':
                ordered_cols_str += (
                        ",EventGuid string, CreatedOn timestamp, ModifiedOn timestamp")
            elif self.mode.lower() == 'standardized':
                ordered_cols_str += (
                        ",EventGuid string, StartDate DATE, EndDate DATE, IsActive INT")
            alter_sql = (
                f"ALTER TABLE {self.delta_table_name} REPLACE COLUMNS \
                    ({ordered_cols_str})"
            )
            self.spark.sql(alter_sql)

    def run(self, table_prop_df):
        self.run_delete_columns(table_prop_df)
        self.run_update_data_type_col_order(table_prop_df)
        self.run_add_new_col(table_prop_df)
