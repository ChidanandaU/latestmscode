from setuptools import setup, find_packages

data = dict(
    name="edm",
    version="#{Build.BuildNumber}#",
    install_requires=[],
    data_files=[],
    packages=find_packages(),
)

if __name__ == '__main__':
    setup(**data)
