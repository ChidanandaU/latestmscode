#!/bin/bash

bdp_install_dir=/opt/protegrity/
bdp_package=BDP_Package_7.2.0.17-RC_db123.tgz

clean_up()
{
    if [ -d $bdp_install_dir ];then
        rm -rf $bdp_install_dir
    fi

    if [ -f /usr/bin/pepserver ];then
        rm -f /usr/bin/pepserver
    fi
    echo "Exiting..."
    exit 1;
}

setup_bdp()
{
    if [ ! -d ${bdp_install_dir} ];then
        echo -e "\nBig Data Protector Installation started under ${bdp_install_dir}.\n"
        mkdir -p ${bdp_install_dir}

        if [ $? -ne 0 ];then
            echo -e "\nError: Unable to create directory ${bdp_install_dir}.\n"
            clean_up
        fi

        if [ ! -f /dbfs/${bdp_package} ];then
            echo -e "\nError: ${bdp_package} doesn't exist in /dbfs/ directory.\n"
            clean_up
        fi
        
        cp /dbfs/${bdp_package} ${bdp_install_dir}/
        
        echo -e "\nExtracting from ${bdp_package}\n"
        tar -xvf ${bdp_install_dir}/${bdp_package} -C ${bdp_install_dir}

        if [ $? -ne 0 ]; then
            echo -e "\nError: Failed to extract from ${bdp_package} package.\n"
            clean_up
        fi

        rm -f ${bdp_install_dir}/${bdp_package}
        
        # Copying pepserver binary to /usr/bin
        cp ${bdp_install_dir}/defiance_dps/bin/pepserver /usr/bin/

        chmod +x /usr/bin/pepserver

        #symlink jpeplite.plm
        echo -e "\nSetting up Symbolic link for jpeplite.plm\n"
        ln -s ${bdp_install_dir}/jpeplite/lib/jpeplite.plm ${bdp_install_dir}/jpeplite/lib/libjpeplite.so
        if [ $? -ne 0 ]; then
            echo -e "\nError: Failed to create jpeplite symlink.\n"
            clean_up
        fi
    else
        # If BDP_Installation_directory exists, then Check for directories and files and links 
        echo -e "\n${bdp_install_dir} already exists. Checking for required files and directories...\n"
        if [ ! \( -d ${bdp_install_dir}/defiance_dps/bin -a -d ${bdp_install_dir}/defiance_dps/data \) ];then
            echo -e "\nError: ${bdp_install_dir}/defiance_dps/ directory does not exist\n"    
            exit 1    
        fi
        
        if [ ! -d ${bdp_install_dir}/jpeplite/lib ];then
            echo -e "\nError: ${bdp_install_dir}/jpeplite/lib/ directory does not exist\n"
            exit 1
        else
            if [ ! \( -f ${bdp_install_dir}/jpeplite/lib/jpeplite.plm -a -L ${bdp_install_dir}/jpeplite/lib/libjpeplite.so \) ];then
                echo -e "\nError: jpeplite files are missing.\n"
                exit 1
            fi
        fi

        if [ ! -f /usr/bin/pepserver ];then
            echo -e "\nError: pepserver not present in /usr/bin/\n"
            exit 1
        fi


    fi

    #starting pepserver
    echo -e "\nStarting Pepserver...\n"
    /usr/bin/pepserver -dir ${bdp_install_dir}/defiance_dps/data
    if [ $? -ne 0 ]; then
        echo -e "Error: Failed to start Pepserver."
        clean_up
    fi


}


setup_bdp

exit 0
