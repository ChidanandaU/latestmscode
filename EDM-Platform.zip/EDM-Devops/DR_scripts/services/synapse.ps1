#
#
#PowerShell Script for  testing Synapse DB Failover in DR Region
#
#
$restoration_point_name=(Get-Date).ToString()
$subscription_id=$args[1]

# Synapse Variables
$primaryResourceGroup=$args[2]
$PrimarySynapseWorkspace=$args[3]
$primaryPoolName=$args[4]

$SecondaryResourceGroup=$args[5]
$SecondarySynapseWorkspace=$args[6]
$SecondaryPoolName=$args[7]

$DWPerformanceValue=$args[8]

Write-Output "$BeginSynapseFailOver $subscription_id $primaryResourceGroup $PrimarySynapseWorkspace $primaryPoolName $SecondaryResourceGroup $SecondarySynapseWorkspace $SecondaryPoolName $DWPerformanceValue"


if($args[9] -eq $True) {

                        $timeout = new-timespan -Minutes 360
                        $sw = [diagnostics.stopwatch]::StartNew()
                          while ($sw.elapsed -lt $timeout){
                                # Create Restoration Point
                                Write-output "Create Restoration Point"
                                New-AzSynapseSqlPoolRestorePoint -WorkspaceName $PrimarySynapseWorkspace -Name $primaryPoolName -RestorePointLabel $restoration_point_name
                
                                start-sleep -seconds 5
                }
                
                        write-host "Synapse Snapshot Created After:"$sw.elapsed
}

if($args[0] -eq $True) 
{
        $pool = Get-AzSynapseSqlPool -ResourceGroupName $primaryResourceGroup -WorkspaceName $PrimarySynapseWorkspace  -Name $primaryPoolName
        $databaseId = $pool.Id -replace "Microsoft.Synapse", "Microsoft.Sql" -replace "workspaces", "servers" ` -replace "sqlPools", "databases"
        # Get the latest restore point
       $restorePoint = $pool | Get-AzSynapseSqlPoolRestorePoint | Select-Object -Last 1 
       # Restore to same workspace with source SQL pool

        Write-output "Restore from the Restoration Point in the DR Region"
        # Restore from the Restoration Point in the DR Region
        Restore-AzSynapseSqlPool -FromRestorePoint -RestorePoint $restorePoint.RestorePointCreationDate -TargetSqlPoolName  $SecondaryPoolName -ResourceGroupName $SecondaryResourceGroup -WorkspaceName $SecondarySynapseWorkspace -ResourceId $databaseId -PerformanceLevel $DWPerformanceValue

        Write-output "Remove Restoration Point"
        #Remove Restoration Point
        Remove-AzSynapseSqlPoolRestorePoint -WorkspaceName $PrimarySynapseWorkspace -SqlPoolName $primaryPoolName -RestorePointCreationDate $restorePoint.RestorePointCreationDate -Force
}
else
{
        Write-output "Synapse FailOver Skipped"
}
if($args[10] -eq $True) {
        Write-Output "Remove Last Restore Point"
        $pool = Get-AzSynapseSqlPool -ResourceGroupName $primaryResourceGroup -WorkspaceName $PrimarySynapseWorkspace  -Name $primaryPoolName
        $restorePoint = $pool | Get-AzSynapseSqlPoolRestorePoint | Select-Object -Last 1

        Remove-AzSynapseSqlPoolRestorePoint -ResourceId $restorePoint.Id -Force




}